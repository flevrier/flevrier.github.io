import sys
import os
import time
import math

import numpy as np

import scipy.ndimage
import scipy.signal
from scipy.stats import norm, rankdata

import ctypes

from astropy.io import fits
from astropy import units as u
from astropy import constants as const
from astropy.io import fits

import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Ellipse

from variables import *

data_type="d"

def id2filename(type,sim):
    if (sim=="Clump-0"):
        filename="SF-THY3D_grav_mag_bcl-036-"+type+"-X0.52-Y0.78-Z0.82-18.0pc-Q9.fits"
    if (sim=='9_9_standard-output_00240'):
        if (type=="dens"):filename="9_9_standard-output_00240-n.fits"
        if (type=="magnX"):filename="9_9_standard-output_00240-Blx.fits"
        if (type=="magnY"):filename="9_9_standard-output_00240-Bly.fits"
        if (type=="magnZ"):filename="9_9_standard-output_00240-Blz.fits"
# Clump center position : from 0 to 1 in any direction, 0.5 being at the center of the axis
#    if (sim=="SimulationTest"):
#        simtype="Test1"
#        X0="0.1" # Centre d'extraction
#        Y0="0.1"
#        Z0="0.1"
#        sz="1.0" # in pc
#        lmax="1" # Nombre de cellules sur un axe (2^lmax)
#    if (sim.find ("7_7_standard") >= 0):
#        simtype=sim
#        X0="0.0" # Centre d'extraction
#        Y0="0.0"
#        Z0="0.0"
#        sz="50.0" # in pc
#        lmax="7" # Nombre de cellules sur un axe (2^lmax)
#    if (sim.find ("9_9_standard") >= 0):
#        simtype=sim
#        X0="0.0" # Centre d'extraction
#        Y0="0.0"
#        Z0="0.0"
#        sz="50.0" # in pc
#        lmax="9" # Nombre de cellules sur un axe (2^lmax)
#    if (sim=="Clump-68096"):
#        simtype="THY3D_grav_mag_bcl-036"
#        X0="0.4140"
#        Y0="0.2324"
#        Z0="0.5908"
#        sz="18.261"
#        lmax="10"
#    if (sim=="Decay-hydro"):
#        simtype="DECAY_hydro-050"
#        X0="0.5"
#        Y0="0.5"
#        Z0="0.5"
#        sz="4.0"
#        lmax="7"
#    if (sim=="Decay-intermediate"):
#        simtype="DECAY-070"
#        X0="0.5"
#        Y0="0.5"
#        Z0="0.5"
#        sz="4.0"
#        lmax="7"
#    if (sim=="Decay-lowbeta"):
#        simtype="DECAY_lowbeta-070"
#        X0="0.5"
#        Y0="0.5"
#        Z0="0.5"
#        sz="4.0"
#        lmax="7"
    return(filename)

def build_coldens(n,direction,pixel_size): # COLUMN DENSITY
    if(direction=="x"):return((np.sum(n,2))*pixel_size)
    if(direction=="y"):return((np.sum(n,1))*pixel_size)
    if(direction=="z"):return((np.sum(n,0))*pixel_size)
    
def build_source_function(n,T,b,nu):
    # Return source function with n in cm-3 and T in K [T may be an array of same shape as n]
    # 02.03.2026 : Alter function to take in b (spectral index) as parameter, so that a variable beta is possible
    knu=kappa(nu,b) # dust opacity at assumed frequency. 02.03.2026 : Modified this function to take in b (spectral index) as parameter
    sf=((((const.m_p.value)*1e3)/gas2dust)*knu)*(Bnu(T,nu).value)*n # Source function in SI provided integration axis is expressed in cm
    SI_2_MJysr=1e20 # To convert from SI to MJy/sr
    sf*=SI_2_MJysr
    return(sf)

def kappa(nu,b): # Return dust opacity at nu in Hz, Uses gas to dust ratio, tau353_over_NHI in cm2/H, spectral index beta, molecular fraction fH2    
    kappa_353=(gas2dust)*(1.0-fH2)*tau353_over_NHI/((const.m_p.value)*1e3) # in cm2/g
    nu_GHz=nu/1e9
    knu=kappa_353*np.power(nu_GHz/353.,beta)
    return(knu)

def Bnu(temperature, frequency):
    """
    Calculates the Planck function B_nu(T) for a given temperature and frequency.

    Parameters
    ----------
    temperature : `astropy.units.Quantity` or equivalent
        The temperature(s) of the blackbody. Can be a scalar or an array of temperatures.
    frequency : `astropy.units.Quantity` or equivalent
        The frequency(s) at which to evaluate the Planck function. Can be a scalar or an array of frequencies.

    Returns
    -------
    `astropy.units.Quantity`
        The Planck function B_nu(T) in units of `W / (m^2 Hz sr)`.

    Notes
    -----
    The Planck function is given by:
    B_nu(T) = (2 * h * nu^3 / c^2) * (1 / (exp(h * nu / (k * T)) - 1))
    where h is Planck's constant, c is the speed of light, k is Boltzmann's constant, nu is frequency, and T is temperature.
    """

    temp = u.Quantity(temperature, u.K, subok=True)
    freq = u.Quantity(frequency, u.Hz, subok=True)

    h = const.h
    c = const.c
    k = const.k_B

    # Store original shapes for broadcasting logic
    temp_orig_shape = temp.shape
    freq_orig_shape = freq.shape

    # --- Broadcasting for element-wise operations ---
    # This logic ensures that if temp is (M,) and freq is (N,), the calculation 
    # is performed for all M*N combinations, resulting in an (M, N) output.
    # If inputs are scalars or only one is an array, it handles those too.

    # Expand temp by adding singleton dimensions at the end, equal to freq's number of dimensions
    if freq.ndim > 0:
        temp = temp.reshape(temp_orig_shape + (1,) * freq.ndim)
    # Expand freq by adding singleton dimensions at the beginning, equal to temp's number of dimensions
    if temp_orig_shape != (): # If temp is not a scalar
        freq = freq.reshape((1,) * len(temp_orig_shape) + freq_orig_shape)

    # Calculate the exponent term (h * nu / (k * T))
    exponent_arg = (h * freq / (k * temp))
    exponent_arg = exponent_arg.to(u.dimensionless_unscaled)

    # Calculate the Planck function
    numerator_value = 2 * h * freq**3 / c**2
    denominator = np.exp(exponent_arg) - 1

    # The Planck function (spectral radiance) is per unit solid angle. 
    # Dividing by u.sr explicitly includes the solid angle dimension.
    planck_value = (numerator_value / denominator) / u.sr

    # Convert to standard units for spectral radiance.
    return planck_value.to(u.W / (u.m**2 * u.Hz * u.sr), equivalencies=u.equivalencies.spectral())

def get_rotplane(rotation_axis):
    if (rotation_axis=="x"):rotplane=(0,1)
    if (rotation_axis=="y"):rotplane=(0,2)
    if (rotation_axis=="z"):rotplane=(1,2)
    return(rotplane)

def rotate_scalar_cube(n0,angle,rotation_axis):
    rotplane=get_rotplane(rotation_axis)
    n=scipy.ndimage.rotate(n0,angle,axes=rotplane,order=1)    
    return(n)

def rotate_vector_cube(bx0,by0,bz0,angle,rotation_axis):
    rotplane=get_rotplane(rotation_axis)
    angle_rad=((angle*u.deg).to(u.rad)).value
    if (rotation_axis=="x"):
        print("NEEDS CHECKING... ABORTING")
        sys.exit()
#        bx=scipy.ndimage.rotate(bx0,angle,axes=rotplane,order=1)    
#        bz=scipy.ndimage.rotate(bz0*math.cos(angle_rad)+by0*math.sin(angle_rad),angle,axes=rotplane,order=1)    
#        by=scipy.ndimage.rotate(-bz0*math.sin(angle_rad)+by0*math.cos(angle_rad),angle,axes=rotplane,order=1) 
    if (rotation_axis=="y"): # CHECKED VIA show_rotation.py ON 04/01/2013 - WAS PREVIOUSLY WRONG ANGLE SIGN
        bx=scipy.ndimage.rotate(bx0*math.cos(angle_rad)-bz0*math.sin(angle_rad),angle,axes=rotplane,order=1)    
        by=scipy.ndimage.rotate(by0,angle,axes=rotplane,order=1)    
        bz=scipy.ndimage.rotate(bx0*math.sin(angle_rad)+bz0*math.cos(angle_rad),angle,axes=rotplane,order=1)
    if (rotation_axis=="z"):
        print("NEEDS CHECKING... ABORTING")
        sys.exit()
#        by=scipy.ndimage.rotate(by0*math.cos(angle_rad)+bx0*math.sin(angle_rad),angle,axes=rotplane,order=1)    
#        bx=scipy.ndimage.rotate(-by0*math.sin(angle_rad)+bx0*math.cos(angle_rad),angle,axes=rotplane,order=1) 
#        bz=scipy.ndimage.rotate(bz0,angle,axes=rotplane,order=1)    
    return(bx,by,bz)

def build_I_uncorrected(sf,direction,pixel_size): # STOKES I # returned in MJy/sr    
    if(direction=="x"):
        print("NEEDS CHECKING !")
        sys.exit()
#        return((np.sum(sf,2))*pixel_size)
    if(direction=="y"):
        print("NEEDS CHECKING !")
        sys.exit()
#        return((np.sum(sf,1))*pixel_size)
    if(direction=="z"):
        return((np.sum(sf,0))*pixel_size)

def build_I_correction(intrinsic_polar_times_sf,bx,by,bz,direction,pixel_size): # STOKES I # returned in MJy/sr    
    cube=np.zeros_like(intrinsic_polar_times_sf)
    b2=np.power(bx,2.0)+np.power(by,2.0)+np.power(bz,2.0)
    nz=np.where(b2>0)
    if(direction=="x"):
        print("NEEDS CHECKING !")
        sys.exit()
    if(direction=="y"):
        print("NEEDS CHECKING !")
        sys.exit()
    if(direction=="z"):
#        cube[nz]=-0.5*intrinsic_polar_times_sf[nz]*((((np.power(bx[nz],2.0)+np.power(by[nz],2.0))/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))-(2./3.)))
        cube[nz]=-intrinsic_polar_times_sf[nz]*((((np.power(bx[nz],2.0)+np.power(by[nz],2.0))/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))-(2./3.))) # Corrected from p0/2 to p0 according to VG 16/07/2013
        return((np.sum(cube,0))*pixel_size)

def build_Q(intrinsic_polar_times_sf,bx,by,bz,direction,pixel_size): # STOKES Q
    cube=np.zeros_like(intrinsic_polar_times_sf)
    b2=np.power(bx,2.0)+np.power(by,2.0)+np.power(bz,2.0)
    nz=np.where(b2>0)
    if(direction=="x"):
        print("NEEDS CHECKING !")
        sys.exit()
        #cube[nz]=intrinsic_polar_times_sf[nz]*((np.power(by[nz],2.0)-np.power(bz[nz],2.0))/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))
        #return((np.sum(cube,2))*pixel_size)
    if(direction=="y"):
        print("NEEDS CHECKING !")
        sys.exit()
        #cube[nz]=intrinsic_polar_times_sf[nz]*((np.power(bx[nz],2.0)-np.power(bz[nz],2.0))/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))
        #return((np.sum(cube,1))*pixel_size)
    if(direction=="z"):
        cube[nz]=intrinsic_polar_times_sf[nz]*((np.power(bx[nz],2.0)-np.power(by[nz],2.0))/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))        
        return((np.sum(cube,0))*pixel_size)

def build_U(intrinsic_polar_times_sf,bx,by,bz,direction,pixel_size): # STOKES U
    cube=np.zeros_like(intrinsic_polar_times_sf)
    b2=np.power(bx,2.0)+np.power(by,2.0)+np.power(bz,2.0)
    nz=np.where(b2>0)
    if(direction=="x"):
        print("NEEDS CHECKING !")
        sys.exit()
        #cube[nz]=-2.0*intrinsic_polar_times_sf[nz]*((by[nz]*bz[nz])/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))
        #return((np.sum(cube,2))*pixel_size)
    if(direction=="y"):
        print("NEEDS CHECKING !")
        sys.exit()
        #cube[nz]=-2.0*intrinsic_polar_times_sf[nz]*((bx[nz]*bz[nz])/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))
        #return((np.sum(cube,1))*pixel_size)
    if(direction=="z"):
        cube[nz]=2.0*intrinsic_polar_times_sf[nz]*((bx[nz]*by[nz])/(np.power(bx[nz],2.0)+np.power(by[nz],2.0)+np.power(bz[nz],2.0)))
        return((np.sum(cube,0))*pixel_size)

def build_P(Q,U): # POLARIZED INTENSITY P=sqrt(Q2+U2)
    return(np.sqrt(np.power(Q,2.0)+np.power(U,2.0)))

def build_P_over_I(P,I):
    result=np.zeros_like(P)
    nz=np.where(I!=0.0)
    result[nz]=P[nz]/I[nz]
    return(result)

def build_chi(Q,U): # IDENTICAL TO IDL'S 0.5*ATAN(-U,Q)
#    result=0.5*np.arctan2(-U,Q)+math.pi/2.0 # VG FORMULA
    result0=0.5*np.arctan2(U,Q) # VG FORMULA CORRECTED ON 13/02/2012 # CHECKED WITH HEALPIX CONVENTION ON PLOTS 07/01/2013 # CHANGED U SIGN ON 16/01/2013 TO FIT WITH IAU CONVENTION
#    result0=0.5*np.arctan2(-U,Q) # Apparently for Planck convention # SO THIS IS WHAT WE DO TO COMPARE MEANINGFULLY TO OBSERVATIONS : BUILD U AND Q IN HEALPIX, BUT THEN BUILD chi in AIU (18/01/2013)
#    result=np.zeros_like(result0)
#    pos=np.where(result0>=0)
#    neg=np.where(result0<0)
#    result[pos]=result0[pos]-math.pi/2.0
#    result[neg]=result0[neg]+math.pi/2.0
    return(result0)

def beam(beam_info,pixelsize):
    flag=1
    eps=1e-6
    bmaj=beam_info[0]
    bmin=beam_info[1]
    pa=beam_info[2]
    scale=beam_info[3]
    zero=beam_info[4]
    #print(bmaj,bmin,pixelsize)
    if ((bmaj<pixelsize) or (bmin<pixelsize)):
        print("Beam size too small with respect to pixel size, I will not be performing convolution")
        flag=0
        result=0
    else:
        max_sigma=fwhm2sigma(bmaj)
        min_sigma=fwhm2sigma(bmin)
        p=int(2.*math.ceil(bmaj/pixelsize))
        N=2*p+1
        XY_grids=XY(N,N)
        X0=(XY_grids[0]-float(p))*pixelsize
        Y0=(XY_grids[1]-float(p))*pixelsize
        X=(X0*math.cos(pa+math.pi/2.0))+(Y0*math.sin(pa+math.pi/2.0))
        Y=-(X0*math.sin(pa+math.pi/2.0))+(Y0*math.cos(pa+math.pi/2.0))
        argX=-mmultiply(X,X,np.ones((N,N),dtype=data_type)/(2.*math.pow(min_sigma,2.)))
        argY=-mmultiply(Y,Y,np.ones((N,N),dtype=data_type)/(2.*math.pow(max_sigma,2.)))
        result=np.zeros((N,N),dtype=data_type)
        for i in range(N):
            for j in range(N):
                result[i][j]=math.exp(argX[i][j]+argY[i][j])
        result=set_flux(result,1.0)
        toosmall=np.where(result < eps)
        for k in range(len(toosmall[0])):
            result[toosmall[0][k]][toosmall[1][k]]=0.0
        result=set_flux(result,1.0)
    #print(result.shape)
    #print(np.min(result),np.max(result))
    #matplotlib.pyplot.imshow(result,interpolation="nearest")
    #matplotlib.pyplot.show()
    return(result,bmaj,bmin,pa,scale,zero,flag)

def fwhm2sigma(fwhm):
    return((0.5)*fwhm/math.sqrt(2*math.log(2)))

def XY(Nx,Ny):
    X=grid(Nx)
    Y=grid(Ny)
    X.resize(Nx,1)
    XX=np.tile(X,(1,Ny))
    YY=np.tile(Y,(Nx,1))
    return(XX,YY)

def grid(N):
    return(np.linspace(0.0,float(N-1),N))

def mmultiply(*args):
    ret=args[0]
    for a in args[1:]:
        ret=np.multiply(ret,a)
    return(ret)

# Given a two-dimensional array and a flux, scales the array so that adding up all pixel values yields the desired flux
def set_flux(array,flux):
    factor=flux/total(array)
    return(array*factor)

def total(array):
    ret=sum(array)
    for i in range(1,array.ndim):
        ret=sum(ret)
    return(ret)

def remove_zero_strips(reference_map,tostrip_map):
    zero=np.where(reference_map==0)
    x_remove=np.where(np.sum(reference_map,1)==0)[0]
    y_remove=np.where(np.sum(reference_map,0)==0)[0]
    tostrip_map_nz=np.reshape(tostrip_map[reference_map>0],(reference_map.shape[0]-len(x_remove),reference_map.shape[1]-len(y_remove)))
    return(tostrip_map_nz)

def apply_beam(map,beam,mode):
    if (beam[6]==1):
        slice=np.zeros((map.shape[len(map.shape)-1],map.shape[len(map.shape)-1]),dtype=data_type) 
        if (len(map.shape)==4): # MEANS POLARIZATION AXIS IS IN
            for i_f in range(map.shape[1]):
                slice[:][:]=map[0][i_f][:][:]
                if ((i_f==0) or (np.max(slice)>0.0) or (np.min(slice)<0.0)):
                    result2d=scipy.signal.convolve2d(slice,beam[0],mode=mode)
                    if (i_f==0):
                        Ny_final=result2d.shape[0]
                        Nx_final=result2d.shape[1]
                else:
                    result2d=np.zeros((Ny_final,Nx_final),dtype=data_type)        
                if (i_f==0):
                    result=np.zeros((map.shape[0],map.shape[1],result2d.shape[0],result2d.shape[1]),dtype=data_type)        
                result[0][i_f][:][:]=result2d[:][:]
        if (len(map.shape)==3): # MEANS POLARIZATION AXIS IS NOT IN
            for i_f in range(map.shape[0]):
                slice[:][:]=map[i_f][:][:]
                if ((i_f==0) or (np.max(slice)>0.0) or (np.min(slice)<0.0)):
                    result2d=scipy.signal.convolve2d(slice,beam[0],mode=mode)
                    if (i_f==0):
                        Ny_final=result2d.shape[0]
                        Nx_final=result2d.shape[1]
                else:
                    result2d=np.zeros((Ny_final,Nx_final),dtype=data_type)        
                if (i_f==0):
                    result=np.zeros((map.shape[0],Ny_final,Nx_final),dtype=data_type)        
                result[i_f][:][:]=result2d[:][:]
        if (len(map.shape)==2): # APPLIES TO 2D TEMPLATES
            result=scipy.signal.convolve2d(map,beam[0],mode=mode)
            Ny_final=result.shape[0]
            Nx_final=result.shape[1]
    else:
        result=map
    return(result)

def fig_simple(color_data,crval,crpix,cdelt,cmap,data_range,extent,scale,XAXIS,YAXIS,XUNIT,YUNIT,title,figfile,color_units):
    Nx=color_data.shape[1]
    Ny=color_data.shape[0]
    fig=plt.figure(figsize=(8.8,8.3))
    D_norm = mpl.colors.Normalize(vmin=np.min(data_range), vmax=np.max(data_range))
    ax1 = fig.add_axes([0.03,0.15,0.85,0.8])
    if (scale=="lin"):ax1.imshow(color_data, interpolation='nearest',origin='lower',cmap=cmap,extent=extent,norm=D_norm)
    if (scale=="log"):ax1.imshow(np.log(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    if (scale=="log10"):ax1.imshow(np.log10(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    ax1.set_xlabel("$"+XAXIS+"$ $["+XUNIT+"]$",fontsize=20)
    ax1.set_ylabel("$"+YAXIS+"$ $["+YUNIT+"]$",fontsize=20)
    ax1.set_title(title+"\n",fontsize=20)
    ax1.axis(extent)
    locs, labels = plt.yticks()
    plt.setp(labels, rotation=90)
    ax2 = fig.add_axes([0.85,0.15,0.03, 0.8])
    cb1 = mpl.colorbar.ColorbarBase(ax2, cmap=cmap,norm=D_norm,orientation='vertical')
    cb1.set_label(color_units,fontsize=20)
    if (figfile!=""):
        plt.savefig(figfile)
        plt.clf()
    else:
        plt.show()

def fig_beamed(color_data,crval,crpix,cdelt,cmap,data_range,extent,scale,XAXIS,YAXIS,XUNIT,YUNIT,bmin,bmaj,bpa,title,figfile,color_units):
    Nx=color_data.shape[1]
    Ny=color_data.shape[0]
    fig=plt.figure(figsize=(8.8,8.3))
    D_norm = mpl.colors.Normalize(vmin=np.min(data_range), vmax=np.max(data_range))
    ax1 = fig.add_axes([0.03,0.15,0.85,0.8])
    if (scale=="lin"):ax1.imshow(color_data, interpolation='nearest',origin='lower',cmap=cmap,extent=extent,norm=D_norm)
    if (scale=="log"):ax1.imshow(np.log(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    if (scale=="log10"):ax1.imshow(np.log10(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    ax1.set_xlabel("$"+XAXIS+"$ $["+XUNIT+"]$",fontsize=20)
    ax1.set_ylabel("$"+YAXIS+"$ $["+YUNIT+"]$",fontsize=20)
    ax1.set_title(title+"\n",fontsize=20)
    ax1.add_artist(Ellipse(xy=[0.9*extent[0]+0.1*extent[1],0.9*extent[2]+0.1*extent[3]], width=bmin, height=bmaj, angle=bpa,fc='yellow',ec='black',lw=1))      
    ax1.axis(extent)
    locs, labels = plt.yticks()
    plt.setp(labels, rotation=90)
    ax2 = fig.add_axes([0.85,0.15,0.03, 0.8])
    cb1 = mpl.colorbar.ColorbarBase(ax2, cmap=cmap,norm=D_norm,orientation='vertical')
    cb1.set_label(color_units,fontsize=20)
    if (figfile!=""):
        plt.savefig(figfile)
        plt.clf()
    else:
        plt.show()

def fig_simple_with_arrows(color_data,angle_data,crval,crpix,cdelt,nperside,color,width,cmap,data_range,extent,scale,XAXIS,YAXIS,XUNIT,YUNIT,title,figfile,color_units):
    Nx=angle_data.shape[1]
    Ny=angle_data.shape[0]
    px=int(Nx/nperside)
    py=int(Ny/nperside)
    halflength=0.8*np.min([float(px),float(py)])
    fig=plt.figure(figsize=(10,8))
    D_norm = mpl.colors.Normalize(vmin=np.min(data_range), vmax=np.max(data_range))
    ax1 = fig.add_axes([0.03,0.11,0.85,0.8])
    if (scale=="lin"):ax1.imshow(color_data, interpolation='nearest',origin='lower',cmap=cmap,extent=extent,norm=D_norm)
    if (scale=="log"):ax1.imshow(np.log(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    if (scale=="log10"):ax1.imshow(np.log10(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)    
    ax1.set_xlabel("$"+XAXIS+"$ $["+XUNIT+"]$",fontsize=20)
    ax1.set_ylabel("$"+YAXIS+"$ $["+YUNIT+"]$",fontsize=20)
    ax1.set_title(title+"\n",fontsize=20)
    dx=cdelt[0]
    dy=cdelt[1]
    maxn=nperside+1    
    maxn=nperside+1    
    if ((maxn-1)*px<Nx-1):start_x=int((Nx-(maxn-1)*px)/2)-1
    else:start_x=0
    if ((maxn-1)*py<Ny-1):start_y=int((Ny-(maxn-1)*py)/2)-1
    else:start_y=0
    for ix in range(maxn):
        for iy in range(maxn):
            pix_x=ix*px+start_x
            pix_y=iy*py+start_y
            val_ix=(crval[0]+(float(pix_x)-crpix[0])*dx)
            val_iy=(crval[1]+(float(pix_y)-crpix[1])*dy)
            hdx=(halflength*(dx/2.0))
            hdy=(halflength*(dy/2.0))
            # NEED TO CHECK THAT THIS GIVES THE RIGHT ORIENTATION FOR ARROWS. I CHANGED SIGNS TO MATCH EARLIER FIGS BUT NOT SURE THESE WERE CORRECT THEN (26.02.2026)
            arrow_x=[val_ix+hdx*math.sin(angle_data[pix_y,pix_x]),val_ix-hdx*math.sin(angle_data[pix_y,pix_x])]
            #arrow_x=[val_ix-hdx*math.sin(angle_data[pix_y,pix_x]),val_ix+hdx*math.sin(angle_data[pix_y,pix_x])]
            arrow_y=[val_iy-hdy*math.cos(angle_data[pix_y,pix_x]),val_iy+hdy*math.cos(angle_data[pix_y,pix_x])]
            ax1.plot(arrow_x,arrow_y,color=color,lw=width)    
    ax1.axis(extent)
    ax2 = fig.add_axes([0.85,0.11,0.03, 0.8])
    cb1 = mpl.colorbar.ColorbarBase(ax2, cmap=cmap,norm=D_norm,orientation='vertical')
    cb1.set_label(color_units,fontsize=20)
    if (figfile!=""):
        plt.savefig(figfile)
        plt.clf()
    else:
        plt.show()

def fig_beamed_with_arrows(color_data,angle_data,crval,crpix,cdelt,nperside,color,width,cmap,data_range,extent,scale,XAXIS,YAXIS,XUNIT,YUNIT,bmin,bmaj,bpa,title,figfile,color_units):
    Nx=angle_data.shape[1]
    Ny=angle_data.shape[0]
    px=int(Nx/nperside)
    py=int(Ny/nperside)
    halflength=0.8*np.min([float(px),float(py)])
    fig=plt.figure(figsize=(10,8))
    D_norm = mpl.colors.Normalize(vmin=np.min(data_range), vmax=np.max(data_range))
    ax1 = fig.add_axes([0.03,0.11,0.85,0.8])
    if (scale=="lin"):ax1.imshow(color_data, interpolation='nearest',origin='lower',cmap=cmap,extent=extent,norm=D_norm)
    if (scale=="log"):ax1.imshow(np.log(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)
    if (scale=="log10"):ax1.imshow(np.log10(color_data), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)    
    ax1.set_xlabel("$"+XAXIS+"$ $["+XUNIT+"]$",fontsize=20)
    ax1.set_ylabel("$"+YAXIS+"$ $["+YUNIT+"]$",fontsize=20)
    ax1.set_title(title+"\n",fontsize=20)
    dx=cdelt[0]
    dy=cdelt[1]
    maxn=nperside+1    
    maxn=nperside+1    
    if ((maxn-1)*px<Nx-1):start_x=int((Nx-(maxn-1)*px)/2)-1
    else:start_x=0
    if ((maxn-1)*py<Ny-1):start_y=int((Ny-(maxn-1)*py)/2)-1
    else:start_y=0
    for ix in range(maxn):
        for iy in range(maxn):
            pix_x=ix*px+start_x
            pix_y=iy*py+start_y
            val_ix=(crval[0]+(float(pix_x)-crpix[0])*dx)
            val_iy=(crval[1]+(float(pix_y)-crpix[1])*dy)
            hdx=(halflength*(dx/2.0))
            hdy=(halflength*(dy/2.0))
            # NEED TO CHECK THAT THIS GIVES THE RIGHT ORIENTATION FOR ARROWS. I CHANGED SIGNS TO MATCH EARLIER FIGS BUT NOT SURE THESE WERE CORRECT THEN (26.02.2026)
            arrow_x=[val_ix+hdx*math.sin(angle_data[pix_y,pix_x]),val_ix-hdx*math.sin(angle_data[pix_y,pix_x])]
            #arrow_x=[val_ix-hdx*math.sin(angle_data[pix_y,pix_x]),val_ix+hdx*math.sin(angle_data[pix_y,pix_x])]
            arrow_y=[val_iy-hdy*math.cos(angle_data[pix_y,pix_x]),val_iy+hdy*math.cos(angle_data[pix_y,pix_x])]
            ax1.plot(arrow_x,arrow_y,color=color,lw=width)
    ax1.add_artist(Ellipse(xy=[0.9*extent[0],0.9*extent[2]], width=bmin, height=bmaj, angle=bpa,fc='yellow',ec='black',lw=1))  
    ax1.axis(extent)
    ax2 = fig.add_axes([0.85,0.11,0.03, 0.8])
    cb1 = mpl.colorbar.ColorbarBase(ax2, cmap=cmap,norm=D_norm,orientation='vertical')
    cb1.set_label(color_units,fontsize=20)
    if (figfile!=""):
        plt.savefig(figfile)
        plt.clf()
    else:
        plt.show()

# ROUTINE TO GENERATE T AND BETA CUBES A LA REGALDO-SAINT BLANCARD (2023)
def generate_gaussian_mapped_cube(
    n: np.ndarray, 
    mean: float, 
    std_dev: float, 
    correlation_type: str = 'correlated'
) -> np.ndarray:
    """
    Generates a 3D cube output from an input 3D cube n,
    such that output has a Gaussian distribution with specified mean and std_dev.
    The correlation between output and n can be either direct or inverse.

    Args:
        n (np.ndarray): The input 3D NumPy array (cube).
        mean (float): The desired mean of the Gaussian distribution for output.
        std_dev (float): The desired standard deviation of the Gaussian distribution for output.
        correlation_type (str): Specifies the type of correlation. 
                                'correlated' for direct correlation (default), 
                                'anti-correlated' for inverse correlation.

    Returns:
        np.ndarray: The output 3D NumPy array output with Gaussian-distributed values
                    correlated or anti-correlated with n.

    Raises:
        ValueError: If n is not a 3D NumPy array.
        ValueError: If correlation_type is not 'correlated' or 'anti-correlated'.
    """
    if not isinstance(n, np.ndarray) or n.ndim != 3:
        raise ValueError("Input 'n' must be a 3D NumPy array.")
    
    if correlation_type not in ['correlated', 'anti-correlated']:
        raise ValueError("correlation_type must be either 'correlated' or 'anti-correlated'.")

    # Handle edge case where all values in n are the same
    if np.all(n == n.flat[0]):
        # If all input values are the same, all output values will be the mean
        return np.full(n.shape, mean)

    # 1. Normalize n to the range [0, 1]
    min_n, max_n = n.min(), n.max()
    n_normalized = (n - min_n) / (max_n - min_n)

    # 2. Apply inversion if anti-correlated
    if correlation_type == 'anti-correlated':
        # Smaller values in original n (and n_normalized) will result in larger values here.
        processed_n = 1 - n_normalized
    else:
        processed_n = n_normalized

    # 3. Map to a Gaussian distribution using ranks
    flat_processed_n = processed_n.flatten()

    # Get ranks of the values. 'average' method handles ties.
    ranks = rankdata(flat_processed_n, method='average')

    # Convert ranks to quantiles
    quantiles = (ranks - 0.5) / len(flat_processed_n)

    # Apply the inverse CDF of the normal distribution
    output_flat = norm.ppf(quantiles, loc=mean, scale=std_dev)

    # Reshape the result back to the original 3D shape
    output = output_flat.reshape(n.shape)

    return output

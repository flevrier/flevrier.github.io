from variables import *
from routines import *

INPUT_DIR=SIMDATA_DIR+sim+"/Output/"
OUTPUT_DIR=SIMDATA_DIR+sim+"/Output-beamed/"

rotation_axis="y"
integration_axis="z"

# Retrieval of header information
hdr=(fits.open(SIMDATA_DIR+sim+"/Original-data/"+id2filename("dens",sim))[0]).header
# Cube size
Nx=hdr['NAXIS1']
Ny=hdr['NAXIS2']
Nz=hdr['NAXIS3']
if (rotation_axis=="x"):Ntokeep=Nx
if (rotation_axis=="y"):Ntokeep=Ny
if (rotation_axis=="z"):Ntokeep=Nz

# Pixel sizes
pc=(const.pc).to(u.cm).value # 1 pc in cm
dx_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('X')]
dy_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Y')]
dz_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Z')]
dx_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('X')]
dy_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Y')]
dz_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Z')]
if (dx_unit=="pc"):dx=pc*float(dx_val) # in cm
else:print("Unknown unit : ",dx_unit)
if (dy_unit=="pc"):dy=pc*float(dy_val) # in cm
else:print("Unknown unit : ",dy_unit)
if (dz_unit=="pc"):dz=pc*float(dz_val) # in cm
else:print("Unknown unit : ",dz_unit)
pixel_sizes=[dx,dy,dz]

# Axes
XUNIT="'"
YUNIT="'"
if (integration_axis=="x"):
    XAXIS="Y"
    YAXIS="Z"
if (integration_axis=="y"):
    XAXIS="X"
    YAXIS="Z"
if (integration_axis=="z"):
    XAXIS="X"
    YAXIS="Y"

# pixelsizes in arcseconds
dX=((((pixel_sizes[["x","y","z"].index(XAXIS.lower())]/pc)/distance)*u.rad).to(u.arcsec)).value
dY=((((pixel_sizes[["x","y","z"].index(YAXIS.lower())]/pc)/distance)*u.rad).to(u.arcsec)).value
# Assertion that dX and dY should be identical
assert dX==dY
# Construction of Gaussian beam 
b=beam(beam_info,dX) 


for nu in nus:
    nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
    print("Convolving maps for frequency "+nu_str)
    extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str

    for angle in angles:
        print("Computing for angle "+str(angle)+" degrees")
        # Read-in of NH, I, Q, U, P, P/I and chi at full resolution
        cd=(fits.open(INPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+".fits")[0]).data
        I=(fits.open(INPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data
        Q=(fits.open(INPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data
        U=(fits.open(INPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data
        P=(fits.open(INPUT_DIR+"P_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data
        PI=(fits.open(INPUT_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data    
        chi=(fits.open(INPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).data
        # Remove zero strips due to rotation
        cd_nz=remove_zero_strips(cd,cd)
        I_nz=remove_zero_strips(cd,I)
        Q_nz=remove_zero_strips(cd,Q)
        U_nz=remove_zero_strips(cd,U)
        P_nz=remove_zero_strips(cd,P)
        PI_nz=remove_zero_strips(cd,PI)
        chi_nz=remove_zero_strips(cd,chi)
        # keep only central Ntokeep*Ntokeep pixels, corresponding to the size of the special cases 0 and 90 degrees
        #### CHANGELOG 8/10/18: int cast added in the two following lines
        dpx=int ((cd_nz.shape[0]-Ntokeep)/2)
        dpy=int ((cd_nz.shape[1]-Ntokeep)/2)
        sub_cd_nz=cd_nz[dpx:dpx+Ntokeep-1,dpy:dpy+Ntokeep-1]
        sub_I_nz=I_nz[dpx:dpx+Ntokeep-1,dpy:dpy+Ntokeep-1]
        sub_Q_nz=Q_nz[dpx:dpx+Ntokeep-1,dpy:dpy+Ntokeep-1]
        sub_U_nz=U_nz[dpx:dpx+Ntokeep-1,dpy:dpy+Ntokeep-1]
        
        # Smoothing of full LOS column density, I, Q and U by the Planck beam
        sm_cd=apply_beam(sub_cd_nz,b,'valid')
        sm_I=apply_beam(sub_I_nz,b,'valid')
        sm_Q=apply_beam(sub_Q_nz,b,'valid')
        sm_U=apply_beam(sub_U_nz,b,'valid')

        ### THIS IS TO TEST THE CONVOLUTION OF THE P/I MAP DIRECTLY
        #sub_PI_nz=PI_nz[dpx:dpx+Ntokeep-1,dpy:dpy+Ntokeep-1]
        #fake_sm_PI=apply_beam(sub_PI_nz,b,'valid')

        # Construction of the smoothed P, P/I and chi (submm polarized emission angle, perpendicular to B) from the smoothed I, Q, U
        sm_P=build_P(sm_Q,sm_U)
        sm_PI=build_P_over_I(sm_P,sm_I)
        sm_chi=build_chi(sm_Q,sm_U)    
        # SELECT SUBSET IF REQUESTED
        if (select_central_subset):
            print("Selecting central subset of "+str(N_central_subset)+ " by "+str(N_central_subset)+" pixels")
            #### CHANGELOG 8/10/18: int cast added in the two following lines
            dpx=int ((sm_cd.shape[0]-N_central_subset)/2)
            dpy=int ((sm_cd.shape[1]-N_central_subset)/2)
            sub_sm_cd=sm_cd[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_I=sm_I[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_Q=sm_Q[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_U=sm_U[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_P=sm_P[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_PI=sm_PI[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sub_sm_chi=sm_chi[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            sm_cd=sub_sm_cd
            sm_I=sub_sm_I
            sm_Q=sub_sm_Q
            sm_U=sub_sm_U
            sm_P=sub_sm_P
            sm_PI=sub_sm_PI
            sm_chi=sub_sm_chi

            ### THIS IS TO TEST THE CONVOLUTION OF THE P/I MAP DIRECTLY
            #sub_fake_sm_PI=fake_sm_PI[dpx:dpx+N_central_subset,dpy:dpy+N_central_subset]
            #fake_sm_PI=sub_fake_sm_PI

        # WRITE ONE FILE TO FITS TO CREATE HEADER
        fits.writeto(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_I,overwrite=True)
        # READ IT BACK IN 
        hdr_out=(fits.open(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits")[0]).header
        # UPDATE HEADER
        # CHANGE THIS TO USE DEGREES AND NOT ARCSEC, AS CARTA DOES NOT ALLOW ARCSEC (26.02.2026)
        crval=[0.,0.]
        crpix=[sm_I.shape[1]/2,sm_I.shape[0]/2]
        cdelt=[-(dX*u.arcsec).to(u.deg).value,(dY*u.arcsec).to(u.deg).value]
        ctype=['RA---SIN','DEC--SIN']
        cunit=['DEGREE','DEGREE']
        for i in range(len(crval)): hdr_out ['CRVAL'+str(i+1)] = crval[i]
        for i in range(len(crpix)): hdr_out ['CRPIX'+str(i+1)] = crpix[i]
        for i in range(len(cdelt)): hdr_out ['CDELT'+str(i+1)] = cdelt[i]
        for i in range(len(ctype)): hdr_out ['CTYPE'+str(i+1)] = ctype[i]
        for i in range(len(cunit)): hdr_out ['CUNIT'+str(i+1)] = cunit[i]
        hdr_out ['BSCALE'] = beam_info[3]
        hdr_out ['BZERO'] = beam_info[4]
        if ((cunit[0].strip()).upper()=='DEGREE'):
            hdr_out ['BMAJ']  = (beam_info[0]*u.arcsec).to(u.deg).value
            hdr_out ['BMIN']  = (beam_info[1]*u.arcsec).to(u.deg).value
        if ((cunit[0].strip()).upper()=='ARCSEC'):
            hdr_out ['BMAJ']  = beam_info[0]
            hdr_out ['BMIN']  = beam_info[1]
        hdr_out ['BPA']  = beam_info[2]
        # WRITE OUT P/I THAT HAS NO  UNIT
        fits.writeto(OUTPUT_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_PI,hdr_out,overwrite=True)

        # WRITE OUT CHI THAT IS IN RADIANS
        hdr_out ['BUNIT']  = 'RADIANS'
        fits.writeto(OUTPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_chi,hdr_out,overwrite=True)

        # NOW USE UNIT cm-2 FOR COLUMN DENSITY AND WRITE IT OUT
        hdr_out ['BUNIT']  = 'cm-2'
        fits.writeto(OUTPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+"_sm"+str(Planck_FWHM)+".fits",sm_cd,hdr_out,overwrite=True)

        # NOW USE MJY/sr FOR I, Q, U, P AND WRITE THEM OUT
        hdr_out ['BUNIT']  = 'MJy/sr'                
        fits.writeto(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_I,hdr_out,overwrite=True)
        fits.writeto(OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_Q,hdr_out,overwrite=True)
        fits.writeto(OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_U,hdr_out,overwrite=True)
        fits.writeto(OUTPUT_DIR+"P_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",sm_P,hdr_out,overwrite=True)

        ### THIS IS TO TEST THE CONVOLUTION OF THE P/I MAP DIRECTLY
        #fits.writeto(OUTPUT_DIR+"fake_PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits",fake_sm_PI,hdr_out,overwrite=True)


from variables import *
from routines import *

# SF = source function

INPUT_DIR=SIMDATA_DIR+sim+"/Original-data/"
OUTPUT_DIR=INPUT_DIR

# LOAD DENSITY FILE
n_file=INPUT_DIR+id2filename("dens",sim)
n=(fits.open(n_file)[0]).data

if (variable_Tdust==None): # MAKE UNIFORM DUST TEMPERATURE CUBE
    print("Using uniform dust temperature of "+str(Tdust)+"K")
    Td=Tdust*np.ones_like(n)
elif (variable_Tdust=="Gaussian_mapping") : # MAKE A TEMPERATURE CUBE ACCORDING TO THE GAUSSIAN MAPPING AS IN BRSB 2023
    print("Using a dust temperature derived as a Gaussian mapping from the density cube as in Regaldo-Saint Blancard et al. (2023)")
    Td=generate_gaussian_mapped_cube(n, T_mean, T_std,correlation_type='anti-correlated')
    print("Temperature stats : Min="+str(np.min(Td))+" Max="+str(np.max(Td)))
    fits.PrimaryHDU(Td).writeto(INPUT_DIR+Td_tag+".fits",overwrite=True)
elif (variable_Tdust=="RADMC"): # USE A TEMPERATURE CUBE COMPUTED BY RADMC3D
    print("RADMC-3D dust temperature cube not yet implemented")
else:
    print("Dust temperature cube keyword not recognized")

if (variable_beta==None): # MAKE UNIFORM SPECTRAL INDEX CUBE
    print("Using uniform spectral index beta="+str(beta))
    beta_cube=beta*np.ones_like(n)
elif (variable_beta=="Gaussian_mapping"): # MAKE A SPECTRAL INDEX CUBE ACCORDING TO THE GAUSSIAN MAPPING AS IN BRSB 2023
    print("Using a spectral index derived as a Gaussian mapping from the density cube as in Regaldo-Saint Blancard et al. (2023)")
    beta_cube=generate_gaussian_mapped_cube(n, beta_mean, beta_std,correlation_type='correlated')
    print("Spectral index stats : Min="+str(np.min(beta_cube))+" Max="+str(np.max(beta_cube)))
    fits.PrimaryHDU(beta_cube).writeto(INPUT_DIR+beta_tag+".fits",overwrite=True)
else:
    print("Spectral index cube keyword not recognized")
    
if (include_RAT): # LOAD DUST ALIGNMENT EFFICIENCY (RAT = Radiative Alignment Torque)
    RAT_file=INPUT_DIR+"Pelkonen/RAT.fits"
    print("Using RAT file "+RAT_file)
    intrinsic_polar=((fits.open(RAT_file)[0]).data).astype('>f4')
elif (include_fake_RAT): # AD HOC DUST ALIGNMENT EFFICIENCY
    print("Using an ad hoc prescription for RAT efficiency")
    intrinsic_polar=alpha*np.ones_like(n)
    n0_fake_RAT=5e2 # Start decrease at 500 cm-2
    w=np.where(n>n0_fake_RAT)
    intrinsic_polar[w]=alpha*(n0_fake_RAT/n[w]) # inversely proportional to density
else: # MAKE UNIFORM DUST ALIGNMENT EFFICIENCY CUBE
    print("Using uniform alignment efficiency p0="+str(alpha))
    intrinsic_polar=alpha*np.ones_like(n)

for nu in nus:
    nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
    print("Building source function for "+nu_str)
    sf=build_source_function(n,Td,beta_cube,nu)
    fits.PrimaryHDU(sf).writeto(OUTPUT_DIR+"sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+".fits",overwrite=True)
    if (include_RAT):
        fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"RAT*sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+".fits",overwrite=True)
    if (include_fake_RAT):
        fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"fakeRAT*sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+".fits",overwrite=True)
        fits.PrimaryHDU(intrinsic_polar).writeto(INPUT_DIR+"fakeRAT_"+Td_tag+"_"+beta_tag+"_"+nu_str+".fits",overwrite=True)

#
#    if (variable_Tdust==None): # USE UNIFORM DUST TEMPERATURE SPECIFIED IN variables.py
#        fits.PrimaryHDU(sf).writeto(OUTPUT_DIR+"sf_"+str(Tdust)+"K"+"_"+nu_str+".fits",overwrite=True)
#        if (include_RAT):
#            fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"RAT*sf_"+str(Tdust)+"K"+"_"+nu_str+".fits",overwrite=True)
#        if (include_fake_RAT):
#            fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"fakeRAT*sf_"+str(Tdust)+"K"+"_"+nu_str+".fits",overwrite=True)
#            fits.PrimaryHDU(intrinsic_polar).writeto(INPUT_DIR+"fakeRAT_"+str(Tdust)+"K"+"_"+nu_str+".fits",overwrite=True)
#    elif (variable_Tdust=="Gaussian_mapping") : # USE A TEMPERATURE CUBE ACCORDING TO THE GAUSSIAN MAPPING AS IN BRSB 2023
#        fits.PrimaryHDU(sf).writeto(OUTPUT_DIR+"sf_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+".fits",overwrite=True)
#        if (include_RAT):
#            #print np.min(intrinsic_polar),np.max(intrinsic_polar)
#            fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"RAT*sf_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+".fits",overwrite=True)
#        if (include_fake_RAT):
#            #print np.min(intrinsic_polar),np.max(intrinsic_polar)
#            fits.PrimaryHDU(intrinsic_polar*sf).writeto(INPUT_DIR+"fakeRAT*sf_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+".fits",overwrite=True)
#            fits.PrimaryHDU(intrinsic_polar).writeto(INPUT_DIR+"fakeRAT_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+".fits",overwrite=True)
#    elif (compute_Tdust=="RADMC"): # USE A TEMPERATURE CUBE COMPUTED BY RADMC3D
#        print("RADMC-3D dust temperature cube not yet implemented")
#    else :
#        print("Dust temperature cube keyword not recognized")

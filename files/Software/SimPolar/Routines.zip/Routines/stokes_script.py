from variables import *
from routines import *

do_cd=1# # REQUIRES n
do_I0=1 # REQUIRES sf
do_deltaI=1 # REQUIRES alpha*sf,b
do_QU=1 # REQUIRES alpha*sf,b
do_chi_P_I_PI=1
apply_pmax_correction=False # IF True, APPLY SCALING TO VMP RAT TO MATCH MAXIMUM TO UNIFORM CASE (alpha)

INPUT_DIR=SIMDATA_DIR+sim+"/Rotated/"
OUTPUT_DIR=SIMDATA_DIR+sim+"/Output/"

rotation_axis="y"
integration_axis="z"

hdr=(fits.open(SIMDATA_DIR+sim+"/Original-data/"+id2filename("dens",sim))[0]).header

pc=(const.pc).to(u.cm).value # 1 pc in cm
if (('CDELT1' in hdr)and('CDELT2' in hdr)and('CDELT3' in hdr)and('CTYPE1' in hdr)and('CTYPE2' in hdr)and('CTYPE3' in hdr)and('CUNIT1' in hdr)and('CUNIT2' in hdr)and('CUNIT3' in hdr)):
    dx_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('X')]
    dy_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Y')]
    dz_val=[hdr['CDELT1'],hdr['CDELT2'],hdr['CDELT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Z')]
    dx_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('X')]
    dy_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Y')]
    dz_unit=[hdr['CUNIT1'],hdr['CUNIT2'],hdr['CUNIT3']][[hdr['CTYPE1'],hdr['CTYPE2'],hdr['CTYPE3']].index('Z')]
    if (dx_unit=="pc"):dx=pc*float(dx_val)
    else:print("Unknown unit : ",dx_unit)
    if (dy_unit=="pc"):dy=pc*float(dy_val)
    else:print("Unknown unit : ",dy_unit)
    if (dz_unit=="pc"):dz=pc*float(dz_val)
    else:print("Unknown unit : ",dz_unit)
    pixel_sizes=[dx,dy,dz] # GOT TO MAKE SURE UNIT IS cm, FOR INTEGRATION TO BE IN CORRECT UNITS (MJy/sr)
else:
    pixel_sizes=[1.0,1.0,1.0]

for angle in angles:
    print("Simulation : "+sim)
    print("Rotation axis : "+rotation_axis)
    print("Angle : "+str(angle))
    print("Integration axis : "+integration_axis)
    if (do_cd):
        print("--> Column density")
        n_file=INPUT_DIR+"n_"+rotation_axis+str(angle)+".fits"
        n=(fits.open(n_file)[0]).data        
        cd=build_coldens(n,integration_axis,pixel_sizes[["x","y","z"].index(integration_axis)])
        fits.PrimaryHDU(cd).writeto(OUTPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+".fits",overwrite=True)
        # INSERT UNIT IN HEADER FOR NH
        hdr_out=(fits.open(OUTPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+".fits")[0]).header
        hdr_out['BUNIT']='cm-2'
        fits.writeto(OUTPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+".fits",cd,hdr_out,overwrite=True)
        n=0

    for nu in nus:
        nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
        if(do_I0):
            print("--> Uncorrected Stokes I - T : "+str(variable_Tdust)+" - beta : "+str(variable_beta)+" - frequency : "+nu_str)
            sf_file=INPUT_DIR+"sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+"_"+rotation_axis+str(angle)+".fits"
            extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str
            sf=(fits.open(sf_file)[0]).data
            I0=build_I_uncorrected(sf,integration_axis,pixel_sizes[["x","y","z"].index(integration_axis)])
            fits.PrimaryHDU(I0).writeto(OUTPUT_DIR+"I0_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            # INSERT UNIT IN HEADER FOR I0
            hdr_out=(fits.open(OUTPUT_DIR+"I0_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"I0_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",I0,hdr_out,overwrite=True)
            
        if (do_deltaI)or(do_QU):
            bx_file=INPUT_DIR+"bx_"+rotation_axis+str(angle)+".fits"
            by_file=INPUT_DIR+"by_"+rotation_axis+str(angle)+".fits"
            bz_file=INPUT_DIR+"bz_"+rotation_axis+str(angle)+".fits"
            bx=(fits.open(bx_file)[0]).data
            by=(fits.open(by_file)[0]).data
            bz=(fits.open(bz_file)[0]).data

            # HERE CHANGE B VALUES TO UNIFORM FIELD FOR A TEST OF CONSISTENCY OF Q AND U (03.03.2026)
            #bx[:,:,:]=1.0
            #by[:,:,:]=-1.0
            #bz[:,:,:]=0.0
            #print(np.min(bx),np.max(bx))
            #print(np.min(by),np.max(by))
            #print(np.min(bz),np.max(bz))
            # Tested B=e_x : U=0 Q>0      --> OK
            # Tested B=e_y : U=0 Q<0      --> OK
            # Tested B=e_x+e_y : U>0 Q=0  --> OK
            # Tested B=e_x-e_y : U>0 Q=0  --> OK
            
            sf_file=INPUT_DIR+"sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+"_"+rotation_axis+str(angle)+".fits"            
            intrinsic_polar_times_sf=alpha*((fits.open(sf_file)[0]).data)
            extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str
                
        if (do_deltaI):
            print("--> Stokes I correction - T : "+str(variable_Tdust)+" - beta : "+str(variable_beta)+" - RAT : "+str(include_RAT)+" - RAT proxy : "+str(include_fake_RAT)+" - frequency : "+nu_str)
            dI=build_I_correction(intrinsic_polar_times_sf,bx,by,bz,integration_axis,pixel_sizes[["x","y","z"].index(integration_axis)])
            fits.PrimaryHDU(dI).writeto(OUTPUT_DIR+"dI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            # INSERT UNIT IN HEADER FOR dI
            hdr_out=(fits.open(OUTPUT_DIR+"dI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"dI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",dI,hdr_out,overwrite=True)
            
        if (do_QU):
            print("--> Stokes Q,U - T : "+str(variable_Tdust)+" - beta : "+str(variable_beta)+" - RAT : "+str(include_RAT)+" - RAT proxy : "+str(include_fake_RAT)+" - frequency : "+nu_str)
            Q=build_Q(intrinsic_polar_times_sf,bx,by,bz,integration_axis,pixel_sizes[["x","y","z"].index(integration_axis)])
            U=build_U(intrinsic_polar_times_sf,bx,by,bz,integration_axis,pixel_sizes[["x","y","z"].index(integration_axis)])
            fits.PrimaryHDU(Q).writeto(OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            fits.PrimaryHDU(U).writeto(OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)            
            # INSERT UNIT IN HEADER FOR Q
            hdr_out=(fits.open(OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",Q,hdr_out,overwrite=True)
            # INSERT UNIT IN HEADER FOR U
            hdr_out=(fits.open(OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",U,hdr_out,overwrite=True)
            
        if(do_chi_P_I_PI):
            I0_file=OUTPUT_DIR+"I0_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
            dI_file=OUTPUT_DIR+"dI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
            U_file=OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
            Q_file=OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
            I0=(fits.open(I0_file)[0]).data
            dI=(fits.open(dI_file)[0]).data
            U=(fits.open(U_file)[0]).data
            Q=(fits.open(Q_file)[0]).data
            print("--> Stokes I")
            I=I0+dI
            print("--> Polarised intensity")
            P=build_P(Q,U)
            print("--> Polarisation degree")
            PI=build_P_over_I(P,I)
            print("--> Polarisation angle")
            chi=build_chi(Q,U)
            extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str
            fits.PrimaryHDU(I).writeto(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            fits.PrimaryHDU(chi).writeto(OUTPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            fits.PrimaryHDU(P).writeto(OUTPUT_DIR+"P_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            fits.PrimaryHDU(PI).writeto(OUTPUT_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",overwrite=True)
            # INSERT UNIT IN HEADER FOR I
            hdr_out=(fits.open(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",I,hdr_out,overwrite=True)
            # INSERT UNIT IN HEADER FOR P
            hdr_out=(fits.open(OUTPUT_DIR+"P_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='MJy/sr'
            fits.writeto(OUTPUT_DIR+"P_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",P,hdr_out,overwrite=True)
            # INSERT UNIT IN HEADER FOR CHI
            hdr_out=(fits.open(OUTPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits")[0]).header
            hdr_out['BUNIT']='RADIANS'
            fits.writeto(OUTPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits",chi,hdr_out,overwrite=True)

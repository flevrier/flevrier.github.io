from routines import *
from variables import *

INPUT_DIR=SIMDATA_DIR+sim+"/Original-data/"
ROTATED_DIR=SIMDATA_DIR+sim+"/Rotated/"

rotation_axis="y"

# ALL POSSIBLE FIELDS TO ROTATE
#alltotreat=["B","n","T","RAT","sf_"+str(Tdust),"sf_Td","RAT*sf_"+str(Tdust),"RAT*sf_Td","P","fakeRAT*sf_"+str(Tdust),"fakeRAT*sf_Td"]
# Simplified list to get rid of RATs (27.02.2026). Will add back computed T dust if necessary.
alltotreat=["B","n","T","beta","sf"] 

# INFILE NAMES
#filenames=[[id2filename("magnX",sim),id2filename("magnY",sim),id2filename("magnZ",sim)],id2filename("dens",sim),"sf_"+str(Tdust)+".fits"]

# CORRESPONDING OUTFILE NAMES
#outfilenames=[["bx_","by_","bz_"],"n_","T_","RAT_","sf"+str(int(Tdust))+"_","sfT_","RAT*sf"+str(int(Tdust))+"_","RAT*sfT_","P_","fakeRAT*sf"+str(int(Tdust))+"_","fakeRAT*sfT_"]

# SELECT WHICH FILES TO ROTATE
totreat=["B","n","T","beta","sf"]
#totreat=["T","RAT","sf"+str(int(Tdust))+"","sfT","RAT*sf"+str(int(Tdust))+"","RAT*sfT"]
#totreat=alltotreat
#totreat=["B","n","sf_"+str(Tdust),"P"]
#totreat=["sf_Td","RAT*sf_Td"]
#totreat=["sf_Td"]
#totreat=["fakeRAT*sf_Td","B","n","T","sf_Td"]
#totreat=["fakeRAT*sf_"+str(Tdust)]

for item in totreat:
    if (item=="B"): # THESE ARE VECTOR QUANTITIES
        print("Rotating B cubes")
        bx_file=INPUT_DIR+id2filename("magnX",sim)
        by_file=INPUT_DIR+id2filename("magnY",sim)
        bz_file=INPUT_DIR+id2filename("magnZ",sim)
        bx0=(fits.open(bx_file)[0]).data
        by0=(fits.open(by_file)[0]).data
        bz0=(fits.open(bz_file)[0]).data
        for angle in angles:
            print("Computing for angle "+str(angle)+" degrees")
            bx,by,bz=rotate_vector_cube(bx0,by0,bz0,float(angle),rotation_axis)    
            fits.PrimaryHDU(bx).writeto(ROTATED_DIR+"bx_"+rotation_axis+str(angle)+".fits",overwrite=True)
            fits.PrimaryHDU(by).writeto(ROTATED_DIR+"by_"+rotation_axis+str(angle)+".fits",overwrite=True)
            fits.PrimaryHDU(bz).writeto(ROTATED_DIR+"bz_"+rotation_axis+str(angle)+".fits",overwrite=True)
        bx0=0
        by0=0
        bz0=0
        bx=0
        by=0
        bz=0
    if (item=="n") : # THIS IS A SCALAR QUANTITY
        print("Rotating density cube")
        infile=INPUT_DIR+id2filename("dens",sim)
        data0=((fits.open(infile)[0]).data).astype('>f4')
        for angle in angles:
            print("Computing for angle "+str(angle)+" degrees")
            data=rotate_scalar_cube(data0,float(angle),rotation_axis)
            fits.PrimaryHDU(data).writeto(ROTATED_DIR+"n_"+rotation_axis+str(angle)+".fits",overwrite=True)
        data0=0
    if (item=="T") : # THIS IS A SCALAR QUANTITY
        print("Rotating temperature cube")
        if (variable_Tdust==None):
            print("Using uniform dust temperature of "+str(Tdust)+"K so no cube to rotate")
        elif (variable_Tdust=="Gaussian_mapping") :
            infile=INPUT_DIR+Td_tag+".fits"
            data0=((fits.open(infile)[0]).data).astype('>f4')
            for angle in angles:
                print("Computing for angle "+str(angle)+" degrees")
                data=rotate_scalar_cube(data0,float(angle),rotation_axis)
                fits.PrimaryHDU(data).writeto(ROTATED_DIR+Td_tag+"_"+rotation_axis+str(angle)+".fits",overwrite=True)
            data0=0
        elif (compute_Tdust=="RADMC"):
            print("RADMC-3D dust temperature cube not yet implemented")
        else :
            print("Dust temperature cube keyword not recognized")        
    if (item=="beta") : # THIS IS A SCALAR QUANTITY
        print("Rotating spectral index cube")
        if (variable_beta==None):
            print("Using uniform spectral index of "+str(beta)+" so no cube to rotate")
        elif (variable_beta=="Gaussian_mapping") :
            infile=INPUT_DIR+beta_tag+".fits"
            data0=((fits.open(infile)[0]).data).astype('>f4')
            for angle in angles:
                print("Computing for angle "+str(angle)+" degrees")
                data=rotate_scalar_cube(data0,float(angle),rotation_axis)
                fits.PrimaryHDU(data).writeto(ROTATED_DIR+beta_tag+"_"+rotation_axis+str(angle)+".fits",overwrite=True)
            data0=0
        else :
            print("Spectral index cube keyword not recognized")        
    if (item=="sf") : # THIS IS A SCALAR QUANTITY
        for nu in nus:
            nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
            print("Rotating source function cubes for frequency "+nu_str)
            infile=INPUT_DIR+"sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+".fits"
            data0=((fits.open(infile)[0]).data).astype('>f4')
            for angle in angles:
                print("Computing for angle "+str(angle)+" degrees")
                data=rotate_scalar_cube(data0,float(angle),rotation_axis)
                fits.PrimaryHDU(data).writeto(ROTATED_DIR+"sf_"+Td_tag+"_"+beta_tag+"_"+nu_str+"_"+rotation_axis+str(angle)+".fits",overwrite=True)
            
#            if (variable_Tdust==None):
#                print("Using uniform dust temperature of "+str(Tdust)+"K")
#                infile=INPUT_DIR+"sf_"+str(Tdust)+"K_"+nu_str+".fits"
#                data0=((fits.open(infile)[0]).data).astype('>f4')
#                for angle in angles:
#                    print("Computing for angle "+str(angle)+" degrees")
#                    data=rotate_scalar_cube(data0,float(angle),rotation_axis)
#                    fits.PrimaryHDU(data).writeto(ROTATED_DIR+"sf_"+str(Tdust)+"K_"+nu_str+"_"+rotation_axis+str(angle)+".fits",overwrite=True)
#                data0=0
#            elif (variable_Tdust=="Gaussian_mapping") :
#                infile=INPUT_DIR+"sf_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+".fits"
#                data0=((fits.open(infile)[0]).data).astype('>f4')
#                for angle in angles:
#                    print("Computing for angle "+str(angle)+" degrees")
#                    data=rotate_scalar_cube(data0,float(angle),rotation_axis)
#                    fits.PrimaryHDU(data).writeto(ROTATED_DIR+"sf_Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)+"_"+nu_str+"_"+rotation_axis+str(angle)+".fits",overwrite=True)
#                data0=0
#            elif (compute_Tdust=="RADMC"):
#                print("RADMC-3D dust temperature cube not yet implemented")
#            else :
#                print("Dust temperature cube keyword not recognized")        

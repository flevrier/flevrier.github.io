from variables import *
from routines import *

OUTPUT_DIR=SIMDATA_DIR+sim+"/Output/"
BEAMED_DIR=SIMDATA_DIR+sim+"/Output-beamed/"
FIGS_DIR=SIMDATA_DIR+sim+"/Figs/"

rotation_axis="y"
integration_axis="z"

for angle in angles:
    print("Simulation : "+sim)
    print("Rotation axis : "+rotation_axis)
    print("Angle : "+str(angle))
    print("Integration axis : "+integration_axis)

    # PLOT UNCONVOLVED MAPS
    NH_file=OUTPUT_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+".fits"
    hdr=(fits.open(NH_file)[0]).header
    
    # Define the range
    minx=float(hdr["NAXIS1"])/2.0
    maxx=-float(hdr["NAXIS1"])/2.0
    miny=-float(hdr["NAXIS2"])/2.0
    maxy=float(hdr["NAXIS2"])/2.0
    extent=[minx,maxx,miny,maxy]  # Extension in X and Y (X axis to increase from right to left, as in the convolved map)  
    
    # Plot column density maps
    NH=(fits.open(NH_file)[0]).data
    if (autorange):
        fig_simple(np.log10(NH),[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["gist_heat"],[np.min(np.log10(NH)),np.max(np.log10(NH))],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+extension,r"$\log{\left(N_\mathrm{H}/\mathrm{cm}^{-2}\right)}$")
    else:
        fig_simple(np.log10(NH),[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["gist_heat"],[19.3,22.6],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+extension,r"$\log{\left(N_\mathrm{H}/\mathrm{cm}^{-2}\right)}$")

    for nu in nus:
        nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
        print("Plotting unconvolved I, Q, U, P/I maps for frequency "+nu_str)
        extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str
        # Plot I, Q, and U maps
        I_file=OUTPUT_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
        I=(fits.open(I_file)[0]).data        
        if (autorange):
            fig_simple(np.log10(I),[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["gist_heat"],[np.min(np.log10(I)),np.max(np.log10(I))],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$\log{\left(I/MJy.sr^{-1}\right)}$")
        else:
            fig_simple(np.log10(I),[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["gist_heat"],[-2.0,1.0],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$\log{\left(I/MJy.sr^{-1}\right)}$")
            
        Q_file=OUTPUT_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
        Q=(fits.open(Q_file)[0]).data
        if (autorange):
            fig_simple(Q,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["seismic"],[np.min(Q),np.max(Q)],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$Q [MJy.sr^{-1}]$")
        else:
            fig_simple(Q,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["seismic"],[-0.6,0.6],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$Q [MJy.sr^{-1}]$")

        U_file=OUTPUT_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
        U=(fits.open(U_file)[0]).data
        if (autorange):
            fig_simple(U,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["seismic"],[np.min(U),np.max(U)],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$U [MJy.sr^{-1}]$")
        else:
            fig_simple(U,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],mpl.colormaps["seismic"],[-0.6,0.6],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$U [MJy.sr^{-1}]$")
    
        # Plot polarization fraction and B orientation maps
        nperline=22
        PI_file=OUTPUT_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
        chi_file=OUTPUT_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+".fits"
        PI=(fits.open(PI_file)[0]).data
        chi=(fits.open(chi_file)[0]).data
        if (autorange):
            fig_simple_with_arrows(PI,chi+math.pi/2.0,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],nperline,"g",2,mpl.colormaps["gist_heat"],[np.min(PI),np.max(PI)],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$P/I$")
        else:
            fig_simple_with_arrows(PI,chi+math.pi/2.0,[0,0],[int(float(hdr["NAXIS1"])/2),int(float(hdr["NAXIS2"])/2)],[-1,1],nperline,"g",2,mpl.colormaps["gist_heat"],[0.0,0.22],extent,"lin","X","Y","pixel","pixel","",FIGS_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+extension,r"$P/I$")
        

    
    # PLOT CONVOLVED MAPS
    # Read a generic header from the column density file
    NH_file=BEAMED_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+"_sm"+str(Planck_FWHM)+".fits"
    hdr=(fits.open(NH_file)[0]).header

    # Define the range
    if(hdr["CUNIT1"]=="ARCSEC"):
        minx=((float(hdr["CRVAL1"])+(-0.5-float(hdr["CRPIX1"]))*float(hdr["CDELT1"]))*u.arcsec).to(u.deg).value
        maxx=((float(hdr["CRVAL1"])+(float(hdr["NAXIS1"])-0.5-float(hdr["CRPIX1"]))*float(hdr["CDELT1"]))*u.arcsec).to(u.deg).value
    if(hdr["CUNIT2"]=="ARCSEC"):
        miny=((float(hdr["CRVAL2"])+(-0.5-float(hdr["CRPIX2"]))*float(hdr["CDELT2"]))*u.arcsec).to(u.deg).value
        maxy=((float(hdr["CRVAL2"])+(float(hdr["NAXIS2"])-0.5-float(hdr["CRPIX2"]))*float(hdr["CDELT2"]))*u.arcsec).to(u.deg).value
    if(hdr["CUNIT1"]=="DEGREE"):
        minx=(float(hdr["CRVAL1"])+(-0.5-float(hdr["CRPIX1"]))*float(hdr["CDELT1"]))
        maxx=(float(hdr["CRVAL1"])+(float(hdr["NAXIS1"])-0.5-float(hdr["CRPIX1"]))*float(hdr["CDELT1"]))
    if(hdr["CUNIT2"]=="DEGREE"):
        miny=(float(hdr["CRVAL2"])+(-0.5-float(hdr["CRPIX2"]))*float(hdr["CDELT2"]))
        maxy=(float(hdr["CRVAL2"])+(float(hdr["NAXIS2"])-0.5-float(hdr["CRPIX2"]))*float(hdr["CDELT2"]))
    extent=[minx,maxx,miny,maxy]
    
    # Plot column density maps
    NH=(fits.open(NH_file)[0]).data
    if (autorange):
        fig_beamed(np.log10(NH),[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["gist_heat"],[np.min(np.log10(NH)),np.max(np.log10(NH))],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+"_sm"+str(Planck_FWHM)+extension,r"$\log{\left(N_\mathrm{H}/\mathrm{cm}^{-2}\right)}$")
    else:
        fig_beamed(np.log10(NH),[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["gist_heat"],[19.3,22.6],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"cd_"+rotation_axis+str(angle)+"_"+integration_axis+"_sm"+str(Planck_FWHM)+extension,r"$\log{\left(N_\mathrm{H}/\mathrm{cm}^{-2}\right)}$")

    for nu in nus:
        nu_str=str((nu*u.Hz).to(u.GHz).value)+"GHz"
        print("Plotting convolved I, Q, U, P/I maps for frequency "+nu_str)
        extra_tag="_"+Td_tag+"_"+beta_tag+"_"+nu_str
        # Plot I, Q, and U maps
        I_file=BEAMED_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits"
        I=(fits.open(I_file)[0]).data        
        if (autorange):
            fig_beamed(np.log10(I),[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["gist_heat"],[np.min(np.log10(I)),np.max(np.log10(I))],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$\log{\left(I/MJy.sr^{-1}\right)}$")
        else:
            fig_beamed(np.log10(I),[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["gist_heat"],[-2.0,1.0],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"I_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$\log{\left(I/MJy.sr^{-1}\right)}$")
            
        Q_file=BEAMED_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits"
        Q=(fits.open(Q_file)[0]).data
        if (autorange):
            fig_beamed(Q,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["seismic"],[np.min(Q),np.max(Q)],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$Q [MJy.sr^{-1}]$")
        else:
            fig_beamed(Q,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["seismic"],[-0.6,0.6],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"Q_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$Q [MJy.sr^{-1}]$")

        U_file=BEAMED_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits"
        U=(fits.open(U_file)[0]).data
        if (autorange):
            fig_beamed(U,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["seismic"],[np.min(U),np.max(U)],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$U [MJy.sr^{-1}]$")
        else:
            fig_beamed(U,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],mpl.colormaps["seismic"],[-0.6,0.6],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"U_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$U [MJy.sr^{-1}]$")
    
        # Plot polarization fraction and angleB orientation maps
        nperline=22
        PI_file=BEAMED_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits"
        chi_file=BEAMED_DIR+"chi_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_sm"+str(Planck_FWHM)+".fits"
        PI=(fits.open(PI_file)[0]).data
        chi=(fits.open(chi_file)[0]).data
        if (autorange):
            fig_beamed_with_arrows(PI,chi+math.pi/2.0,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],nperline,"g",2,mpl.colormaps["gist_heat"],[np.min(PI),np.max(PI)],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$P/I$")
        else:
            fig_beamed_with_arrows(PI,chi+math.pi/2.0,[float(hdr["CRVAL1"]),float(hdr["CRVAL2"])],[float(hdr["CRPIX1"]),float(hdr["CRPIX2"])],[float(hdr["CDELT1"]),float(hdr["CDELT2"])],nperline,"g",2,mpl.colormaps["gist_heat"],[0.0,0.22],extent,"lin","l","b","^\circ","^\circ",((bmin*u.arcsec).to(u.deg)).value,((bmaj*u.arcsec).to(u.deg)).value,bpa,"",FIGS_DIR+"PI_"+rotation_axis+str(angle)+"_"+integration_axis+extra_tag+"_"+nu_str+"_sm"+str(Planck_FWHM)+extension,r"$P/I$")
        

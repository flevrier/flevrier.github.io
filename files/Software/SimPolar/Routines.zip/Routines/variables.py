import numpy as np
import math

PLANCKDIR='/Users/levrier/Work/Projects/SimPolar-2026/'
SIMDATA_DIR=PLANCKDIR+'Data/'

# Simulations to consider
sim='9_9_standard-output_00240'
#sim="Clump-0"

# Intrinsic polarisation degree
alpha=0.2

# Angles to use for rotation
angles_list1=[0]
angles_list2=[0,30,60,90]
angles_list3=[0,15,30,45,60,75,90]
angles_list4=[0,15,30,45,60,75,90,105,120,135,150,165,180,195,210,225,240,255,270,285,300,315,330,345]
angles_list5=np.arange(0,355,5)
# Change the one below to select one list from above possibilities
angles=angles_list1

# Frequencies to use to build maps (in Hz)
#nus=[353e9] # Just the 353 GHz frequency
nus=[100e9,143e9,217e9,353e9,545e9,857e9] # Planck HFI frequencies
#nus=[300e9,800e9,3e12] # Frequencies in Regaldo-Saint Blancard et al. (2023)


# Dust temperature
variable_Tdust=None
#variable_Tdust="Gaussian_mapping"
#variable_Tdust="RADMC"
# None : Use uniform Tdust (value set below)
Tdust=18.0 # Dust temperature (assumed uniform) in K
# Gaussian_mapping : Use Gaussian mapping as in BRSB 2023. Parameters are set below
T_mean=15.0 # Mean dust temperature in the Gaussian mapping case
T_std=1.0 # Standard deviation of the dust temperature in the Gaussian mapping case
# RADMC : Use Tdust computed from RADMC-3D

# Spectral index
variable_beta=None
#variable_beta="Gaussian_mapping"
# None : Use uniform beta (value set below)
beta=1.65 # spectral index for dust thermal emission (P06b) when assuming uniform beta
# Gaussian_mapping : Use Gaussian mapping as in BRSB 2023. Parameters are set below
beta_mean=1.5 # Mean spectral index in the Gaussian mapping case
beta_std=0.2 # Standard deviation of the spectral index in the Gaussian mapping case

# MAKING TEMPERATURE AND SPECTRAL INDEX TAGS FOR FILENAMES
if (variable_Tdust==None): Td_tag="Td_"+str(Tdust)+"K"
elif (variable_Tdust=="Gaussian_mapping") : Td_tag="Td_Gaussian_Tmean"+str(T_mean)+"_Tstd"+str(T_std)
elif (variable_Tdust=="RADMC"): print("RADMC-3D dust temperature cube not yet implemented")
else: print("Dust temperature cube keyword not recognized")
if (variable_beta==None): beta_tag="beta_"+str(beta)
elif (variable_beta=="Gaussian_mapping"): beta_tag="beta_Gaussian_betamean"+str(beta_mean)+"_betastd"+str(beta_std)
else: print("Spectral index cube keyword not recognized")

# Other parameters for the source function
gas2dust=100.0 # gas-to-dust ratio
nu0=353e9 # Assumed reference frequency for simulated observations, in Hz
tau353_over_NHI=2.4e-26 # tau 353 GHZ to N_HI conversion (P06b)
fH2=0.5 # assumed molecular fraction

# Distance (used in convolution)
distance=100.0 # Distance to the simulated cloud (pc)

# Beam definition
Planck_FWHM=15.0 # Planck beam FWHM in arcmins
bmaj=Planck_FWHM*60.0 # Major axis FWHM, in arcseconds
bmin=bmaj # Minor axis FWHM, in arcseconds
bpa=0.0 # Position angle, in ...
beam_info=[bmaj,bmin,bpa,1.0,0.0,'JY/PIXEL']
#R_arcmins=16.04

# SELECTION OF A CENTRAL SUBSET AFTER CONVOLUTION
select_central_subset=True # Set to True to select 'in fine' the central N_central_subset by N_central_subset pixels
N_central_subset=491 # This should be adapted to the simulation (163 for Clump-0, 491 for 9_9_standard-output_00240 ?)

# Radiative Alignment Torque
include_RAT=False # Set to True to use local RAT efficiency as computed by V.-M. Pelkonen
include_fake_RAT=False
# RAT maximum in VMP file is not 0.2, so we may rescale it to 0.2 so we have the same maximum
#RAT_max_correction=alpha/0.183863028884 # FOR CLUMP 68096
#RAT_max_correction=alpha/0.182533 # FOR CLUMP 0

# PLOTTING VARIABLES
autorange=True # If True, figures will use min and max of maps. If False, a forced range is used.
extension=".png"

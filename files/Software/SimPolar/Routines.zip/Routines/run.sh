python sf_script.py
python rotation_script.py
python stokes_script.py
python convolve_script.py
python figs_script.py

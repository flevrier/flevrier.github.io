import os
import pyfits
import matplotlib
import matplotlib.pyplot
import matplotlib.mpl
import numpy
from common_routines import constant,deg2arcsec,rad2deg
from common_map_routines import channel_boundary_frequencies,channel_boundary_velocities
from matplotlib.patches import Ellipse

TEST_DIR="../Tests/"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

def print_integrated_flux(file_hi_co,expected_integrated_flux,channel_span,nu0,line):
    data_hi_co=(pyfits.open(TEST_DIR+file_hi_co)[0]).data    
    hdr=(pyfits.open(TEST_DIR+file_hi_co)[0]).header
    Nfreqs=hdr['NAXIS3']
    freq_info=[hdr['CRVAL3']/1e9,hdr['CDELT3']/1e9,Nfreqs]
    cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
    cbv=channel_boundary_velocities(cbf,nu0)[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax.
    intflux=0.0
    for i_f in channel_span:
        intflux+=(cbv[Nfreqs-i_f]-cbv[Nfreqs-i_f-1])*data_hi_co[i_f,:,:].sum()
    print " * "+line+" ----> "+str(intflux)+" Jy.km/s when expected integrated flux is "+str(expected_integrated_flux)+" Jy.km/s"
    
def fig_spatial_extent(file,major_axis,axis_ratio,figname):
#    print file
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
    Nx=hdr['NAXIS1']
    Ny=hdr['NAXIS2']
    Nfreqs=hdr['NAXIS3']
    # BUILD INTEGRATED IMAGE (ARBITRARY UNITS)    
    intflux=numpy.zeros((Ny,Nx),dtype=numpy.float64)
    for i_f in range(Nfreqs):intflux[:,:]+=(data[i_f,:,:])
    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
    x=deg2arcsec(float(hdr['CDELT1']))*(numpy.arange(float(Nx))-float(hdr['CRPIX1'])+1)+deg2arcsec(float(hdr['CRVAL1']))
    y=deg2arcsec(float(hdr['CDELT2']))*(numpy.arange(float(Ny))-float(hdr['CRPIX2'])+1)+deg2arcsec(float(hdr['CRVAL2']))
    extent=[max(x)-deg2arcsec(float(hdr['CDELT1']))/2.0,min(x)+deg2arcsec(float(hdr['CDELT1']))/2.0,min(y)-deg2arcsec(float(hdr['CDELT2']))/2.0,max(y)+deg2arcsec(float(hdr['CDELT2']))/2.0]
#    extent=[max(x),min(x),min(y),max(y)]
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern_r')
    # MAKE IMAGE
    ax1.imshow(intflux, interpolation='nearest',origin='lower',cmap=cmap,extent=extent)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])

    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
#    ax1.xaxis.set_major_locator(majorLocator)
    #ax1.yaxis.set_major_locator(majorLocator)
    ax1.set_xlabel(r'$\alpha$ ["]',fontsize=14)
    ax1.set_ylabel(r'$\delta$ ["]',fontsize=14)

    # ADD CROSS AT CENTRAL LOCATION
#    matplotlib.pyplot.scatter([deg2arcsec(RA)],[deg2arcsec(DEC)],marker="+",cmap=cmap,s=200)
    matplotlib.pyplot.axhline(y=deg2arcsec(DEC),xmin=0,xmax=1,color='red')
    matplotlib.pyplot.axvline(x=deg2arcsec(RA),ymin=0,ymax=1,color='red')
    # ADD ELLIPSE
    e=Ellipse(xy=[deg2arcsec(RA),deg2arcsec(DEC)], width=major_axis, height=major_axis*axis_ratio, angle=90.0-rad2deg(PA),fill=False)
    ax1.add_artist(e)
    e.set_clip_box(ax1.bbox)
#    e.set_alpha(0.5)
    # SAVE FIGURE
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

def fig_cut_window(file_tl,file_bl,file_tr,file_br,figname):
#    for file in files:
    hdu_tl=pyfits.open(TEST_DIR+file_tl)[0]
    hdr_tl=hdu_tl.header
    data_tl=hdu_tl.data

    hdu_tr=pyfits.open(TEST_DIR+file_tr)[0]
    hdr_tr=hdu_tr.header
    data_tr=hdu_tr.data
    hdu_bl=pyfits.open(TEST_DIR+file_bl)[0]
    hdr_bl=hdu_bl.header
    data_bl=hdu_bl.data
    hdu_br=pyfits.open(TEST_DIR+file_br)[0]
    hdr_br=hdu_br.header
    data_br=hdu_br.data
    # BUILD INTEGRATED IMAGE (ARBITRARY UNITS)    
    intflux_tl=numpy.zeros((hdr_tl['NAXIS2'],hdr_tl['NAXIS1']),dtype=numpy.float64)
    intflux_tr=numpy.zeros((hdr_tr['NAXIS2'],hdr_tr['NAXIS1']),dtype=numpy.float64)
    intflux_bl=numpy.zeros((hdr_bl['NAXIS2'],hdr_bl['NAXIS1']),dtype=numpy.float64)
    intflux_br=numpy.zeros((hdr_br['NAXIS2'],hdr_br['NAXIS1']),dtype=numpy.float64)
    for i_f in range(hdr_tl['NAXIS3']):intflux_tl[:,:]+=(data_tl[i_f,:,:])
    for i_f in range(hdr_tr['NAXIS3']):intflux_tr[:,:]+=(data_tr[i_f,:,:])
    for i_f in range(hdr_bl['NAXIS3']):intflux_bl[:,:]+=(data_bl[i_f,:,:])
    for i_f in range(hdr_br['NAXIS3']):intflux_br[:,:]+=(data_br[i_f,:,:])
#    print numpy.max(intflux_tl)
#    print numpy.max(intflux_tr)
#    print numpy.max(intflux_br)
#    print numpy.max(intflux_bl)
    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern_r')
    maxvalue=2.e-11
    tl=fig.add_subplot(2,2,1)
    x_tl=deg2arcsec(float(hdr_tl['CDELT1']))*(numpy.arange(float(hdr_tl['NAXIS1']))-float(hdr_tl['CRPIX1'])+1)+deg2arcsec(float(hdr_tl['CRVAL1']))
    y_tl=deg2arcsec(float(hdr_tl['CDELT2']))*(numpy.arange(float(hdr_tl['NAXIS2']))-float(hdr_tl['CRPIX2'])+1)+deg2arcsec(float(hdr_tl['CRVAL2']))
    extent_tl=[max(x_tl)-deg2arcsec(float(hdr_tl['CDELT1']))/2.0,min(x_tl)+deg2arcsec(float(hdr_tl['CDELT1']))/2.0,min(y_tl)-deg2arcsec(float(hdr_tl['CDELT2']))/2.0,max(y_tl)+deg2arcsec(float(hdr_tl['CDELT2']))/2.0]
#    extent_tl=[max(x_tl),min(x_tl),min(y_tl),max(y_tl)]
    # MAKE IMAGE
    tl.imshow(intflux_tl, interpolation='nearest',origin='lower',cmap=cmap,extent=extent_tl,vmax=maxvalue)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
#    tl.set_xlabel(r'$\alpha$ ["]',fontsize=20)
    tl.set_ylabel(r'$\delta$ ["]',fontsize=20)

    tr=fig.add_subplot(2,2,2)
    x_tr=deg2arcsec(float(hdr_tr['CDELT1']))*(numpy.arange(float(hdr_tr['NAXIS1']))-float(hdr_tr['CRPIX1'])+1)+deg2arcsec(float(hdr_tr['CRVAL1']))
    y_tr=deg2arcsec(float(hdr_tr['CDELT2']))*(numpy.arange(float(hdr_tr['NAXIS2']))-float(hdr_tr['CRPIX2'])+1)+deg2arcsec(float(hdr_tr['CRVAL2']))
    extent_tr=[max(x_tr)-deg2arcsec(float(hdr_tr['CDELT1']))/2.0,min(x_tr)+deg2arcsec(float(hdr_tr['CDELT1']))/2.0,min(y_tr)-deg2arcsec(float(hdr_tr['CDELT2']))/2.0,max(y_tr)+deg2arcsec(float(hdr_tr['CDELT2']))/2.0]
#    extent_tr=[max(x_tr),min(x_tr),min(y_tr),max(y_tr)]
    # MAKE IMAGE
    tr.imshow(intflux_tr, interpolation='nearest',origin='lower',cmap=cmap,extent=extent_tr,vmax=maxvalue)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
#    tr.set_xlabel(r'$\alpha$ ["]',fontsize=20)
#    tr.set_ylabel(r'$\delta$ ["]',fontsize=20)

    bl=fig.add_subplot(2,2,3)
    x_bl=deg2arcsec(float(hdr_bl['CDELT1']))*(numpy.arange(float(hdr_bl['NAXIS1']))-float(hdr_bl['CRPIX1'])+1)+deg2arcsec(float(hdr_bl['CRVAL1']))
    y_bl=deg2arcsec(float(hdr_bl['CDELT2']))*(numpy.arange(float(hdr_bl['NAXIS2']))-float(hdr_bl['CRPIX2'])+1)+deg2arcsec(float(hdr_bl['CRVAL2']))
    extent_bl=[max(x_bl)-deg2arcsec(float(hdr_bl['CDELT1']))/2.0,min(x_bl)+deg2arcsec(float(hdr_bl['CDELT1']))/2.0,min(y_bl)-deg2arcsec(float(hdr_bl['CDELT2']))/2.0,max(y_bl)+deg2arcsec(float(hdr_bl['CDELT2']))/2.0]
#    extent_bl=[max(x_bl),min(x_bl),min(y_bl),max(y_bl)]
    # MAKE IMAGE
    bl.imshow(intflux_bl, interpolation='nearest',origin='lower',cmap=cmap,extent=extent_bl,vmax=maxvalue)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
    bl.set_xlabel(r'$\alpha$ ["]',fontsize=20)
    bl.set_ylabel(r'$\delta$ ["]',fontsize=20)

    br=fig.add_subplot(2,2,4)
    x_br=deg2arcsec(float(hdr_br['CDELT1']))*(numpy.arange(float(hdr_br['NAXIS1']))-float(hdr_br['CRPIX1'])+1)+deg2arcsec(float(hdr_br['CRVAL1']))
    y_br=deg2arcsec(float(hdr_br['CDELT2']))*(numpy.arange(float(hdr_br['NAXIS2']))-float(hdr_br['CRPIX2'])+1)+deg2arcsec(float(hdr_br['CRVAL2']))
    extent_br=[max(x_br)-deg2arcsec(float(hdr_br['CDELT1']))/2.0,min(x_br)+deg2arcsec(float(hdr_br['CDELT1']))/2.0,min(y_br)-deg2arcsec(float(hdr_br['CDELT2']))/2.0,max(y_br)+deg2arcsec(float(hdr_br['CDELT2']))/2.0]
#    extent_br=[max(x_br),min(x_br),min(y_br),max(y_br)]
    # MAKE IMAGE
    br.imshow(intflux_br, interpolation='nearest',origin='lower',cmap=cmap,extent=extent_br,vmax=maxvalue)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
    br.set_xlabel(r'$\alpha$ ["]',fontsize=20)
#    br.set_ylabel(r'$\delta$ ["]',fontsize=20)


    # SAVE FIGURE
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

def plot_spectra_generic(FILES,expected_integrated_flux,nu0,figname,sum,Z):
# INITIALIZE FIGURE
    fig=matplotlib.pyplot.figure()
    ax=fig.add_subplot(111)
    ax.set_xlabel(r'$\nu$'+' [MHz]')
    ax.set_ylabel('Flux density [Jy]')

    i=0
    if (sum):total_intflux=0.0
    print "----------------------------------------------"
    print FILES
    for file in FILES:
        hdu=pyfits.open(TEST_DIR+file)[0]
        hdr=hdu.header
        data=hdu.data
        Nfreqs=hdr['NAXIS3']
        freq_axis=(numpy.arange(Nfreqs)-hdr['CRPIX3']+1)*(hdr['CDELT3']/1e6)+(hdr['CRVAL3']/1e6) # in MHz
        spectrum=numpy.zeros((Nfreqs),dtype=numpy.float64)
        for i_f in range(Nfreqs):spectrum[i_f]=(data[i_f,:,:]).sum()
        dfreq=hdr['CDELT3']/1e6
        colors = ['r','g','b','m','c','k','y']
        if (sum):
            if (i==0):ax.plot(freq_axis,spectrum,'b-')
            else:ax.plot(freq_axis,spectrum,'o')
        else:
            if (i==0):ax.plot(freq_axis,spectrum,'b-')
            elif (i==1):ax.plot(freq_axis,spectrum,'o')
            else:ax.bar(freq_axis-dfreq/2.0,spectrum,width=dfreq,edgecolor=colors[i-2],fill=False,linewidth=2)
#ax.plot(freq_axis,spectrum,'o')
        freq_info=[hdr['CRVAL3']/1e9,hdr['CDELT3']/1e9,Nfreqs]
        # COMPUTE INTEGRATED FLUX
        intflux=0.0
        cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
        cbv=channel_boundary_velocities(cbf,nu0)[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax.
        for i_f in range(Nfreqs):intflux+=(cbv[Nfreqs-i_f]-cbv[Nfreqs-i_f-1])*spectrum[i_f]
        if not(sum):
            print "----> "+str(intflux)+" Jy.km/s when expected integrated flux is "+str(expected_integrated_flux)+" Jy.km/s"
        else:
            if (i>0):total_intflux+=intflux
        i+=1
        if (i==0):ax.set_xlim([freq_axis[0],freq_axis[Nfreqs-1]])
    if (sum):print "----> "+str(total_intflux)+" Jy.km/s when expected integrated flux is "+str(expected_integrated_flux)+" Jy.km/s"
#    matplotlib.pyplot.xlim(125.232,141.232)
    matplotlib.pyplot.axvline(x=nu0/(1.+Z),linestyle='--',color='k')
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

#extension=".eps"
extension=".png"
##################################################
# MAKE FIGURES OF HI EXTENT FOR KAPTEYN TEMPLATES #
##################################################
fig_spatial_extent("sax-15mas-hi-5kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-15mas-hi-Kapteyn"+extension)
fig_spatial_extent("sax-5mas-hi-5kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-5mas-hi-Kapteyn"+extension)
fig_spatial_extent("sax-1mas-hi-5kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-1mas-hi-Kapteyn"+extension)
fig_spatial_extent("sax-unresolved-hi-1kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-6kHz-Kapteyn"+extension)
fig_spatial_extent("sax-unresolved-hi-5kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-60kHz-Kapteyn"+extension)
fig_spatial_extent("sax-unresolved-hi-20kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-600kHz-Kapteyn"+extension)
fig_spatial_extent("sax-unresolved-hi-50kHz-Kapteyn.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-2MHz-Kapteyn"+extension)

##############################################################################
# MAKE FIGURES OF HI EXTENT FOR KAPTEYN TEMPLATES, WITH GAUSSIAN BEAM APPLIED #
##############################################################################
fig_spatial_extent("sax-15mas-hi-5kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-15mas-hi-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-5mas-hi-5kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-5mas-hi-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-1mas-hi-5kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-1mas-hi-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-unresolved-hi-1kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-6kHz-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-unresolved-hi-5kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-60kHz-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-unresolved-hi-20kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-600kHz-Kapteyn-smeared"+extension)
fig_spatial_extent("sax-unresolved-hi-50kHz-Kapteyn-smeared.fits",HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,TEST_DIR+"extent-sax-unresolved-hi-2MHz-Kapteyn-smeared"+extension)

########################################################
# MAKE FIGURES OF HI EXTENT IN CUT SPATIAL WINDOW TEST #
########################################################
fig_cut_window("sax-1mas-hi-5kHz-Kapteyn-tl.fits","sax-1mas-hi-5kHz-Kapteyn-bl.fits","sax-1mas-hi-5kHz-Kapteyn-tr.fits","sax-1mas-hi-5kHz-Kapteyn-br.fits",TEST_DIR+"cut-window-sax-1mas-hi-Kapteyn"+extension)

default_sum=False
########################################################################
# PLOT HI SPECTRA KAPTEYN TEMPLATES - TEST VARYING SPECTRAL RESOLUTIONS #
########################################################################
FILES=["sax-unresolved-hi-1kHz-Kapteyn.fits",
       "sax-unresolved-hi-5kHz-Kapteyn.fits",
       "sax-unresolved-hi-20kHz-Kapteyn.fits",
       "sax-unresolved-hi-50kHz-Kapteyn.fits"]
plot_spectra_generic(FILES,HI,constant("nu0_HI"),TEST_DIR+"hi-Kapteyn-varying-spectral_resolution"+extension,default_sum,Z)

#############################################################
# PLOT HI SPECTRA KAPTEYN TEMPLATES - TEST CHANNEL SPLITTING #
#############################################################
FILES=["sax-unresolved-hi-1kHz-Kapteyn.fits",
       "sax-unresolved-hi-1kHz-low-Kapteyn.fits",
       "sax-unresolved-hi-1kHz-center-Kapteyn.fits",
       "sax-unresolved-hi-1kHz-high-Kapteyn.fits"]
plot_spectra_generic(FILES,HI,constant("nu0_HI"),TEST_DIR+"hi-Kapteyn-test-channel-splitting"+extension,True,Z)

#######################################################################
# PLOT HI SPECTRA KAPTEYN TEMPLATES - TEST VARYYING SPATIAL RESOLUTION #
#######################################################################
FILES=["sax-unresolved-hi-5kHz-Kapteyn.fits",
       "sax-5mas-hi-5kHz-Kapteyn.fits",
       "sax-1mas-hi-5kHz-Kapteyn.fits"]
plot_spectra_generic(FILES,HI,constant("nu0_HI"),TEST_DIR+"hi-Kapteyn-varying-spatial_resolution"+extension,default_sum,Z)

####################################################################################################
# PLOT HI SPECTRA KAPTEYN TEMPLATES, WITH GAUSSIAN BEAM APPLIED - TEST VARYING SPECTRAL RESOLUTIONS #
####################################################################################################
FILES=["sax-unresolved-hi-1kHz-Kapteyn-smeared.fits",
       "sax-unresolved-hi-5kHz-Kapteyn-smeared.fits",
       "sax-unresolved-hi-20kHz-Kapteyn-smeared.fits",
       "sax-unresolved-hi-50kHz-Kapteyn-smeared.fits"]
plot_spectra_generic(FILES,HI,constant("nu0_HI"),TEST_DIR+"hi-Kapteyn-varying-spectral_resolution-smeared"+extension,default_sum,Z)

###################################################################################################
# PLOT HI SPECTRA KAPTEYN TEMPLATES, WITH GAUSSIAN BEAM APPLIED - TEST VARYYING SPATIAL RESOLUTION #
###################################################################################################
FILES=["sax-unresolved-hi-5kHz-Kapteyn-smeared.fits",
       "sax-5mas-hi-5kHz-Kapteyn-smeared.fits",
       "sax-1mas-hi-5kHz-Kapteyn-smeared.fits"]
plot_spectra_generic(FILES,HI,constant("nu0_HI"),TEST_DIR+"hi-Kapteyn-varying-spatial_resolution-smeared"+extension,default_sum,Z)

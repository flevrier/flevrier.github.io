from common_routines import *
import sys
import ctypes
sys.path.append("../Config/")
from Config_Map import *
from Config_Path import *
import numpy
import scipy.ndimage
import os
import pyfits

# Load a custom-made shared C library.
_mylib = ctypes.cdll.LoadLibrary(ROUTINES_DIR+"libS3.so")

# Define Python-callable function(s) from the shared object library.
def weighting(n1,n2,n3,xmin,xmax,ymin,ymax,w_xmin,w_xmax,w_ymin,w_ymax,data_in,data_out):
    return _mylib.weighting( ctypes.c_int(n1), 
    		ctypes.c_int(n2), ctypes.c_int(n3), 
                ctypes.c_int(xmin), ctypes.c_int(xmax), 
                ctypes.c_int(ymin), ctypes.c_int(ymax), 
                ctypes.c_double(w_xmin),ctypes.c_double(w_xmax),
                ctypes.c_double(w_ymin),ctypes.c_double(w_ymax),            
            data_in.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            data_out.ctypes.data_as(ctypes.POINTER(ctypes.c_double)) )

def paste_single_cube_on_full_cube(single_cube,full_cube,Xref,Yref,pixelsize,w_i0,w_j0,Nx,Ny):
    # REFERENCE PIXELS
    crpix=single_cube[1]
    i0=crpix[0]
    j0=crpix[1]    
    z0=crpix[2]
    # DIMENSIONS OF SINGLE SOURCE CUBE
    Px=single_cube[0].shape[len(single_cube[0].shape)-1]
    Py=single_cube[0].shape[len(single_cube[0].shape)-2]        
    Pz=single_cube[0].shape[len(single_cube[0].shape)-3]
    # PIXEL INDEX OF THE SINGLE SOURCE CUBE'S BOTTOM LEFT PIXEL WITH RESPECT TO BOTTOM LEFT CORNER OF THE MAPPING WINDOW
    imin=i0-w_i0-Px/2
    jmin=j0-w_j0-Py/2
    # DETERMINE OVERLAP CRITERIA
    x=numpy.array(range(imin,imin+Px))
    criterion_x=(x>=0)&(x<Nx)
    y=numpy.array(range(jmin,jmin+Py))
    criterion_y=(y>=0)&(y<Ny)
    lx=numpy.where(criterion_x)[0]
    ly=numpy.where(criterion_y)[0]
    Nz=full_cube.shape[len(full_cube.shape)-3]
    if ((len(lx)>0) and (len(ly)>0)):
        lx1=numpy.min(lx)
        lx2=numpy.max(lx)
        ly1=numpy.min(ly)
        ly2=numpy.max(ly)
        x1=x[lx1]
        x2=x[lx2]
        y1=y[ly1]
        y2=y[ly2]
        # LOOP OVER THIRD AXIS
        for i in range(Pz):
            iz=z0-Pz/2+i
            if ((iz>-1)and(iz<Nz)):
                # THEN PASTE ONTO FULL MAP
                full_cube[z0-Pz/2+i,y1:y2+1,x1:x2+1]+=single_cube[0][i,ly1:ly2+1,lx1:lx2+1]

# Given a two-dimensional array and a flux, scales the array so that adding up all pixel values yields the desired flux
def set_flux(array,flux):
    factor=flux/total(array)
    return(array*factor)

def channel_boundary_frequencies(freq_info):
    min_freq=freq_info[0]-(freq_info[1]/2.0)
    result=[min_freq]
    for i in range(freq_info[2]):
        result.append(min_freq+float(i+1)*freq_info[1])
    return(result)

def channel_boundary_velocities(cbf,nu0):
    result=[]    
    for f in cbf:
        result.append(freq2velo(1000.0*f,nu0)) # nu0 is in MHz, cbf in GHz
    return(result) # WARNING : Decreasing velocities!

def apply_beam(map,beam):
    if (beam[6]==1):
        slice=numpy.zeros((map.shape[len(map.shape)-1],map.shape[len(map.shape)-1]),dtype=data_type) 
        if (len(map.shape)==4): # MEANS POLARIZATION AXIS IS IN
            for i_f in range(map.shape[1]):
                slice[:][:]=map[0][i_f][:][:]
                if ((i_f==0) or (numpy.max(slice)>0.0) or (numpy.min(slice)<0.0)):
                    result2d=scipy.signal.convolve2d(slice,beam[0])
                    if (i_f==0):
                        Ny_final=result2d.shape[0]
                        Nx_final=result2d.shape[1]
                else:
                    result2d=numpy.zeros((Ny_final,Nx_final),dtype=data_type)        
                if (i_f==0):
                    result=numpy.zeros((map.shape[0],map.shape[1],result2d.shape[0],result2d.shape[1]),dtype=data_type)        
                result[0][i_f][:][:]=result2d[:][:]
        if (len(map.shape)==3): # MEANS POLARIZATION AXIS IS NOT IN
            for i_f in range(map.shape[0]):
                slice[:][:]=map[i_f][:][:]
                if ((i_f==0) or (numpy.max(slice)>0.0) or (numpy.min(slice)<0.0)):
                    result2d=scipy.signal.convolve2d(slice,beam[0])
                    if (i_f==0):
                        Ny_final=result2d.shape[0]
                        Nx_final=result2d.shape[1]
                else:
                    result2d=numpy.zeros((Ny_final,Nx_final),dtype=data_type)        
                if (i_f==0):
                    result=numpy.zeros((map.shape[0],Ny_final,Nx_final),dtype=data_type)        
                result[i_f][:][:]=result2d[:][:]
        if (len(map.shape)==2): # APPLIES TO 2D TEMPLATES
            result=scipy.signal.convolve2d(map,beam[0])
            Ny_final=result.shape[0]
            Nx_final=result.shape[1]
    else:
        result=map
    return(result)

def beam(beam_info,pixelsize):
    flag=1
    eps=1e-9
    bmaj=beam_info[0]
    bmin=beam_info[1]
    pa=beam_info[2]
    scale=beam_info[3]
    zero=beam_info[4]
    if ((bmaj<pixelsize) or (bmin<pixelsize)):
        print "Beam size too small with respect to pixel size, I will not be performing convolution"
        flag=0
        result=0
    else:
        max_sigma=fwhm2sigma(bmaj)
        min_sigma=fwhm2sigma(bmin)
        p=int(3.*math.ceil(bmaj/pixelsize))
        N=2*p+1
        XY_grids=XY(N,N)
        X0=(XY_grids[0]-float(p))*pixelsize
        Y0=(XY_grids[1]-float(p))*pixelsize
        X=(X0*math.cos(pa+math.pi/2.0))+(Y0*math.sin(pa+math.pi/2.0))
        Y=-(X0*math.sin(pa+math.pi/2.0))+(Y0*math.cos(pa+math.pi/2.0))
        argX=-mmultiply(X,X,numpy.ones((N,N),dtype=data_type)/(2.*math.pow(min_sigma,2.)))
        argY=-mmultiply(Y,Y,numpy.ones((N,N),dtype=data_type)/(2.*math.pow(max_sigma,2.)))
        result=numpy.zeros((N,N),dtype=data_type)
        for i in range(N):
            for j in range(N):
                result[i][j]=math.exp(argX[i][j]+argY[i][j])
        result=set_flux(result,1.0)
        toosmall=numpy.where(result < eps)
        for k in range(len(toosmall[0])):
            result[toosmall[0][k]][toosmall[1][k]]=0.0
        result=set_flux(result,1.0)
    return(result,bmaj,bmin,pa,scale,zero,flag)

def write_fits_header(hdu,hdr,beam_info):
    crval=hdr[0]
    crpix=hdr[1]
    cdelt=hdr[2]
    ctype=hdr[3]
    cunit=hdr[4]
    for i in range(len(crval)): hdu.header.update('CRVAL'+str(i+1),crval[i])
    for i in range(len(crpix)): hdu.header.update('CRPIX'+str(i+1),crpix[i])
    for i in range(len(cdelt)): hdu.header.update('CDELT'+str(i+1),cdelt[i])
    for i in range(len(ctype)): hdu.header.update('CTYPE'+str(i+1),ctype[i])
    for i in range(len(cunit)): hdu.header.update('CUNIT'+str(i+1),cunit[i])
    hdu.header.update('BSCALE',beam_info[3])
    hdu.header.update('BZERO',beam_info[4])
    hdu.header.update('BUNIT',beam_info[5])
    if ((cunit[0].strip()).upper()=='DEGREE'):
        hdu.header.update('BMAJ',arcsec2deg(beam_info[0]))
        hdu.header.update('BMIN',arcsec2deg(beam_info[1]))
    if ((cunit[0].strip()).upper()=='ARCSEC'):
        hdu.header.update('BMAJ',beam_info[0])
        hdu.header.update('BMIN',beam_info[1])
    hdu.header.update('BPA',beam_info[2])
    hdu.header.update('EPOCH',2000.0)
    hdu.header.update('RESTFREQ',constant("nu0_HI")*1e6)

def write_map_to_fits(array,hdr,beam_info,filename):
    os.popen("rm -f "+filename)
    hdu=pyfits.PrimaryHDU(array)
    write_fits_header(hdu,hdr,beam_info)
    hdu.writeto(filename)

def image_size(window,pixelsize):
#    Nx=in_pixel(window[1],Xref,pixelsize)-in_pixel(window[0],Xref,pixelsize)+1
#    Ny=in_pixel(window[3],Yref,pixelsize)-in_pixel(window[2],Yref,pixelsize)+1
    Nx=in_pixel(window[1],Xref,pixelsize)-in_pixel(window[0],Xref,pixelsize)
    Ny=in_pixel(window[3],Yref,pixelsize)-in_pixel(window[2],Yref,pixelsize)
    if (Nx==0):Nx=1
    if (Ny==0):Ny=1
    return(Nx,Ny)

def in_map(ra,dec,z,major_axis,line_width,window,beam_margin,nu0,freq_info): # CHECKS IF A GALAXY HAS A CHANCE OF BEING INSIDE MAPPED VOLUME
    # LINE WIDTH GIVEN IN km/s. HIGHER LEVEL ROUTINES (SAX_map_routines.py) MUST DEAL WITH WHAT LINE WIDTH IS APPROPRIATE
    # COMPUTE REDSHIFT EXTENT OF GALAXY
    v0=redshift2velo(z)
    vmax=v0+0.5*line_width
    vmin=v0-0.5*line_width
    nu1=velo2freq(vmin,nu0)
    nu2=velo2freq(vmax,nu0)
    galaxy_numin=numpy.min(numpy.array([nu1,nu2]))
    galaxy_numax=numpy.max(numpy.array([nu1,nu2]))    
    numin=(freq_info[0]-0.5*freq_info[1])*1e3
    numax=(freq_info[0]+freq_info[1]*float(freq_info[2]-0.5))*1e3
    return(not((ra+major_axis+beam_margin<window[0]) or (ra-major_axis-beam_margin>window[1]) or (dec+major_axis+beam_margin<window[2]) or (dec-major_axis-beam_margin>window[3]) or (galaxy_numax<numin) or (galaxy_numin>numax)))


def display_formatted_info(galaxy_info,structure):
    for i in range(len(galaxy_info)):
        print structure[i],galaxy_info[i]

#### ADDING CONTINUOUS 2D FIELD ONTO MAP [version 1 : must have same size, adds same field to all frequencies / total intensity map only]

def read_file(file):
    hdulist=pyfits.open(file)
    return(hdulist[0])

def stretch_map(data,Nx_final,Ny_final):
    # Applies to both square and non-square 2D fields
    # Works both for stretching and squeezing
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    X=(grid(Nx_final)/float(Nx_final-1))*float(Nx-1)
    Y=(grid(Ny_final)/float(Ny_final-1))*float(Ny-1)
    X.resize(Nx_final,1)
    ivals=numpy.transpose(numpy.tile(X,(1,Ny_final)))
    jvals=numpy.transpose(numpy.tile(Y,(Nx_final,1)))
    coords = numpy.array([jvals, ivals])
    result = scipy.ndimage.map_coordinates(data,coords)
#    result=result*(total(numpy.array(data))/total(numpy.array(result))) # HAD TO REMOVE THAT FOR STRETCH_CUBE TO WORK.
    return(result)

def stretch_cube(data,Nx_final,Ny_final,Nfreqs_final):
    # Applies to both square and non-square PPV fields
    # Works both for stretching and squeezing
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]
    tmp=numpy.zeros((Nfreqs,Ny_final,Nx_final),dtype=data_type)
    t0=time.time()
    for ifreq in range(Nfreqs):
        slice=numpy.zeros((Ny,Nx),dtype=data_type)
        slice[:][:]=data[ifreq][:][:] # Watch out if polar axis is in
        tmp_slice=stretch_map(slice,Nx_final,Ny_final)
        tmp[ifreq][:][:]=tmp_slice[:][:]
    if (Nfreqs_final!=Nfreqs):
        result=numpy.zeros((Nfreqs_final,Ny_final,Nx_final),dtype=data_type)
        old_Z=(grid(Nfreqs)/float(Nfreqs-1))
        new_Z=(grid(Nfreqs_final)/float(Nfreqs_final-1))
        for i in range(Nx_final):
            for j in range(Ny_final):
                spectrum=numpy.zeros((Nfreqs),dtype=data_type)
                for ifreq in range(Nfreqs):
                    spectrum[ifreq]=tmp[ifreq][j][i]
                tck=scipy.interpolate.splrep(old_Z,spectrum)
                new_spectrum=scipy.interpolate.splev(new_Z,tck,der=0)
                for ifreq in range(Nfreqs_final):
                    result[ifreq][j][i]=new_spectrum[ifreq]
    else:
        result=tmp
    t1=time.time()
    return(result)

def add_field(field,map,map_parameters,beam_info,scale_factor):
    result=numpy.zeros(map.shape,dtype=data_type)        
    if (len(map.shape)==4): # MEANS POLARIZATION AXIS IS IN
        for i_f in range(map.shape[1]):
            result[0][i_f][:][:]=map[0][i_f][:][:]+scale_factor*field[:][:]
    if (len(map.shape)==3): # MEANS POLARIZATION AXIS IS NOT IN
        for i_f in range(map.shape[0]):
            result[i_f][:][:]=map[i_f][:][:]+scale_factor*field[:][:]
    return(result)

def revert_frequency_axis_in_template(cube):
    Nfreqs=cube.shape[0]
    result=numpy.zeros(cube.shape,dtype=data_type)
    slice=numpy.zeros((cube.shape[1],cube.shape[2]),dtype=data_type)
    for ifreq in range(cube.shape[0]):
        slice[:][:]=cube[ifreq][:][:]
        result[Nfreqs-1-ifreq][:][:]=slice[:][:]
    return(result)

def cut_zeros(data):
    eps=0.000000000001 # everything under 1e-12 is set to zero
    z=numpy.where(data<eps)  
    if (len(z[0])>0):        
        for k in range(len(z[0])):
            data[z[0][k]][z[1][k]][z[2][k]]=0.0
    return(data)

def rotate_map(data,angle):
    # Rotates a 2D map, clockwise, of an angle specified in degrees
    # Total of array 'almost' conserved. Should be corrected afterwards
    result=scipy.ndimage.rotate(data,angle,order=1,reshape=False)
    return(result)

def rotate_cube(data,angle):
    # Rotates a 3D cube around z-axis, clockwise, of an angle specified in degrees
    # Total of array 'almost' conserved. Should be corrected afterwards -> INCLUDED NOW (01/03/2011)
    Nfreqs=data.shape[0]
#    print "overall before rotation",data.sum()
#    print "center plane before rotation",data[Nfreqs/2,:,:].sum()
    result=scipy.ndimage.rotate(data,angle,axes=(1,2),order=1,reshape=False) # WATCH OUT IF POLAR AXIS IS INCLUDED !
    for i in range(Nfreqs):
        if (result[i,:,:].sum()!=0.0):result[i,:,:]*=(data[i,:,:].sum()/result[i,:,:].sum())
#    print "overall after rotation",result.sum()
#    print "center plane after rotation",result[Nfreqs/2,:,:].sum()
    return(result)

def upsize_map(data,Nx_final,Ny_final):
    # Applies to both square and non-square 2D fields
    # Works both for stretching and squeezing
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    X=(grid(Nx_final)/float(Nx_final-1))*float(Nx-1)
    Y=(grid(Ny_final)/float(Ny_final-1))*float(Ny-1)    
    X.resize(Nx_final,1)
    ivals=numpy.transpose(numpy.tile(X,(1,Ny_final)))
    jvals=numpy.transpose(numpy.tile(Y,(Nx_final,1)))
    coords = numpy.array([jvals, ivals])
    result = scipy.ndimage.map_coordinates(data,coords,order=1,mode='nearest')
    return(result)

def spatial_upsize_cube(data,Nx_final,Ny_final):
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]
    result=numpy.zeros((Nfreqs,Ny_final,Nx_final),dtype=data_type)
    slice=numpy.zeros((Ny,Nx),dtype=data_type)
    zero_result_slice=numpy.zeros((Ny_final,Nx_final),dtype=data_type)
    for ifreq in range(Nfreqs):
        slice[:][:]=data[ifreq][:][:] # Watch out if polar axis is in
        if (numpy.max(slice)>0):
            result_slice=upsize_map(slice,Nx_final,Ny_final)
        else:
            result_slice=zero_result_slice
        result[ifreq][:][:]=result_slice[:][:]
    return(result)

def shift_map(data,coords):
    result = scipy.ndimage.map_coordinates(data,coords,order=1,mode='nearest')
    return(result)

def spatial_shift_cube(data,dx,dy):
    # dx and dy in fraction of a pixel from center of central pixel
#    print data.sum()
    result=scipy.ndimage.shift(data,[0,dy,dx],order=1,mode='nearest')
#    print result.sum()
    return(result)

def rescaled_map_size(ratio,N):
    q=rescaled_map_halfsize(ratio,N)
    return(2*q+1)

def rescaled_map_halfsize(ratio,N):
    p=N/2
    q=int(math.ceil((1.0/ratio)*(p+0.5)-0.5))
    return(q)

def spatial_pixel_mapping(ra_vals,dec_vals,Xref,Yref,template_pixelsize,pixelsize):
    result=[]
    Nx=len(ra_vals)    
    Ny=len(dec_vals)    
    x_high=in_pixel(ra_vals[Nx-1]+0.5*template_pixelsize,Xref,pixelsize)
    x_low=in_pixel(ra_vals[0]-0.5*template_pixelsize,Xref,pixelsize)
    x_center=in_pixel(ra_vals[Nx/2],Xref,pixelsize)
    # MAKE IT AN ODD LENGTH MAPPING WITH CENTRAL PIXEL HOLDING CENTER VALUE OF ra_val
    if(x_high-x_center>x_center-x_low):
        difference=x_high+x_low-2*x_center
        x_low-=difference
    if(x_high-x_center<x_center-x_low):
        difference=2*x_center-x_high-x_low
        x_high+=difference
    y_high=in_pixel(dec_vals[Nx-1]+0.5*template_pixelsize,Xref,pixelsize)
    y_low=in_pixel(dec_vals[0]-0.5*template_pixelsize,Xref,pixelsize)
    y_center=in_pixel(dec_vals[Nx/2],Xref,pixelsize)
#    print y_low,y_high
    # MAKE IT AN ODD LENGTH MAPPING WITH CENTRAL PIXEL HOLDING CENTER VALUE OF dec_val
    if(y_high-y_center>y_center-y_low):
        difference=y_high+y_low-2*y_center
        y_low-=difference
    if(y_high-y_center<y_center-y_low):
        difference=2*y_center-y_high-y_low
        y_high+=difference
    # MAKE IT AN EQUAL LENGTH MAPPING IN X AND Y
    if (x_high-x_low+1>y_high-y_low+1):
        difference=(x_high-x_low)-(y_high-y_low)
        y_low-=(difference/2)
        y_high+=(difference/2)
    if (x_high-x_low+1<y_high-y_low+1):
        difference=(y_high-y_low)-(x_high-x_low)
        x_low-=(difference/2)
        x_high+=(difference/2)
    N_final=x_high-x_low+1
#    print y_low,y_high
    for i in range(N_final):
        ix=x_low+i
        iy=y_low+i
        x_indices=[]
        y_indices=[]
        x_weights=[]
        y_weights=[]
        low_x=Xref+pixelsize*(float(ix)-0.5)
        high_x=Xref+pixelsize*(float(ix)+0.5)
        low_y=Yref+pixelsize*(float(iy)-0.5)
        high_y=Yref+pixelsize*(float(iy)+0.5)
        for io in range(Nx):
            out_condition=((ra_vals[io]-0.5*template_pixelsize)>high_x)or((ra_vals[io]+0.5*template_pixelsize)<low_x)
            if not(out_condition):            
                low_cond=((ra_vals[io]-0.5*template_pixelsize)>=low_x) # TRUE IF ORIGINAL PIXEL'S LOWER BOUND IS ABOVE NEW PIXEL'S LOWER BOUND
                hi_cond=((ra_vals[io]+0.5*template_pixelsize)<=high_x) # TRUE IF ORIGINAL PIXEL'S HIGHER BOUND IS BELOW NEW PIXEL'S HIGHER BOUND
                if (hi_cond)and(low_cond):weight=1.0
                elif (hi_cond)and(not(low_cond)): weight=(ra_vals[io]+0.5*template_pixelsize-low_x)/template_pixelsize
                elif (low_cond)and(not(hi_cond)): weight=(high_x-(ra_vals[io]-0.5*template_pixelsize))/template_pixelsize
                else:weight=0.0
                x_indices.append(io)
                x_weights.append(weight)
        for io in range(Ny):
            out_condition=((dec_vals[io]-0.5*template_pixelsize)>high_y)or((dec_vals[io]+0.5*template_pixelsize)<low_y)
            if not(out_condition):            
                low_cond=((dec_vals[io]-0.5*template_pixelsize)>=low_y) # TRUE IF ORIGINAL PIXEL'S LOWER BOUND IS ABOVE NEW PIXEL'S LOWER BOUND
                hi_cond=((dec_vals[io]+0.5*template_pixelsize)<=high_y) # TRUE IF ORIGINAL PIXEL'S HIGHER BOUND IS BELOW NEW PIXEL'S HIGHER BOUND
                if (hi_cond)and(low_cond):weight=1.0
                elif (hi_cond)and(not(low_cond)): weight=(dec_vals[io]+0.5*template_pixelsize-low_y)/template_pixelsize
                elif (low_cond)and(not(hi_cond)): weight=(high_y-(dec_vals[io]-0.5*template_pixelsize))/template_pixelsize
                else:weight=0.0
                y_indices.append(io)
                y_weights.append(weight)
        result.append([(numpy.array(x_indices),numpy.array(x_weights)),(numpy.array(y_indices),numpy.array(y_weights))])
    return(result)
                
def downsizing_mapping(ratio,N):
    # N MUST BE AN ODD NUMBER
    q=rescaled_map_halfsize(ratio,N)
    q_grid=grid(q+1)
    mapping=[]
    i=0
    w=0
    for q_val in q_grid:
        jp=int(math.floor((q_val+0.5)*ratio+0.5))
        jm=int(math.floor((q_val-0.5)*ratio+0.5))
        rp=ratio*(q_val+0.5)-jp+0.5
        rm=jm+0.5-ratio*(q_val-0.5)
        p_pave=range(numpy.max([jm+N/2,0]),numpy.min([jp+1+N/2,N]))
        n_pave=range(numpy.max([-jp+N/2,0]),numpy.min([-jm+1+N/2,N]))
        p_weights=numpy.ones((len(p_pave)),dtype=data_type)
        p_weights[0]=rm
        if (jp+1+N/2<N+1): p_weights[len(p_weights)-1]=rp
        mapping.append((numpy.array(p_pave),p_weights))
        w+=p_weights.sum()
        if (i>0):
            n_weights=numpy.ones((len(n_pave)),dtype=data_type)
            for x in range(len(n_pave)):n_weights[x]=p_weights[len(n_pave)-1-x]
            mapping.insert(0,(numpy.array(n_pave),n_weights))
            w+=n_weights.sum()
        i+=1
    return(mapping)

def downsize_map(data,mapping):
    out_sz=len(mapping)
    result=numpy.zeros((out_sz,out_sz),dtype=data_type)
    for i in range(out_sz):
        mi=mapping[i]
        mi_indices=mi[0]
        mi_weights=mi[1]
        lmi=len(mi_indices)            
        for j in range(out_sz):
            mj=mapping[j]
            mj_indices=mj[0]
            mj_weights=mj[1]
            lmj=len(mj_indices)                
            ij=data[numpy.min(mi_indices):numpy.max(mi_indices)+1,numpy.min(mj_indices):numpy.max(mj_indices)+1]
            w=numpy.outer(mi_weights,mj_weights)
            result[i,j]=(ij*w).sum()
    return(result)

def spatial_downsize_cube(data,spatial_mapping):
    out_sz=len(spatial_mapping)
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]
    result=numpy.zeros((Nfreqs,out_sz,out_sz),dtype=numpy.float64)    
    result_1d=numpy.zeros((Nfreqs),dtype=numpy.float64)  
    if (out_sz==1):# POINTLIKE SOURCE
        weighting(Nx,Ny,Nfreqs,0,Nx-1,0,Ny-1,1.0,1.0,1.0,1.0,data,result_1d) 
        result[:,0,0]=result_1d[:]        
    else:
        for i in range(out_sz):
            mi=spatial_mapping[i][0]
            #print mi
            mi_indices=mi[0]
            mi_weights=mi[1]
            lmi=len(mi_indices)                     
            for j in range(out_sz):
                mj=spatial_mapping[j][1]
                mj_indices=mj[0]
                mj_weights=mj[1]
                lmj=len(mj_indices)      
                if (lmi>0)and(lmj>0):
                    weighting(Nx,Ny,Nfreqs,mi[0][0],mi[0][lmi-1],mj[0][0],mj[0][lmj-1],mi[1][0],mi[1][lmi-1],mj[1][0],mj[1][lmj-1],data,result_1d) 
                    result[:,j,i]=result_1d[:]
                else:
                    result[:,j,i]=0.0
    return(result)

def velocity_channel_mapping(template_velocities,channel_boundary_velocities):
#    print template_velocities
#    print channel_boundary_velocities
    result=[]
    Nfreqs=len(template_velocities)
    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Third-axis size of a pixel in the template (km/s)
    for i in range(len(channel_boundary_velocities)-1):
        indices=[]
        weights=[]
        for io in range(len(template_velocities)):
            out_condition=((template_velocities[io]-dv/2.0)>channel_boundary_velocities[i+1])or((template_velocities[io]+dv/2.0)<channel_boundary_velocities[i])
            if not(out_condition):
                low_cond=((template_velocities[io]-dv/2.0)>=channel_boundary_velocities[i]) # TRUE IF ORIGINAL PIXEL'S LOWER BOUND IS ABOVE NEW PIXEL'S LOWER BOUND
                hi_cond=((template_velocities[io]+dv/2.0)<=channel_boundary_velocities[i+1]) # TRUE IF ORIGINAL PIXEL'S HIGHER BOUND IS BELOW NEW PIXEL'S HIGHER BOUND
                if (hi_cond)and(low_cond):weight=1.0
                elif (hi_cond)and(not(low_cond)): weight=(template_velocities[io]+dv/2.0-channel_boundary_velocities[i])/dv
                elif (low_cond)and(not(hi_cond)): weight=(channel_boundary_velocities[i+1]-(template_velocities[io]-dv/2.0))/dv
                else:weight=0.0
                indices.append(io)
                weights.append(weight)
        result.append((numpy.array(indices),numpy.array(weights)))
#    print result
    return(result)

def velocity_downsize_cube(data,velocity_mapping,template_velocities,channel_boundary_velocities):
    out_sz=len(velocity_mapping)
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]
#    print Nfreqs
    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Third-axis size of a pixel in the template (km/s)
    result=numpy.zeros((out_sz,Ny,Nx),dtype=data_type)
    norm=numpy.zeros((Ny,Nx),dtype=data_type)
#    print Nx,Ny
    for k in range(out_sz):
        ubv=channel_boundary_velocities[k+1]
        lbv=channel_boundary_velocities[k]
        cw=ubv-lbv
        m=velocity_mapping[k]
#        print m
        indices=m[0]
        weights=m[1]   
        lm=len(indices)
        for k_tmp in range(lm):
#            result[k][:][:]+=(data[indices[k_tmp]][:][:]*weights[k_tmp]/weights.sum())
            result[k][:][:]+=(data[indices[k_tmp]][:][:]*weights[k_tmp]*dv/cw)
    return(result)


def velocity_upsize_cube(data,template_velocities,channel_boundary_velocities):
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]
    Nfreqs_final=len(channel_boundary_velocities)-1
#    print Nfreqs
    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1)
    coordinates=[]
    for i in range(Nfreqs_final):
        cv=0.5*(channel_boundary_velocities[i]+channel_boundary_velocities[i+1]) # Velocity at the center of the channel (km/s)
        pix=in_pixel(cv,template_velocities[0],dv) # Gives the pixel number along the template's third axis in which that velocity falls 
        pixval=pix*dv+template_velocities[0] # Gives the velocity associated with that pixel in the template (km/s)
        coord=pix+(cv-pixval)/dv # Gives the coordinate of the channel pixel in units of the template pixels
        coordinates.append(coord)
    result=numpy.zeros((Nfreqs_final,Ny,Nx),dtype=data_type)
    zero_result_los=numpy.zeros((Nfreqs_final),dtype=data_type)
    los=numpy.zeros((Nfreqs),dtype=data_type)
#    losint=numpy.zeros((Nfreqs),dtype=data_type)
#    for k in range(Nfreqs):losint[k]=(data[k,:,:].sum())
    for i in range(Nx):
        for j in range(Ny):
            los[:]=data[:,j,i]
            if (numpy.max(los)>0):
                result_los=scipy.ndimage.map_coordinates(los,numpy.array([coordinates]),order=1,mode='nearest')
            else:
                result_los=zero_result_los
            result[:,j,i]=result_los[:]
    return(result)

def apply_cube_transform(data,spatial_ratio,angle,template_velocities,channel_boundary_velocities,ra_vals,dec_vals,pixelsize,template_pixelsize,hash,id):
    # SAFEGUARD NULL RESULT FOR TEST OF RETURN VALUE
    result=0
    # GET SIZE OF TEMPLATE CUBE Nx,Ny,Nfreqs
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nfreqs=data.shape[len(data.shape)-3]

    if (hash!=""): # THIS MEANS WE'RE GOING TO USE THE POSSIBILITY OF REUSING SPATIALLY MODIFIED TEMPLATES 
        file=SCRATCH_DIR+hash+"/"+id+".fits"
        if (os.path.isfile(file)): # THERE IS SUCH A FILE
#            print "I have found "+hash+"/"+id+".fits"
            hdu_in=pyfits.open(file)
            data=(hdu_in[0]).data
            hdu_in.close()
        else: # PERFORM SPATIAL MODIFICATIONS
            # CHECK SPATIAL RATIO
            if (spatial_ratio>1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS BIGGER THAN THE REQUESTED SIZE
                spatial_mapping=spatial_pixel_mapping(ra_vals,dec_vals,Xref,Yref,template_pixelsize,pixelsize)
                N_final=len(spatial_mapping)
                if (N_final>1)and(angle!=0): # PERFORM ROTATION (SHIFT TAKEN CARE OF IN SPATIAL MAPPING AND DOWNSIZING)
                    originalsum=data.sum()
                    data=rotate_cube(data,angle)
                    data*=(originalsum/(data.sum()))
                data=spatial_downsize_cube(data,spatial_mapping)
                if (N_final==1): # Need to put a zero-valued border around the central, single pixel
                    tmp1=numpy.zeros((Nfreqs,N_final+2,N_final+2),dtype=data_type)
                    tmp1[0:Nfreqs,1,1]=data[0:Nfreqs,0,0]
                    data=tmp1
            else:  # THE TEMPLATE CUBE'S SPATIAL SIZE IS SMALLER THAN THE REQUESTED SIZE - REQUIRES SOME CORRECTION TO KEEP THE TOTAL FLUX        
                # COMPUTE RESCALED SPATIAL SIZES 
                Nx_final=rescaled_map_size(spatial_ratio,Nx)
                Ny_final=rescaled_map_size(spatial_ratio,Ny) 
                # PERFORM ROTATION
                originalsum=data.sum()
                data=rotate_cube(data,angle)
                # PERFORM UPSIZING
                data=spatial_upsize_cube(data,Nx_final,Ny_final)*spatial_ratio*spatial_ratio
                data*=(originalsum/(data.sum()))
                # WRITE OUT TO FITS FOR REUSE
                # BUT FIRST TEST SOME OTHER JOB HAS NOT WRITTEN IT OUT IN THE MEANTIME
#            print "I am making "+hash+"/"+id+".fits"
                if not(os.path.isfile(file)): hdu.writeto(file)
#        print data.shape
    else: # WE DO NOT WANT TO REUSE SPATIALLY MODIFIED TEMPLATES             
        # CHECK SPATIAL RATIO
        if (spatial_ratio>1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS BIGGER THAN THE REQUESTED SIZE
            spatial_mapping=spatial_pixel_mapping(ra_vals,dec_vals,Xref,Yref,template_pixelsize,pixelsize)
            N_final=len(spatial_mapping)
            if (N_final>1)and(angle!=0): # PERFORM ROTATION (SHIFT TAKEN CARE OF IN SPATIAL MAPPING AND DOWNSIZING)
                originalsum=data.sum()
                data=rotate_cube(data,angle)
                data*=(originalsum/(data.sum()))
            data=spatial_downsize_cube(data,spatial_mapping)
            if (N_final==1): # Need to put a zero-valued border around the central, single pixel
                tmp1=numpy.zeros((Nfreqs,N_final+2,N_final+2),dtype=data_type)
                tmp1[0:Nfreqs,1,1]=data[0:Nfreqs,0,0]
                data=tmp1
        else:  # THE TEMPLATE CUBE'S SPATIAL SIZE IS SMALLER THAN THE REQUESTED SIZE - REQUIRES SOME CORRECTION TO KEEP THE TOTAL FLUX        
            # COMPUTE RESCALED SPATIAL SIZES 
            Nx_final=rescaled_map_size(spatial_ratio,Nx)
            Ny_final=rescaled_map_size(spatial_ratio,Ny) 
            # PERFORM ROTATION
            originalsum=data.sum()
            data=rotate_cube(data,angle)
            # PERFORM UPSIZING
            data=spatial_upsize_cube(data,Nx_final,Ny_final)*spatial_ratio*spatial_ratio
            data*=(originalsum/(data.sum()))

    # CHECK VELOCITY SCALING 

# FLAWED VERSION : COMPARE WIDTHS WHERE THERE'S SIGNAL !
#    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Velocity width of channels in the template cube (km/s)
#    min_out_dv=channel_boundary_velocities[len(channel_boundary_velocities)-1]-channel_boundary_velocities[len(channel_boundary_velocities)-2] # Max velocity width of channels in output cube (km/s)
#    max_out_dv=channel_boundary_velocities[1]-channel_boundary_velocities[0] # Maximum velocity width of channels in output cube (km/s)
#    print dv,min_out_dv,channel_boundary_velocities
#    if (min_out_dv>dv): # THE TEMPLATE CUBE'S VELOCITY SIZE IS BIGGER THAN THE REQUESTED SIZE        
#        velocity_mapping=velocity_channel_mapping(template_velocities,channel_boundary_velocities)
#        data=velocity_downsize_cube(data,velocity_mapping,template_velocities,channel_boundary_velocities)
#    else:
#        data=velocity_upsize_cube(data,template_velocities,channel_boundary_velocities)
# BELOW IS CORRECTED VERSION
    velocity_mapping=velocity_channel_mapping(template_velocities,channel_boundary_velocities)
    nmax_indices=numpy.max([len(velocity_mapping[k][0]) for k in range(len(velocity_mapping))])
    nmin_indices=numpy.min([len(velocity_mapping[k][0]) for k in range(len(velocity_mapping))])
#    print nmin_indices,nmax_indices
    signal_nindices=[]
    for k in range(len(velocity_mapping)):
        indices=velocity_mapping[k][0]
        count=False
        for index in indices:
            if ((numpy.min(data[index,:,:])!=0.0)or(numpy.max(data[index,:,:])!=0.0)):count=True
        if (count):signal_nindices.append(len(indices))
#    print signal_nindices
    if (len(signal_nindices)>0):
        if (numpy.max(signal_nindices)>2):
#            print "downsizing"
            data=velocity_downsize_cube(data,velocity_mapping,template_velocities,channel_boundary_velocities)
        else:
#            print "upsizing"
            data=velocity_upsize_cube(data,template_velocities,channel_boundary_velocities)    
    return(data)


def apply_map_transform(data,spatial_ratio,angle,dx,dy):
    result=0
    Nx=data.shape[len(data.shape)-1]
    Ny=data.shape[len(data.shape)-2]
    Nx_final=rescaled_map_size(spatial_ratio,Nx)
    Ny_final=rescaled_map_size(spatial_ratio,Ny)
    if (spatial_ratio>1):
        spatial_mapping=downsizing_mapping(spatial_ratio,Nx)
        if ((Nx_final>1)and(Ny_final>1)):
            tmp1=downsize_map(data,spatial_mapping)
        else: # Need to put a zero-valued border around the central, single pixel
            tmp0=downsize_map(data,spatial_mapping)
            tmp1=numpy.zeros((Ny_final+2,Nx_final+2),dtype=data_type)
            tmp1[1,1]=tmp0[0,0]
    elif (spatial_ratio<1):
        tmp1=upsize_map(data,Nx_final,Ny_final)
    else:
        tmp1=data
    if (angle!=0):tmp4=rotate_map(tmp1,angle)
    else:tmp4=tmp1
    if ((dx!=0)or(dy!=0)):result=shift_map(tmp4,dx,dy)
    else:result=tmp4
    return(result)

#def old_apply_cube_transform(data,spatial_ratio,angle,dx,dy,template_velocities,channel_boundary_velocities):
#    # SAFEGUARD NULL RESULT FOR TEST OF RETURN VALUE
#    result=0
#    # GET SIZE OF TEMPLATE CUBE Nx,Ny,Nfreqs
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    # COMPUTE RESCALED SPATIAL SIZES 
#    Nx_final=rescaled_map_size(spatial_ratio,Nx)
#    Ny_final=rescaled_map_size(spatial_ratio,Ny) 
#    # FIRST PERFORM ROTATION IF NECESSARY (COMPARE SOURCE POSITION AND SIZE WITH OUTPUT PIXEL)
#    if (angle!=0):data=rotate_cube(data,angle)
#    if ((dx!=0)or(dy!=0)):data=spatial_shift_cube(data,dx,dy)
#    # CHECK SPATIAL RATIO
#    if (spatial_ratio>1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS BIGGER THAN THE REQUESTED SIZE
#        spatial_mapping=downsizing_mapping(spatial_ratio,Nx)
#        data=spatial_downsize_cube(data,spatial_mapping)
#        if ((Nx_final==1)or(Ny_final==1)): # Need to put a zero-valued border around the central, single pixel
#            tmp1=numpy.zeros((Nfreqs,Ny_final+2,Nx_final+2),dtype=data_type)
#            tmp1[0:Nfreqs,1,1]=data[0:Nfreqs,0,0]
#            data=tmp1
#    elif (spatial_ratio<1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS SMALLER THAN THE REQUESTED SIZE - REQUIRES SOME CORRECTION TO KEEP THE TOTAL FLUX
#        before=data.sum()
#        data=spatial_upsize_cube(data,Nx_final,Ny_final)*spatial_ratio*spatial_ratio
#        factor=(before/data.sum())
#        data*=factor
#    # CHECK VELOCITY SCALING
#    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Velocity width of channels in the template cube (km/s)
#    min_out_dv=channel_boundary_velocities[len(channel_boundary_velocities)-1]-channel_boundary_velocities[len(channel_boundary_velocities)-2] # Max velocity width of channels in output cube (km/s)
#    max_out_dv=channel_boundary_velocities[1]-channel_boundary_velocities[0] # Maximum velocity width of channels in output cube (km/s)
#    if (min_out_dv>dv): # THE TEMPLATE CUBE'S VELOCITY SIZE IS BIGGER THAN THE REQUESTED SIZE        
#        velocity_mapping=velocity_channel_mapping(template_velocities,channel_boundary_velocities)
#        data=velocity_downsize_cube(data,velocity_mapping)
#    else:
#        data=velocity_upsize_cube(data,template_velocities,channel_boundary_velocities)
#    return(data)

#def frequency_downsize_cube(data,frequency_mapping):
#    out_sz=len(frequency_mapping)
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    result=numpy.zeros((out_sz,Ny,Nx),dtype=data_type)
#    for i in range(out_sz):
#        m=frequency_mapping[i]
#        indices=m[0]
#        weights=m[1]   
#        lm=len(indices)
#        for k in range(lm):
#            result[i][:][:]+=(data[indices[k]][:][:]*weights[k])
#    return(result)


#def frequency_upsize_cube(data,Nfreqs_final):
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    result=numpy.zeros((Nfreqs_final,Ny,Nx),dtype=data_type)
#    Z=(grid(Nfreqs_final)-Nfreqs_final/2)*(float(Nfreqs)/float(Nfreqs_final))+Nfreqs/2
#    zero_result_los=numpy.zeros((Nfreqs_final),dtype=data_type)
#    for i in range(Nx):
#        for j in range(Ny):
#            los=numpy.zeros((Nfreqs),dtype=data_type)
#            los[:]=data[:,j,i]
#            if (numpy.max(los)>0):
#                result_los=scipy.ndimage.map_coordinates(los,numpy.array([Z]),order=1,mode='nearest')
#            else:
#                result_los=zero_result_los
#            result[:,j,i]=result_los[:]
#    return(result)

#def frequency_shift_cube(data,dz):
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    result=numpy.zeros((Nfreqs,Ny,Nx),dtype=data_type)
#    Z=grid(Nfreqs)-dz
#    for i in range(Nx):
#        for j in range(Ny):
#            los=numpy.zeros((Nfreqs),dtype=data_type)
#            los[:]=data[:,j,i]
#            if (numpy.max(los)>0):
#                result_los=scipy.ndimage.map_coordinates(los,numpy.array([Z]),order=1,mode='nearest')
#            else:
#                result_los=los
#            result[:,j,i]=result_los[:]
#    return(result)
#
#def frequency_upsize_and_shift_cube(data,Nfreqs_final,dz):
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    result=numpy.zeros((Nfreqs_final,Ny,Nx),dtype=data_type)
#    Z=(grid(Nfreqs_final)-Nfreqs_final/2)*(float(Nfreqs)/float(Nfreqs_final))+Nfreqs/2-dz
#    zero_result_los=numpy.zeros((Nfreqs_final),dtype=data_type)
#    los=numpy.zeros((Nfreqs),dtype=data_type)
#    for i in range(Nx):
#        for j in range(Ny):            
#            los[:]=data[:,j,i]
#            if (numpy.max(los)>0):
#                result_los=scipy.ndimage.map_coordinates(los,numpy.array([Z]),order=1,mode='nearest')
#            else:
#                result_los=zero_result_los
#            result[:,j,i]=result_los[:]
#    return(result)



#def new_apply_cube_transform(data,spatial_ratio,angle,dx,dy,template_velocities,channel_boundary_velocities,apply_rotate_and_shift):
#    # SAFEGUARD NULL RESULT FOR TEST OF RETURN VALUE
#    result=0
#    # GET SIZE OF TEMPLATE CUBE Nx,Ny,Nfreqs
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    # COMPUTE RESCALED SPATIAL SIZES 
#    Nx_final=rescaled_map_size(spatial_ratio,Nx)
#    Ny_final=rescaled_map_size(spatial_ratio,Ny) 
#    # CHECK SPATIAL RATIO
#    if (spatial_ratio>1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS BIGGER THAN THE REQUESTED SIZE
#        spatial_mapping=downsizing_mapping(spatial_ratio,Nx)
#        data=spatial_downsize_cube(data,spatial_mapping)
#        if ((Nx_final==1)or(Ny_final==1)): # Need to put a zero-valued border around the central, single pixel
#            tmp1=numpy.zeros((Nfreqs,Ny_final+2,Nx_final+2),dtype=data_type)
#            tmp1[0:Nfreqs,1,1]=data[0:Nfreqs,0,0]
#            data=tmp1
#    elif (spatial_ratio<1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS SMALLER THAN THE REQUESTED SIZE - REQUIRES SOME CORRECTION TO KEEP THE TOTAL FLUX
#        before=data.sum()
#        data=spatial_upsize_cube(data,Nx_final,Ny_final)*spatial_ratio*spatial_ratio
#        factor=(before/data.sum())
#        data*=factor
#    # CHECK VELOCITY SCALING
#    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Velocity width of channels in the template cube (km/s)
#    min_out_dv=channel_boundary_velocities[len(channel_boundary_velocities)-1]-channel_boundary_velocities[len(channel_boundary_velocities)-2] # Max velocity width of channels in output cube (km/s)
#    max_out_dv=channel_boundary_velocities[1]-channel_boundary_velocities[0] # Maximum velocity width of channels in output cube (km/s)
#    if (min_out_dv>dv): # THE TEMPLATE CUBE'S VELOCITY SIZE IS BIGGER THAN THE REQUESTED SIZE        
#        velocity_mapping=velocity_channel_mapping(template_velocities,channel_boundary_velocities)
#        data=velocity_downsize_cube(data,velocity_mapping)
#    else:
#        data=velocity_upsize_cube(data,template_velocities,channel_boundary_velocities)
#    # FIRST PERFORM ROTATION IF NECESSARY (COMPARE SOURCE POSITION AND SIZE WITH OUTPUT PIXEL)
#    if (apply_rotate_and_shift):
##        print Nx_final,Ny_final
#        originalsum=data.sum()
#        if (angle!=0):data=rotate_cube(data,angle)
#        if ((dx!=0)or(dy!=0)):data=spatial_shift_cube(data,dx,dy)
#        data*=(originalsum/(data.sum()))
#
#    return(data)


#def spatial_downsize_cube(data,spatial_mapping):
#    out_sz=len(spatial_mapping)
##    print out_sz
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#    result=numpy.zeros((Nfreqs,out_sz,out_sz),dtype=numpy.float64)    
#    result_1d=numpy.zeros((Nfreqs),dtype=numpy.float64)  
#    if (out_sz==1):# POINTLIKE SOURCE
#        weighting(Nx,Ny,Nfreqs,0,Nx-1,0,Ny-1,1.0,1.0,1.0,1.0,data,result_1d) 
#        result[:,0,0]=result_1d[:]        
#    else:
#        for i in range(out_sz):
#            mi=spatial_mapping[i]
#            mi_indices=mi[0]
#            mi_weights=mi[1]
#            lmi=len(mi_indices)                     
#            for j in range(out_sz):
#                mj=spatial_mapping[j]
#                mj_indices=mj[0]
#                mj_weights=mj[1]
#                lmj=len(mj_indices)      
#                weighting(Nx,Ny,Nfreqs,mi[0][0],mi[0][lmi-1],mj[0][0],mj[0][lmj-1],mi[1][0],mi[1][lmi-1],mj[1][0],mj[1][lmj-1],data,result_1d) 
#                result[:,j,i]=result_1d[:]
#    return(result)


#def apply_cube_transform(data,spatial_ratio,angle,dx,dy,template_velocities,channel_boundary_velocities):
#    # SAFEGUARD NULL RESULT FOR TEST OF RETURN VALUE
#    result=0
#    # GET SIZE OF TEMPLATE CUBE Nx,Ny,Nfreqs
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
#
#    # COMPUTE RESCALED SPATIAL SIZES 
#    Nx_final=rescaled_map_size(spatial_ratio,Nx)
#    Ny_final=rescaled_map_size(spatial_ratio,Ny) 
#
#    # FIRST PERFORM ROTATION IF NECESSARY (COMPARE SOURCE POSITION AND SIZE WITH OUTPUT PIXEL)
#    if (Nx_final>1)or(Ny_final>1):
#        originalsum=data.sum()
#        if (angle!=0):data=rotate_cube(data,angle)
#        if ((dx!=0)or(dy!=0)):data=spatial_shift_cube(data,dx,dy)
#        data*=(originalsum/(data.sum()))
#    # CHECK SPATIAL RATIO
#    if (spatial_ratio>1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS BIGGER THAN THE REQUESTED SIZE
#        spatial_mapping=downsizing_mapping(spatial_ratio,Nx)
#        data=spatial_downsize_cube(data,spatial_mapping)
#        if ((Nx_final==1)or(Ny_final==1)): # Need to put a zero-valued border around the central, single pixel
#            tmp1=numpy.zeros((Nfreqs,Ny_final+2,Nx_final+2),dtype=data_type)
#            tmp1[0:Nfreqs,1,1]=data[0:Nfreqs,0,0]
#            data=tmp1
#    elif (spatial_ratio<1): # THE TEMPLATE CUBE'S SPATIAL SIZE IS SMALLER THAN THE REQUESTED SIZE - REQUIRES SOME CORRECTION TO KEEP THE TOTAL FLUX
#        before=data.sum()
#        data=spatial_upsize_cube(data,Nx_final,Ny_final)*spatial_ratio*spatial_ratio
#        factor=(before/data.sum())
#        data*=factor
#    # CHECK VELOCITY SCALING
#    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Velocity width of channels in the template cube (km/s)
#    min_out_dv=channel_boundary_velocities[len(channel_boundary_velocities)-1]-channel_boundary_velocities[len(channel_boundary_velocities)-2] # Max velocity width of channels in output cube (km/s)
#    max_out_dv=channel_boundary_velocities[1]-channel_boundary_velocities[0] # Maximum velocity width of channels in output cube (km/s)
#    if (min_out_dv>dv): # THE TEMPLATE CUBE'S VELOCITY SIZE IS BIGGER THAN THE REQUESTED SIZE        
#        velocity_mapping=velocity_channel_mapping(template_velocities,channel_boundary_velocities)
#        data=velocity_downsize_cube(data,velocity_mapping)
#    else:
#        data=velocity_upsize_cube(data,template_velocities,channel_boundary_velocities)
#    return(data)



#def new_velocity_downsize_cube(data,velocity_mapping):
#    out_sz=len(velocity_mapping)
#    Nx=data.shape[len(data.shape)-1]
#    Ny=data.shape[len(data.shape)-2]
#    Nfreqs=data.shape[len(data.shape)-3]
##    dv=(template_velocities[Nfreqs-1]-template_velocities[0])/float(Nfreqs-1) # Third-axis size of a pixel in the template (km/s)
#    result=numpy.zeros((out_sz,Ny,Nx),dtype=data_type)
#    norm=numpy.zeros((Ny,Nx),dtype=data_type)
##    print Nx,Ny
#    for k in range(out_sz):
#        m=velocity_mapping[k]
#        indices=m[0]
#        weights=m[1]   
#        lm=len(indices)
#        for k_tmp in range(lm):
#            wsignal=numpy.where(data[indices[k_tmp]][:][:]!=0.0)
#            for w in range(len(wsignal[0])):
#                i=wsignal[0][w]
#                j=wsignal[1][w]
#                result[k][j][i]+=(data[indices[k_tmp]][j][i]*weights[k_tmp])
#                norm[j][i]+=(weights[k_tmp])
##        nonzero=numpy.where(norm>0.0)
##        print nonzero
##        for w in range(len(nonzero[0])):
##            print nonzero,nonzero[0][w],nonzero[1][w]
##            result[k][nonzero[1][w]][nonzero[0][w]]/=norm[nonzero[1][w]][nonzero[0][w]]
###            result[k][:][:]+=(data[indices[k_tmp]][:][:]*weights[k_tmp]/weights.sum())
#    return(result)

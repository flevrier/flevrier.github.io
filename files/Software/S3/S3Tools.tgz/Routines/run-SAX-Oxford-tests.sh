#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sax_tarfile="single-sax"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_ratio=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

window_20as="198.6236,218.6236,129.0536,149.0536" # 20" on each side, centered on the source position
window_5as="206.1236,211.1236,136.5536,141.5536" # 5" on each side, centered on the source position
window_1as="208.1236,209.1236,138.5536,139.5536" # 1" on each side, centered on the source position
window_400mas="208.4236,208.8236,138.8536,139.2536" # 0.4" on each side, centered on the source position

window_400mas_tl="208.6236,208.8236,139.0536,139.2536" # 'Top Left' subset of the 0.4" on each side window centered on the source position
window_400mas_tr="208.4236,208.6236,139.0536,139.2536" # 'Top Right' subset of the 0.4" on each side window centered on the source position
window_400mas_bl="208.6236,208.8236,138.8536,139.0536" # 'Bottom Left' subset of the 0.4" on each side window centered on the source position
window_400mas_br="208.4236,208.6236,138.8536,139.0536" # 'Bottom Right' subset of the 0.4" on each side window centered on the source position

window_300mas="208.4736,208.7736,138.9036,139.2036" # 0.3" on each side, centered on the source position
window_200mas="208.5236,208.7236,138.9536,139.1536" # 0.2" on each side, centered on the source position
window_200mas_positive_shift_10mas="208.5336,208.7336,138.9636,139.1636" # 0.2" on each side, with a positive 0.01" shift in X an Y with respect to source position
window_200mas_negative_shift_10mas="208.5136,208.7136,138.9436,139.1436" # 0.2" on each side, with a negative 0.01" shift in X an Y with respect to source position

freqrange_hi_1kHz="0.1330461931086369,0.000001,400" # 400 channels (1kHz) centered on HI central frequency
freqrange_hi_5kHz="0.1330461931086369,0.000005,80" # 80 channels (1kHz) centered on HI central frequency
freqrange_hi_20kHz="0.1330461931086369,0.00002,20" # 20 channels (1kHz) centered on HI central frequency
freqrange_hi_50kHz="0.1330461931086369,0.0001,8" # 8 channels (1kHz) centered on HI central frequency

freqrange_hi_1kHz_lowband="0.1330461931086369,0.000001,160" # 160 channels (1 kHz) on the lower band of the HI signal
freqrange_hi_1kHz_centerband="0.1332061931086369,0.000001,80" # 80 channels (1 kHz) on the lower band of the HI signal
freqrange_hi_1kHz_highband="0.1332861931086369,0.000001,160" # 160 channels (1 kHz) on the lower band of the HI signal

freqrange_co10_100kHz="10.7934235333737961,0.0001,400" # 400 channels (100 kHz) centered on CO(1-0) central frequency
freqrange_co10_400kHz="10.7934235333737961,0.0004,100" # 100 channels (400 MHz) centered on CO(1-0) central frequency
freqrange_co10_800kHz="10.7934235333737961,0.0008,50" # 50 channels (800 kHz) centered on CO(1-0) central frequency
freqrange_co10_4MHz="10.7934235333737961,0.004,10" # 10 channels (4 MHz) centered on CO(1-0) central frequency

freqrange_co21_200kHz="21.5868470667475922,0.0002,400" # 400 channels (200 kHz) centered on CO(2-1) central frequency
freqrange_co32_300kHz="32.3802706001213883,0.0003,400" # 400 channels (300 kHz) centered on CO(3-2) central frequency
freqrange_co43_400kHz="43.1736941334951843,0.0004,400" # 400 channels (400 kHz) centered on CO(4-3) central frequency
freqrange_co54_500kHz="53.9671176668689804,0.0005,400" # 400 channels (500 kHz) centered on CO(5-4) central frequency
freqrange_co65_600kHz="64.7605412002427765,0.0006,400" # 400 channels (600 kHz) centered on CO(6-5) central frequency
freqrange_co76_700kHz="75.5539647336165726,0.0007,400" # 400 channels (700 kHz) centered on CO(7-6) central frequency
freqrange_co87_800kHz="86.3473882669903687,0.0008,400" # 400 channels (800 kHz) centered on CO(8-7) central frequency
freqrange_co98_900kHz="97.1408118003641648,0.0009,400" # 400 channels (900 kHz) centered on CO(9-8) central frequency
freqrange_co109_1MHz="107.9342353337379608,0.001,400" # 400 channels (1 MHz) centered on CO(10-9) central frequency

freqrange_all="0.11,0.1,2000" # 2000 channels (100 MHz wide) starting at 110 MHz : total coverage is 10 MHz -> 200 GHz

echo '################################################################################################'
echo '# HI EMISSION FROM SPATIALLY UNRESOLVED SOURCE, VARYING SPECTRAL RESOLUTIONS, OXFORD TEMPLATES #'
echo '################################################################################################'

outfile="sax-unresolved-hi-50kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_50kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-20kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_20kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-5kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '############################################################################################################################'
echo '# HI EMISSION FROM SPATIALLY UNRESOLVED SOURCE, VARYING SPECTRAL RESOLUTIONS, OXFORD TEMPLATES, WITH GAUSSIAN BEAM APPLIED #'
echo '############################################################################################################################'

outfile="sax-unresolved-hi-50kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_50kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-20kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_20kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-5kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_5kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#########################################################################################################'
echo '# HI EMISSION FROM SOURCE WITH VARYING SPATIAL RESOLUTION, 5 kHz SPECTRAL RESOLUTIONS, OXFORD TEMPLATES #'
echo '#########################################################################################################'
outfile="sax-5mas-hi-5kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.005 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-15mas-hi-5kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.015 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-300microas-hi-5kHz-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.0003 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#####################################################################################################################################'
echo '# HI EMISSION FROM SOURCE WITH VARYING SPATIAL RESOLUTION, 5 kHz SPECTRAL RESOLUTIONS, OXFORD TEMPLATES, WITH GAUSSIAN BEAM APPLIED #'
echo '#####################################################################################################################################'
outfile="sax-5mas-hi-5kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.005 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-15mas-hi-5kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.03 --bmin=0.03 --bpa=0.0 --noise=0.0 --pixelsize=0.015 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Oxford-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.002 --bmin=0.002 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'


echo '################################################'
echo '# CO EMISSION FROM SPATIALLY UNRESOLVED SOURCE #'
echo '################################################'
# CO (1-0) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 100 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co10-100kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co10_100kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (1-0) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 400 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co10-400kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co10_400kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (1-0) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 800 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co10-800kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co10_800kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (1-0) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 4 MHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co10-4MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co10_4MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (2-1) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 200 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co21-200kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co21_200kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_2_1 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (3-2) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 300 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co32-300kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co32_300kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_3_2 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (4-3) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 400 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co43-400kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co43_400kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_4_3 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (5-4) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 500 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co54-500kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co54_500kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_5_4 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (6-5) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 600 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co65-600kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co65_600kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_6_5 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (7-6) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 700 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co76-700kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co76_700kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_7_6 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (8-7) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 800 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co87-800kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co87_800kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_8_7 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (9-8) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 900 kHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co98-900kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co98_900kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_9_8 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (10-9) EMISSON FROM SPATIALLY UNRESOLVED SOURCE, 1 MHz SPECTRAL RESOLUTION
outfile="sax-unresolved-co109-1MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_co109_1MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --co_10_9 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '##############################################'
echo '# CO EMISSION FROM SPATIALLY RESOLVED SOURCE #'
echo '##############################################'
# CO (1-0) EMISSON FROM SPATIALLY RESOLVED SOURCE, 100 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co10-100kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co10_100kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (2-1) EMISSON FROM SPATIALLY RESOLVED SOURCE, 200 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co21-200kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co21_200kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_2_1 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (3-2) EMISSON FROM SPATIALLY RESOLVED SOURCE, 300 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co32-300kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co32_300kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_3_2 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (4-3) EMISSON FROM SPATIALLY RESOLVED SOURCE, 400 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co43-400kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co43_400kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_4_3 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (5-4) EMISSON FROM SPATIALLY RESOLVED SOURCE, 500 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co54-500kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co54_500kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_5_4 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (6-5) EMISSON FROM SPATIALLY RESOLVED SOURCE, 600 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co65-600kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co65_600kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_6_5 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (7-6) EMISSON FROM SPATIALLY RESOLVED SOURCE, 700 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co76-700kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co76_700kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_7_6 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (8-7) EMISSON FROM SPATIALLY RESOLVED SOURCE, 800 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co87-800kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co87_800kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_8_7 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (9-8) EMISSON FROM SPATIALLY RESOLVED SOURCE, 900 kHz SPECTRAL RESOLUTION
outfile="sax-1mas-co98-900kHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co98_900kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_9_8 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# CO (10-9) EMISSON FROM SPATIALLY RESOLVED SOURCE, 1 MHz SPECTRAL RESOLUTION
outfile="sax-1mas-co109-1MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas --freqinfo=$freqrange_co109_1MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_10_9 --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '###################################################################'
echo '# UNRESOLVED SOURCE, HI AND ALL CO LINES FROM 110 MHz to 200 GHz  #'
echo '###################################################################'
outfile="hi-co"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_all --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=5.0 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --co_1_0 --co_2_1 --co_3_2 --co_4_3 --co_5_4 --co_6_5 --co_7_6 --co_8_7 --co_9_8 --co_10_9 --freqaxis --nocmb
echo '----------------------------------------------------------------'


#echo '######################################################'
#echo '# TEST MAP NOT CENTERED ON RESOLVED CO(1-0) EMISSION #'
#echo '######################################################'
#outfile="sax-1mas-co10-100kHz-positive-shift-10mas"
#echo '>>>> BUILDING FILE '$outfile
#python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas_positive_shift_10mas --freqinfo=$freqrange_co10_100kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
#echo '----------------------------------------------------------------'
#
#outfile="sax-1mas-co10-100kHz-negative-shift-10mas"
#echo '>>>> BUILDING FILE '$outfile
#python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_200mas_negative_shift_10mas --freqinfo=$freqrange_co10_100kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --co_1_0 --freqaxis --zrange=9.66001,9.66001 --nocmb
#echo '----------------------------------------------------------------'


echo '#####################################################################'
echo '# TEST CHANNEL SPLITTING ON UNRESOLVED HI 5 kHz SPECTRAL RESOLUTION #'
echo '#####################################################################'
outfile="sax-unresolved-hi-1kHz-low-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_lowband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-center-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_centerband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-high-Oxford"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_highband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#################################'
echo '# TEST SPATIAL WINDOW SPLITTING #'
echo '#################################'

outfile="sax-1mas-hi-5kHz-Oxford-tl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_tl --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Oxford-tr"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_tr --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Oxford-bl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_bl --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Oxford-br"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_br --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '####################################################################'
echo '# TESTING FOR DIFFERENCES WITH REFERENCE FILES USING DIFF COMMANDS #'
echo '####################################################################'
cd ../Tests/
for outfile in *Oxford*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done
for outfile in *co*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done

# Build spectra plots and print out integrated fluxes 
echo '####################################################################'
echo '# BUILDING IMAGES OF SOURCES AND PLOTS OF SPECTRA FOR OUTPUT FILES #'
echo '####################################################################'
cd ../Routines/
python plot-SAX-Oxford-tests.py



#freqrange_hi_40MHz="0.053232090735,0.04,5" # 5 channels (40MHz) centered on HI central frequency [1 non zero channel]
#freqrange_hi_10MHz="0.113232090735,0.01,5" # 5 channels (10MHz) centered on HI central frequency [1 non zero channel]
#freqrange_hi_2MHz="0.129232090735,0.002,5" # 5 channels (2MHz) centered on HI central frequency [3 non zero channels]
#freqrange_hi_600kHz="0.130232090735,0.0006,10" # 10 channels (600 kHz) centered on HI central frequency [5 non zero channels]
#freqrange_hi_120kHz="0.130232090735,0.00012,50" # 50 channels (120 kHz) centered on HI central frequency [25 non zero channels]
#freqrange_hi_60kHz="0.130232090735,0.00006,100" # 100 channels (60 kHz) centered on HI central frequency [47 non zero channels]

#freqrange_hi_60kHz_lowband="0.130232090735,0.00006,40" # 40 channels (60 kHz) on the lower band of the HI signal
#freqrange_hi_60kHz_centerband="0.132632090735,0.00006,20" # 20 channels (60 kHz) on the center band of the HI signal
#freqrange_hi_60kHz_highband="0.133832090735,0.00006,40" # 40 channels (60 kHz) on the higher band of the HI signal

#freqrange_hi_6kHz="0.130232090735,0.000006,1000" # 1000 channels (6kHz) centered on HI central frequency [467 non zero channel]

print "Wait for GUI to start..."

from Tkinter import *
import tkFileDialog
import os
import math
from time import *
import stat
import tkFont
from displays import *
from common_routines import *
from common_map_routines import *
from io_routines import *
import sys
sys.path.append("../Config/")
from Config_Path import *

from Config_Map import *

class S3Map_application(Frame):
    def __init__(self,master=None):        
        Frame.__init__(self,master)
        self.grid()
        self.createWidgets()

    def createWidgets(self):
        self.angle_units=["arcsecs","arcmins","degrees","radians"]
        self.frequency_units=["GHz","MHz","kHz"]
    # VARIABLE DECLARATION
        self.CatalogChoice=IntVar()
	self.MapCubeChoice=IntVar()
	self.FreqVeloAxis=IntVar()
        self.RQAGNVar=IntVar()
        self.FRIVar=IntVar()
        self.FRIIVar=IntVar()
        self.DiskSFGVar=IntVar()
        self.NuclearSFGVar=IntVar()
        self.GPSVar=IntVar()
        self.TotalIntensityVar=IntVar()
        self.LinearPolarizationVar=IntVar()
        self.co10Var=IntVar()
        self.co21Var=IntVar()
        self.co32Var=IntVar()
        self.co43Var=IntVar()
        self.co54Var=IntVar()
        self.co65Var=IntVar()
        self.co76Var=IntVar()
        self.co87Var=IntVar()
        self.co98Var=IntVar()
        self.co109Var=IntVar()
        self.EORVar=IntVar()
        self.HIVar=StringVar()
        self.UseRefPos=IntVar()
        self.Z_LINE_Var=IntVar()
        self.BMAJ_UNIT_Var=IntVar()
        self.BMAJ_UNIT_Value=StringVar()
        self.BMIN_UNIT_Var=IntVar()
        self.BMIN_UNIT_Value=StringVar()
        self.BPA_UNIT_Var=IntVar()
        self.BPA_UNIT_Value=StringVar()
        self.CDELTX_UNIT_Var=IntVar()
        self.CDELTX_UNIT_Value=StringVar()
        self.CDELTnu_UNIT_Var=IntVar()
        self.CDELTnu_UNIT_Value=StringVar()
        self.CRVALnu_UNIT_Var=IntVar()
        self.CRVALnu_UNIT_Value=StringVar()
        self.ZAXIS_TYPE_Var=IntVar()
	self.Nfreq=IntVar()
        self.SourceListName=StringVar()
        self.MapCubeName=StringVar()
        self.AnnotationName=StringVar()
        self.ScriptName=StringVar()
        self.CatalogName=StringVar()
        self.outputdir=StringVar()
        self.FullRange=IntVar()
        self.QueryLoadChoice=IntVar()
        self.Limit_BLC_RA=IntVar()
        self.Limit_BLC_DEC=IntVar()
        self.Limit_TRC_RA=IntVar()
        self.Limit_TRC_DEC=IntVar()

        self.save_script_file=StringVar()
        self.annotation_file=StringVar()
        self.catalog_file=StringVar()
        self.source_list_file=StringVar()
        self.FITSfile=StringVar()

        self.script_file=StringVar()
        self.script_file.set(os.popen("pwd").readlines()[0].replace("\n","/")+"script.py")

        self.PixelSize=DoubleVar()
        self.makedistscale=IntVar()
        self.makeangsize=IntVar()
        self.makemorph=IntVar()
        self.makenoise=IntVar()
        self.initialize=IntVar()
        
        self.ImageSize_X=IntVar()
        self.ImageSize_Y=IntVar()
        self.I=IntVar()
        self.Q=IntVar()
        self.U=IntVar()
        self.V=IntVar()
        self.ReverseRA=IntVar()
        self.IncludeGSM=IntVar()
        self.IncludeCMB=IntVar()
        self.IncludeEOR=IntVar()
        self.showCube=IntVar()
        self.BuildCatalog=IntVar()
        self.BuildSourceList=IntVar()
        self.BuildMapCube=IntVar()
        self.BuildAnnotation=IntVar()
        self.BuildScript=IntVar()
        self.ShowSourceList=IntVar()
        self.ShowCatalog=IntVar()
        self.ShowMapCube=IntVar()
        self.Cubebuildcatalog=IntVar()
        self.catrootdir=StringVar()
        self.input=StringVar()
        self.in_id=StringVar()
        self.dir=StringVar()
        self.qid=StringVar()

        self.ZMIN=DoubleVar()
        self.ZMAX=DoubleVar()

        self.dirname=StringVar()
        self.NoiseLevel=DoubleVar()
        self.BeamMajorFWHM=DoubleVar()
        self.BeamMinorFWHM=DoubleVar()
        self.BeamPA=DoubleVar()
        self.CubeNoiseLevel=DoubleVar()
        self.CubeBeamFWHM=DoubleVar()
        self.profile_accuracy=IntVar()
        self.image_accuracy=IntVar()
        self.ContinuumHI=IntVar()
        self.Min_Z=DoubleVar()
        self.Max_Z=DoubleVar()
        self.Min_X_From_Query_sgn=StringVar()
        self.Min_X_From_Query_deg=IntVar()
        self.Min_X_From_Query_min=IntVar()
        self.Min_X_From_Query_sec=DoubleVar()
        self.Max_X_From_Query_sgn=StringVar()
        self.Max_X_From_Query_deg=IntVar()
        self.Max_X_From_Query_min=IntVar()
        self.Max_X_From_Query_sec=DoubleVar()
        self.Min_Y_From_Query_sgn=StringVar()
        self.Min_Y_From_Query_deg=IntVar()
        self.Min_Y_From_Query_min=IntVar()
        self.Min_Y_From_Query_sec=DoubleVar()
        self.Max_Y_From_Query_sgn=StringVar()
        self.Max_Y_From_Query_deg=IntVar()
        self.Max_Y_From_Query_min=IntVar()
        self.Max_Y_From_Query_sec=DoubleVar()
        self.AreaSearchChoice=IntVar()
        self.SelectedTypes=IntVar()
        self.Min_X_From_Query=IntVar()
        self.Max_X_From_Query=IntVar()
        self.Min_Y_From_Query=IntVar()
        self.Max_Y_From_Query=IntVar()
        self.DB=StringVar()
        
    # VARIABLE INITIALIZATION
        self.BPA_UNIT_Var.set(3)
        self.CDELTnu_UNIT_Var.set(2)
        self.CRVALnu_UNIT_Var.set(1)
        self.ContinuumHI.set(0)
        self.RQAGNVar.set(1)
        self.FRIVar.set(1)
        self.FRIIVar.set(1)
        self.DiskSFGVar.set(1)
        self.NuclearSFGVar.set(1)
        self.QueryLoadChoice.set(1)
        self.AreaSearchChoice.set(1)
        self.UseRefPos.set(1)
	self.Nfreq.set(1)
        self.CatalogChoice.set(0)
        self.MapCubeChoice.set(1)
        self.FreqVeloAxis.set(2)
        self.PixelSize.set(1.0)
        self.ShowMapCube.set(1)
        self.I.set(1)
        self.BuildMapCube.set(1)
        self.BuildCatalog.set(1)
        self.BuildSourceList.set(0)
        self.BuildAnnotation.set(1)
        self.SelectedTypes.set(0)
        self.image_accuracy.set(100)
        self.ZAXIS_TYPE_Var.set(1)
        self.Limit_BLC_RA.set(1)
        self.Limit_BLC_DEC.set(1)
        self.Limit_TRC_RA.set(1)
        self.Limit_TRC_DEC.set(1)
        self.HIVar.set("Oxford")
	self.outputdir.set(OUTPUT_DIR)

	self.Include_Continuum=IntVar()
	self.Include_HI=IntVar()
	self.Include_CO=IntVar()
	self.Include_Continuum_Line=StringVar()
	self.Include_HI_Line=StringVar()
	self.Include_Continuum.set(0)
	self.Include_HI.set(0)
	self.Include_CO.set(0)
        self.IncludeCMB.set(1)

        self.BeamMajorFWHM.set(2.0)
        self.BeamMinorFWHM.set(2.0)
        self.CubeBeamFWHM.set(2.0)
        self.initialize.set(1)
        
        self.IOFrame=Frame(self)
        self.IOFrame.grid(sticky=W)

        self.OutputMapDirLabel=Label(self.IOFrame,text="Input Tarball")
        self.OutputMapDirLabel.grid(row=0,column=1,sticky=E)
	self.OutputMapDirEntry=Entry(self.IOFrame,relief=GROOVE,textvariable=self.in_id,bg="white",selectbackground="yellow",width=28,justify=LEFT)
        self.OutputMapDirEntry.grid(row=0,column=2,sticky=W)
	self.OutputMapDirBrowse=Button(self.IOFrame,text="Browse",command=self.browse_input,relief=GROOVE,width=6)
        self.OutputMapDirBrowse.grid(row=0,column=3,padx=4,sticky=W)

        self.BuildMapCubeLabel=Label(self.IOFrame,text="Output Name")
        self.BuildMapCubeLabel.grid(column=1,row=2,sticky=E)
        self.MapCubeName_Entry=Entry(self.IOFrame,relief=GROOVE,textvariable=self.qid,bg="white",selectbackground="yellow",width=28,justify=LEFT)
        self.MapCubeName_Entry.grid(column=2,row=2,sticky=W)
	self.MapCubeNameRefresh=Button(self.IOFrame,text="Refresh",command=self.refresh_filename,relief=GROOVE,width=6)
        self.MapCubeNameRefresh.grid(row=2,column=3,padx=4)
        self.MapCubeNameRefresh.configure(state=DISABLED)

        
#        self.DOChoice=Radiobutton(self.CatalogFrame,variable=self.CatalogChoice,value=1,command=self.ChooseSAX,padx=0,text="S-Cubed SAX")
#        self.DOChoice.grid(column=0,row=1,sticky=W)

        self.BoxFrame=Frame(self)
        self.BoxFrame.grid(sticky=W)

        self.BoxChoice=Radiobutton(self.BoxFrame,variable=self.AreaSearchChoice,value=1,command=self.ChooseBox,padx=0,text="Rectangular Map")
#        self.BoxChoice.grid(column=0,row=0,sticky=W,columnspan=4)

        self.Label=Label(self.BoxFrame,text="X:")
        self.Label.grid(column=0,row=1,sticky=W,padx=4)
        self.Label=Label(self.BoxFrame,text="From")
        self.Label.grid(column=1,row=1)
        self.Min_X_Display=AngleDisplay(self.BoxFrame)
        self.Min_X_Display.grid(column=2,row=1)
        self.Label=Label(self.BoxFrame,text="[d:':\"]")
        self.Label.grid(column=3,row=1)
        self.Button=Checkbutton(self.BoxFrame,text="From Query",variable=self.Min_X_From_Query,command=self.Toggle_Min_X_From_Query,selectcolor="Blue")
        self.Button.grid(column=4,row=1,sticky=W)

        self.Label=Label(self.BoxFrame,text="To")
        self.Label.grid(column=1,row=2)
        self.Max_X_Display=AngleDisplay(self.BoxFrame)
        self.Max_X_Display.grid(column=2,row=2)
        self.Label=Label(self.BoxFrame,text="[d:':\"]")
        self.Label.grid(column=3,row=2)
        self.Button=Checkbutton(self.BoxFrame,text="From Query",variable=self.Max_X_From_Query,command=self.Toggle_Max_X_From_Query,selectcolor="Blue")
        self.Button.grid(column=4,row=2,sticky=W)

        self.Label=Label(self.BoxFrame,text="Y:")
        self.Label.grid(column=0,row=3,sticky=W,padx=4)
        self.Label=Label(self.BoxFrame,text="From")
        self.Label.grid(column=1,row=3)
        self.Min_Y_Display=AngleDisplay(self.BoxFrame)
        self.Min_Y_Display.grid(column=2,row=3)
        self.Label=Label(self.BoxFrame,text="[d:':\"]")
        self.Label.grid(column=3,row=3)
        self.Button=Checkbutton(self.BoxFrame,text="From Query",variable=self.Min_Y_From_Query,command=self.Toggle_Min_Y_From_Query,selectcolor="Blue")
        self.Button.grid(column=4,row=3,sticky=W)

        self.Label=Label(self.BoxFrame,text="To")
        self.Label.grid(column=1,row=4)
        self.Max_Y_Display=AngleDisplay(self.BoxFrame)
        self.Max_Y_Display.grid(column=2,row=4)
        self.Label=Label(self.BoxFrame,text="[d:':\"]")
        self.Label.grid(column=3,row=4)
        self.Button=Checkbutton(self.BoxFrame,text="From Query",variable=self.Max_Y_From_Query,command=self.Toggle_Max_Y_From_Query,selectcolor="Blue")
        self.Button.grid(column=4,row=4,sticky=W)

#        self.DiskFrame=Frame(self)
#        self.DiskFrame.grid(sticky=W)
#
#        self.DiskChoice=Radiobutton(self.DiskFrame,variable=self.AreaSearchChoice,value=2,command=self.ChooseDisk,padx=0,text="Circular Map")
#        self.DiskChoice.grid(column=4,row=0,sticky=W,columnspan=4)
#        self.DiskChoice.configure(state=DISABLED)
#
#        self.Label=Label(self.DiskFrame,text="Center:")
#        self.Label.grid(column=4,row=1,sticky=W,padx=4)
#        self.Label=Label(self.DiskFrame,text="X")
#        self.Label.grid(column=5,row=1)
#        self.Center_X_Display=AngleDisplay(self.DiskFrame)
#        self.Center_X_Display.grid(column=6,row=1)
#        self.Center_X_Display.configure(state=DISABLED)
#        self.Label=Label(self.DiskFrame,text="[d:':\"]")
#        self.Label.grid(column=7,row=1)
#
#        self.Label=Label(self.DiskFrame,text="Y")
#        self.Label.grid(column=5,row=2)
#        self.Center_Y_Display=AngleDisplay(self.DiskFrame)
#        self.Center_Y_Display.grid(column=6,row=2)
#        self.Center_Y_Display.configure(state=DISABLED)
#        self.Label=Label(self.DiskFrame,text="[d:':\"]")
#        self.Label.grid(column=7,row=2)
#        
#        self.Label=Label(self.DiskFrame,text="Radius")
#        self.Label.grid(column=4,row=4,sticky=W,padx=4)
#        self.Radius_Display=AngleDisplay(self.DiskFrame)
#        self.Radius_Display.grid(column=6,row=4)
#        self.Radius_Display.configure(state=DISABLED)
#        self.Label=Label(self.DiskFrame,text="[d:':\"]")
#        self.Label.grid(column=7,row=4)

        self.FrequencyFrame=Frame(self,height=80,width=400)
        self.FrequencyFrame.grid(sticky=W)

        self.Freq_Label=Label(self.FrequencyFrame,text="Minimum Frequency")
        self.Freq_Label.grid(column=0,row=0,sticky=W,padx=4)
        self.minObsFreq_Display=FreqDisplay(self.FrequencyFrame)
        self.minObsFreq_Display.Freq.set(constant("nu0_HI"))
        self.minObsFreq_Display.grid(column=1,row=0,sticky=W,columnspan=2)
#        self.Label=Label(self.FrequencyFrame,text="[MHz]")
#        self.Label.grid(column=2,row=0,sticky=W)

        self.SpectralResolution_Label=Label(self.FrequencyFrame,text="Frequency Resolution")
        self.SpectralResolution_Label.grid(column=0,row=1,sticky=W,padx=4)
        self.SpectralResolution_Display=FreqDisplay(self.FrequencyFrame)
	self.SpectralResolution_Display.Freq.set(default_spectral_width)
        self.SpectralResolution_Display.grid(column=1,row=1,sticky=W,columnspan=2)
#        self.Label=Label(self.FrequencyFrame,text="[kHz]")
#        self.Label.grid(column=2,row=1,sticky=W)

        self.CDELTnu_UNIT_Menu=Menubutton(self.FrequencyFrame,text="Units",relief=GROOVE,width=5)
        self.CDELTnu_UNIT_Menu.grid(column=4,row=1,sticky=W)
        self.CDELTnu_UNIT_Menu.menu=Menu(self.CDELTnu_UNIT_Menu,tearoff=0)
        self.CDELTnu_UNIT_Menu["menu"]=self.CDELTnu_UNIT_Menu.menu
        self.CDELTnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[0],variable=self.CDELTnu_UNIT_Var,value=0,command=self.Set_CDELTnu_UNIT,selectcolor="blue")
        self.CDELTnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[1],variable=self.CDELTnu_UNIT_Var,value=1,command=self.Set_CDELTnu_UNIT,selectcolor="blue")
        self.CDELTnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[2],variable=self.CDELTnu_UNIT_Var,value=2,command=self.Set_CDELTnu_UNIT,selectcolor="blue")
        self.CDELTnu_UNIT_Entry=Entry(self.FrequencyFrame,relief=FLAT,textvariable=self.CDELTnu_UNIT_Value,bg="white",selectbackground="yellow",width=5,justify=LEFT)
        self.CDELTnu_UNIT_Entry.grid(column=3,row=1)
        self.CDELTnu_UNIT_Entry.configure(state=DISABLED)
        self.Set_CDELTnu_UNIT()

        self.CRVALnu_UNIT_Menu=Menubutton(self.FrequencyFrame,text="Units",relief=GROOVE,width=5)
        self.CRVALnu_UNIT_Menu.grid(column=4,row=0,sticky=W)
        self.CRVALnu_UNIT_Menu.menu=Menu(self.CRVALnu_UNIT_Menu,tearoff=0)
        self.CRVALnu_UNIT_Menu["menu"]=self.CRVALnu_UNIT_Menu.menu
        self.CRVALnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[0],variable=self.CRVALnu_UNIT_Var,value=0,command=self.Set_CRVALnu_UNIT,selectcolor="blue")
        self.CRVALnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[1],variable=self.CRVALnu_UNIT_Var,value=1,command=self.Set_CRVALnu_UNIT,selectcolor="blue")
        self.CRVALnu_UNIT_Menu.menu.add_radiobutton(label=self.frequency_units[2],variable=self.CRVALnu_UNIT_Var,value=2,command=self.Set_CRVALnu_UNIT,selectcolor="blue")
        self.CRVALnu_UNIT_Entry=Entry(self.FrequencyFrame,relief=FLAT,textvariable=self.CRVALnu_UNIT_Value,bg="white",selectbackground="yellow",width=5,justify=LEFT)
        self.CRVALnu_UNIT_Entry.grid(column=3,row=0)
        self.CRVALnu_UNIT_Entry.configure(state=DISABLED)
        self.Set_CRVALnu_UNIT()

        self.SetupFrame=Frame(self,height=80,width=400)
        self.SetupFrame.grid(sticky=W)

#        self.Label=Label(self.SetupFrame,text="Setup")
#        self.Label.grid(column=0,row=0,sticky=W,padx=2)
       	self.Apply_Z_Range_Button=Button(self.SetupFrame,text="Setup",command=self.Apply_Z_Range,relief=GROOVE,width=5)
        self.Apply_Z_Range_Button.grid(row=0,column=0,sticky=W)
	self.Nfreq_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.Nfreq,bg="white",selectbackground="yellow",width=5,justify=RIGHT)
	self.Nfreq_Entry.grid(column=1,row=0,sticky=W)

	self.Nfreq_Label=Label(self.SetupFrame,text="channels for")
	self.Nfreq_Label.grid(column=2,row=0,sticky=W,padx=4)


        self.Z_LINE_Menu=Menubutton(self.SetupFrame,text="Line",relief=GROOVE,width=5)
        self.Z_LINE_Menu.grid(column=3,row=0,sticky=E)
        self.Z_LINE_Menu.menu=Menu(self.Z_LINE_Menu,tearoff=0)
        self.Z_LINE_Menu["menu"]=self.Z_LINE_Menu.menu
        self.Z_LINE_Menu.menu.add_radiobutton(label="HI",variable=self.Z_LINE_Var,value=0,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(1-0)",variable=self.Z_LINE_Var,value=1,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(2-1)",variable=self.Z_LINE_Var,value=2,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(3-2)",variable=self.Z_LINE_Var,value=3,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(4-3)",variable=self.Z_LINE_Var,value=4,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(5-4)",variable=self.Z_LINE_Var,value=5,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(6-5)",variable=self.Z_LINE_Var,value=6,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(7-6)",variable=self.Z_LINE_Var,value=7,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(8-7)",variable=self.Z_LINE_Var,value=8,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(9-8)",variable=self.Z_LINE_Var,value=9,selectcolor="blue")
        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(10-9)",variable=self.Z_LINE_Var,value=10,selectcolor="blue")

        self.Label=Label(self.SetupFrame,text="with z in")
        self.Label.grid(column=4,row=0,padx=4)

        self.ZMIN_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.ZMIN,bg="white",selectbackground="yellow",width=4,justify=RIGHT)
        self.ZMIN_Entry.grid(column=5,row=0,sticky=E)
        self.Label=Label(self.SetupFrame,text="-")
        self.Label.grid(column=6,row=0,padx=1)
        self.ZMAX_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.ZMAX,bg="white",selectbackground="yellow",width=4,justify=RIGHT)
        self.ZMAX_Entry.grid(column=7,row=0,sticky=W)

#
#



#        self.SetupFrame=Frame(self,height=80,width=400)
#        self.SetupFrame.grid(sticky=W)
#
#        self.Label=Label(self.SetupFrame,text="Redshift Range")
#        self.Label.grid(column=0,row=2,sticky=W,padx=4)
#        self.ZMIN_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.ZMIN,bg="white",selectbackground="yellow",width=5,justify=RIGHT)
#        self.ZMIN_Entry.grid(column=1,row=2)
#        self.ZMAX_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.ZMAX,bg="white",selectbackground="yellow",width=5,justify=RIGHT)
#        self.ZMAX_Entry.grid(column=2,row=2)
#        self.Label=Label(self.SetupFrame,text="with")
#        self.Label.grid(column=3,row=2,padx=4)
#
#	self.Nfreq_Label=Label(self.SetupFrame,text="Number of channels")
#	self.Nfreq_Label.grid(column=0,row=3,sticky=W,padx=4)
#	self.Nfreq_Entry=Entry(self.SetupFrame,relief=GROOVE,textvariable=self.Nfreq,bg="white",selectbackground="yellow",width=14,justify=RIGHT)
#	self.Nfreq_Entry.grid(column=1,row=3,sticky=W,columnspan=2)
#
#
#        self.Z_LINE_Menu=Menubutton(self.SetupFrame,text="Line",relief=GROOVE,width=5)
#        self.Z_LINE_Menu.grid(column=4,row=2,sticky=E)
#        self.Z_LINE_Menu.menu=Menu(self.Z_LINE_Menu,tearoff=0)
#        self.Z_LINE_Menu["menu"]=self.Z_LINE_Menu.menu
#        self.Z_LINE_Menu.menu.add_radiobutton(label="HI",variable=self.Z_LINE_Var,value=0,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(1-0)",variable=self.Z_LINE_Var,value=1,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(2-1)",variable=self.Z_LINE_Var,value=2,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(3-2)",variable=self.Z_LINE_Var,value=3,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(4-3)",variable=self.Z_LINE_Var,value=4,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(5-4)",variable=self.Z_LINE_Var,value=5,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(6-5)",variable=self.Z_LINE_Var,value=6,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(7-6)",variable=self.Z_LINE_Var,value=7,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(8-7)",variable=self.Z_LINE_Var,value=8,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(9-8)",variable=self.Z_LINE_Var,value=9,selectcolor="blue")
#        self.Z_LINE_Menu.menu.add_radiobutton(label="CO(10-9)",variable=self.Z_LINE_Var,value=10,selectcolor="blue")
#
#       	self.Apply_Z_Range_Button=Button(self.SetupFrame,text="Apply",command=self.Apply_Z_Range,relief=GROOVE,width=5)
#        self.Apply_Z_Range_Button.grid(row=3,column=4,sticky=W)
#
        self.ImagingFrame=Frame(self,height=80,width=400)
        self.ImagingFrame.grid(sticky=W)

        self.BeamFWHM_Label=Label(self.ImagingFrame,text='Beam Major FWHM')
        self.BeamFWHM_Label.grid(column=0,row=3,sticky=W,padx=4)
        self.BeamFWHM_Entry=Entry(self.ImagingFrame,relief=GROOVE,textvariable=self.BeamMajorFWHM,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
        self.BeamFWHM_Entry.grid(column=1,row=3,sticky=W)
#        self.Label=Label(self.ImagingFrame,text='["]')
#        self.Label.grid(column=2,row=3,sticky=W)

#################
# TEST FOR UNIT DROP_DOWN MENU
        self.BMAJ_UNIT_Menu=Menubutton(self.ImagingFrame,text="Units",relief=GROOVE,width=5)
        self.BMAJ_UNIT_Menu.grid(column=3,row=3,sticky=W)
        self.BMAJ_UNIT_Menu.menu=Menu(self.BMAJ_UNIT_Menu,tearoff=0)
        self.BMAJ_UNIT_Menu["menu"]=self.BMAJ_UNIT_Menu.menu
        self.BMAJ_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[0],variable=self.BMAJ_UNIT_Var,value=0,command=self.Set_BMAJ_UNIT,selectcolor="blue")
        self.BMAJ_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[1],variable=self.BMAJ_UNIT_Var,value=1,command=self.Set_BMAJ_UNIT,selectcolor="blue")
        self.BMAJ_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[2],variable=self.BMAJ_UNIT_Var,value=2,command=self.Set_BMAJ_UNIT,selectcolor="blue")
        self.BMAJ_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[3],variable=self.BMAJ_UNIT_Var,value=3,command=self.Set_BMAJ_UNIT,selectcolor="blue")
        self.BMAJ_UNIT_Entry=Entry(self.ImagingFrame,relief=FLAT,textvariable=self.BMAJ_UNIT_Value,bg="white",selectbackground="yellow",width=10,justify=LEFT)
        self.BMAJ_UNIT_Entry.grid(column=2,row=3)
        self.BMAJ_UNIT_Entry.configure(state=DISABLED)
        self.Set_BMAJ_UNIT()

        self.BMIN_UNIT_Menu=Menubutton(self.ImagingFrame,text="Units",relief=GROOVE,width=5)
        self.BMIN_UNIT_Menu.grid(column=3,row=4,sticky=W)
        self.BMIN_UNIT_Menu.menu=Menu(self.BMIN_UNIT_Menu,tearoff=0)
        self.BMIN_UNIT_Menu["menu"]=self.BMIN_UNIT_Menu.menu
        self.BMIN_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[0],variable=self.BMIN_UNIT_Var,value=0,command=self.Set_BMIN_UNIT,selectcolor="blue")
        self.BMIN_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[1],variable=self.BMIN_UNIT_Var,value=1,command=self.Set_BMIN_UNIT,selectcolor="blue")
        self.BMIN_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[2],variable=self.BMIN_UNIT_Var,value=2,command=self.Set_BMIN_UNIT,selectcolor="blue")
        self.BMIN_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[3],variable=self.BMIN_UNIT_Var,value=3,command=self.Set_BMIN_UNIT,selectcolor="blue")
        self.BMIN_UNIT_Entry=Entry(self.ImagingFrame,relief=FLAT,textvariable=self.BMIN_UNIT_Value,bg="white",selectbackground="yellow",width=10,justify=LEFT)
        self.BMIN_UNIT_Entry.grid(column=2,row=4)
        self.BMIN_UNIT_Entry.configure(state=DISABLED)
        self.Set_BMIN_UNIT()

        self.BPA_UNIT_Menu=Menubutton(self.ImagingFrame,text="Units",relief=GROOVE,width=5)
        self.BPA_UNIT_Menu.grid(column=3,row=5,sticky=W)
        self.BPA_UNIT_Menu.menu=Menu(self.BPA_UNIT_Menu,tearoff=0)
        self.BPA_UNIT_Menu["menu"]=self.BPA_UNIT_Menu.menu
        self.BPA_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[0],variable=self.BPA_UNIT_Var,value=0,command=self.Set_BPA_UNIT,selectcolor="blue")
        self.BPA_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[1],variable=self.BPA_UNIT_Var,value=1,command=self.Set_BPA_UNIT,selectcolor="blue")
        self.BPA_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[2],variable=self.BPA_UNIT_Var,value=2,command=self.Set_BPA_UNIT,selectcolor="blue")
        self.BPA_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[3],variable=self.BPA_UNIT_Var,value=3,command=self.Set_BPA_UNIT,selectcolor="blue")
        self.BPA_UNIT_Entry=Entry(self.ImagingFrame,relief=FLAT,textvariable=self.BPA_UNIT_Value,bg="white",selectbackground="yellow",width=10,justify=LEFT)
        self.BPA_UNIT_Entry.grid(column=2,row=5)
        self.BPA_UNIT_Entry.configure(state=DISABLED)
        self.Set_BPA_UNIT()

        self.CDELTX_UNIT_Menu=Menubutton(self.ImagingFrame,text="Units",relief=GROOVE,width=5)
        self.CDELTX_UNIT_Menu.grid(column=3,row=6,sticky=W)
        self.CDELTX_UNIT_Menu.menu=Menu(self.CDELTX_UNIT_Menu,tearoff=0)
        self.CDELTX_UNIT_Menu["menu"]=self.CDELTX_UNIT_Menu.menu
        self.CDELTX_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[0],variable=self.CDELTX_UNIT_Var,value=0,command=self.Set_CDELTX_UNIT,selectcolor="blue")
        self.CDELTX_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[1],variable=self.CDELTX_UNIT_Var,value=1,command=self.Set_CDELTX_UNIT,selectcolor="blue")
        self.CDELTX_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[2],variable=self.CDELTX_UNIT_Var,value=2,command=self.Set_CDELTX_UNIT,selectcolor="blue")
        self.CDELTX_UNIT_Menu.menu.add_radiobutton(label=self.angle_units[3],variable=self.CDELTX_UNIT_Var,value=3,command=self.Set_CDELTX_UNIT,selectcolor="blue")
        self.CDELTX_UNIT_Entry=Entry(self.ImagingFrame,relief=FLAT,textvariable=self.CDELTX_UNIT_Value,bg="white",selectbackground="yellow",width=10,justify=LEFT)
        self.CDELTX_UNIT_Entry.grid(column=2,row=6)
        self.CDELTX_UNIT_Entry.configure(state=DISABLED)
        self.Set_CDELTX_UNIT()



###############


        self.BeamFWHM_Label=Label(self.ImagingFrame,text='Beam Minor FWHM')
        self.BeamFWHM_Label.grid(column=0,row=4,sticky=W,padx=4)
        self.BeamFWHM_Entry=Entry(self.ImagingFrame,relief=GROOVE,textvariable=self.BeamMinorFWHM,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
        self.BeamFWHM_Entry.grid(column=1,row=4,sticky=W)
#        self.Label=Label(self.ImagingFrame,text='["]')
#        self.Label.grid(column=2,row=4,sticky=W)

        self.BeamFWHM_Label=Label(self.ImagingFrame,text='Beam Position Angle')
        self.BeamFWHM_Label.grid(column=0,row=5,sticky=W,padx=4)
        self.BeamFWHM_Entry=Entry(self.ImagingFrame,relief=GROOVE,textvariable=self.BeamPA,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
        self.BeamFWHM_Entry.grid(column=1,row=5,sticky=W)
#        self.Label=Label(self.ImagingFrame,text='[rad]')
#        self.Label.grid(column=2,row=5,sticky=W)

        self.PixelSize_Label=Label(self.ImagingFrame,text='Pixel size')
        self.PixelSize_Label.grid(column=0,row=6,sticky=W,padx=4)
        self.PixelSize_Entry=Entry(self.ImagingFrame,relief=GROOVE,textvariable=self.PixelSize,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
        self.PixelSize_Entry.grid(column=1,row=6,sticky=W)
#        self.Label=Label(self.ImagingFrame,text='["]')
#        self.Label.grid(column=2,row=6,sticky=W)

#        self.ImageSizeFrame=Frame(self,height=80,width=400)
#        self.ImageSizeFrame.grid(sticky=W)
#	self.ImageSizeLabel=Label(self.ImageSizeFrame,text="Image size (pixels)")
#	self.ImageSizeLabel.grid(column=0,row=0,sticky=W,padx=4)
#        self.ImageSize_XEntry=Entry(self.ImageSizeFrame,relief=GROOVE,textvariable=self.ImageSize_X,bg="white",selectbackground="yellow",width=5,justify=RIGHT)
#        self.ImageSize_XEntry.grid(column=1,row=0,sticky=W)
#        self.ImageSize_YEntry=Entry(self.ImageSizeFrame,relief=GROOVE,textvariable=self.ImageSize_Y,bg="white",selectbackground="yellow",width=5,justify=RIGHT)
#        self.ImageSize_YEntry.grid(column=2,row=0,sticky=W)
#       	self.Update_Size_Button=Button(self.ImageSizeFrame,text="Update",command=self.Update_Size,relief=GROOVE,width=4)
#        self.Update_Size_Button.grid(row=0,column=3,sticky=W)

#        self.NoiseFrame=Frame(self,height=80,width=400)
#        self.NoiseFrame.grid(sticky=W)
        self.NoiseLevel_Label=Label(self.ImagingFrame,text='Noise level')
        self.NoiseLevel_Label.grid(column=0,row=8,sticky=W,padx=4)
        self.NoiseLevel_Entry=Entry(self.ImagingFrame,relief=GROOVE,textvariable=self.NoiseLevel,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
        self.NoiseLevel_Entry.grid(column=1,row=8,sticky=W)
        self.NoiseLevel_UnitLabel=Label(self.ImagingFrame,text='nJy')
        self.NoiseLevel_UnitLabel.grid(column=2,row=8,sticky=W,padx=4)

        self.CatalogFrame=Frame(self)
        self.CatalogFrame.grid(sticky=W)

#        self.RWChoice=Radiobutton(self.CatalogFrame,variable=self.CatalogChoice,value=0,command=self.ChooseSEX,padx=0,text="S-Cubed SEX")
#        self.RWChoice.grid(column=0,row=0,sticky=W)

        self.SEXSourceTypes=Menubutton(self.CatalogFrame,text="Source Types",relief=GROOVE,width=11)
        self.SEXSourceTypes.grid(column=1,row=0,sticky=E)
        self.SEXSourceTypes.menu=Menu(self.SEXSourceTypes,tearoff=0)
        self.SEXSourceTypes["menu"]=self.SEXSourceTypes.menu
        self.SEXSourceTypes.menu.add_checkbutton(label="Radio-quiet AGN",variable=self.RQAGNVar,selectcolor="blue")
        self.SEXSourceTypes.menu.add_checkbutton(label="FRI",variable=self.FRIVar,selectcolor="blue")
        self.SEXSourceTypes.menu.add_checkbutton(label="FRII",variable=self.FRIIVar,selectcolor="blue")
        self.SEXSourceTypes.menu.add_checkbutton(label="Normal galaxies",variable=self.DiskSFGVar,selectcolor="blue")
        self.SEXSourceTypes.menu.add_checkbutton(label="Starburst galaxies",variable=self.NuclearSFGVar,selectcolor="blue")
        self.SEXSourceTypes.configure(state=DISABLED)

        self.SEXGPSMenu=Menubutton(self.CatalogFrame,text="GPS",relief=GROOVE,width=3)
        self.SEXGPSMenu.grid(column=2,row=0,sticky=E)
        self.SEXGPSMenu.menu=Menu(self.SEXGPSMenu,tearoff=0)
        self.SEXGPSMenu["menu"]=self.SEXGPSMenu.menu
        self.SEXGPSMenu.menu.add_radiobutton(label="Select both GPS and non-GPS sources",variable=self.GPSVar,value=0,selectcolor="blue")
        self.SEXGPSMenu.menu.add_radiobutton(label="Select non-GPS sources only",variable=self.GPSVar,value=1,command=self.CheckGPS,selectcolor="blue")
        self.SEXGPSMenu.menu.add_radiobutton(label="Select GPS sources only",variable=self.GPSVar,value=2,selectcolor="blue")
        self.SEXGPSMenu.configure(state=DISABLED)

#       	self.ResetSEXSourceTypesButton=Button(self.CatalogFrame,text="Reset",command=self.ResetSEXSourceTypes,relief=GROOVE,width=4)
#        self.ResetSEXSourceTypesButton.grid(row=0,column=3,sticky=W)
#        self.ResetSEXSourceTypesButton.configure(state=DISABLED)

#        self.BSLButton=Checkbutton(self.CatalogFrame,text="Force Source List",variable=self.BuildSourceList,selectcolor="Blue",command=self.Toggle_BSL)
#        self.BSLButton.grid(column=4,row=0,sticky=W)
##        self.STOButton=Checkbutton(self.CatalogFrame,text="Selected Types Only",variable=self.SelectedTypes,selectcolor="Blue")
##        self.STOButton.grid(column=3,row=3,sticky=W)
#        self.BSLButton.configure(state=DISABLED)
##        self.STOButton.configure(state=DISABLED)

        self.OptionsFrame=Frame(self,height=80,width=400)
        self.OptionsFrame.grid(sticky=W)

	self.Continuum_Checkbutton=Checkbutton(self.OptionsFrame,text="Continuum",variable=self.Include_Continuum,selectcolor="Blue")
        self.Continuum_Checkbutton.grid(row=0,column=0,sticky=W)
        self.Continuum_Checkbutton.configure(state=DISABLED)
	self.HI_Checkbutton=Checkbutton(self.OptionsFrame,text="HI line",variable=self.Include_HI,selectcolor="Blue")
        self.HI_Checkbutton.grid(row=1,column=0,sticky=W)
        self.HI_Checkbutton.configure(state=DISABLED)
        self.HIMenu=Menubutton(self.OptionsFrame,text="HI Data",relief=GROOVE,width=9)
        self.HIMenu.grid(column=1,row=1,sticky=E)
        self.HIMenu.menu=Menu(self.HIMenu,tearoff=0)
        self.HIMenu["menu"]=self.HIMenu.menu
        self.HIMenu.menu.add_radiobutton(label="Oxford",variable=self.HIVar,value="Oxford",selectcolor="blue")
        self.HIMenu.menu.add_radiobutton(label="Kapteyn",variable=self.HIVar,value="Kapteyn",selectcolor="blue")
        self.HIMenu.configure(state=DISABLED)

	self.CO_Checkbutton=Checkbutton(self.OptionsFrame,text="CO lines",variable=self.Include_CO,selectcolor="Blue")
        self.CO_Checkbutton.grid(row=2,column=0,sticky=W)
        self.CO_Checkbutton.configure(state=DISABLED)
        self.CO_line_menu=Menubutton(self.OptionsFrame,text="Transitions",relief=GROOVE,width=9)
        self.CO_line_menu.grid(column=1,row=2,sticky=E)
        self.CO_line_menu.menu=Menu(self.CO_line_menu,tearoff=0)
        self.CO_line_menu["menu"]=self.CO_line_menu.menu

        self.CO_line_menu.menu.add_checkbutton(label="J=1-0",variable=self.co10Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=2-1",variable=self.co21Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=3-2",variable=self.co32Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=4-3",variable=self.co43Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=5-4",variable=self.co54Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=6-5",variable=self.co65Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=7-6",variable=self.co76Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=8-7",variable=self.co87Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=9-8",variable=self.co98Var,selectcolor="blue")
        self.CO_line_menu.menu.add_checkbutton(label="J=10-9",variable=self.co109Var,selectcolor="blue")
        self.CO_line_menu.configure(state=DISABLED)

        self.Select_CO_Label=Label(self.OptionsFrame,text="  Select ")
	self.Select_CO_Label.grid(column=2,row=2,sticky=W,padx=4)

       	self.Select_all_CO_Button=Button(self.OptionsFrame,text="All",command=self.Select_all_CO,relief=GROOVE)
        self.Select_all_CO_Button.grid(row=2,column=3,sticky=W)
        self.Select_all_CO_Button.configure(state=DISABLED)
       	self.Deselect_all_CO_Button=Button(self.OptionsFrame,text="None",command=self.Deselect_all_CO,relief=GROOVE)
        self.Deselect_all_CO_Button.grid(row=2,column=4,sticky=W)
        self.Deselect_all_CO_Button.configure(state=DISABLED)

        self.ReverseRA_Button=Checkbutton(self.OptionsFrame,text="Reverse R.A.",variable=self.ReverseRA,selectcolor="Blue")
        self.ReverseRA_Button.grid(column=3,row=7,sticky=W,columnspan=2)

        self.GSM_Button=Checkbutton(self.OptionsFrame,text="Global Sky Model",variable=self.IncludeGSM,selectcolor="Blue")
        self.GSM_Button.grid(column=0,row=5,sticky=W)
        self.GSM_Button.configure(state=DISABLED)

        self.CMB_Button=Checkbutton(self.OptionsFrame,text="CMB",variable=self.IncludeCMB,selectcolor="Blue")
        self.CMB_Button.grid(column=0,row=6,sticky=W)
        self.CMB_Button.configure(state=DISABLED)

        self.EOR_Button=Checkbutton(self.OptionsFrame,text="EoR signal",variable=self.IncludeEOR,selectcolor="Blue")
        self.EOR_Button.grid(column=0,row=4,sticky=W)
        self.EOR_Button.configure(state=DISABLED)

        self.EORMenu=Menubutton(self.OptionsFrame,text="EOR Data",relief=GROOVE,width=9)
        self.EORMenu.grid(column=1,row=4,sticky=E)
        self.EORMenu.menu=Menu(self.EORMenu,tearoff=0)
        self.EORMenu["menu"]=self.EORMenu.menu
        self.EORMenu.menu.add_radiobutton(label="Lisbon",variable=self.EORVar,value=0,selectcolor="blue")
#        self.EORMenu.menu.add_radiobutton(label="Paris",variable=self.EORVar,value=1,selectcolor="blue")
        self.EORMenu.configure(state=DISABLED)

#        self.I_Button=Checkbutton(self.OptionsFrame,text="I",variable=self.I,selectcolor="Blue")
#        self.I_Button.grid(column=3,row=0,sticky=W)
#        self.Q_Button=Checkbutton(self.OptionsFrame,text="Q",variable=self.Q,selectcolor="Blue")
#        self.Q_Button.grid(column=3,row=1,sticky=W)
#        self.U_Button=Checkbutton(self.OptionsFrame,text="U",variable=self.U,selectcolor="Blue")
#        self.U_Button.grid(column=4,row=0,sticky=W)
#        self.V_Button=Checkbutton(self.OptionsFrame,text="V",variable=self.V,selectcolor="Blue")
#        self.V_Button.grid(column=4,row=1,sticky=W)
#        self.V_Button.configure(state=DISABLED)

        self.ContinuumPolarization=Menubutton(self.OptionsFrame,text="I,Q,U,V",relief=GROOVE,width=9)
        self.ContinuumPolarization.grid(column=1,row=0,sticky=W)
        self.ContinuumPolarization.menu=Menu(self.ContinuumPolarization,tearoff=0)
        self.ContinuumPolarization["menu"]=self.ContinuumPolarization.menu
        self.ContinuumPolarization.menu.add_checkbutton(label="Total intensity",variable=self.TotalIntensityVar,selectcolor="blue")
        self.ContinuumPolarization.menu.add_checkbutton(label="Linear polarization",variable=self.LinearPolarizationVar,selectcolor="blue")
        self.ContinuumPolarization.configure(state=DISABLED)

        self.ZAXIS_TYPE_Menu=Menubutton(self.OptionsFrame,text="Z-axis",relief=GROOVE,width=6)
        self.ZAXIS_TYPE_Menu.grid(column=2,row=7,sticky=W)
        self.ZAXIS_TYPE_Menu.menu=Menu(self.ZAXIS_TYPE_Menu,tearoff=0)
        self.ZAXIS_TYPE_Menu["menu"]=self.ZAXIS_TYPE_Menu.menu
        self.ZAXIS_TYPE_Menu.menu.add_radiobutton(label="Velocity",variable=self.ZAXIS_TYPE_Var,value=0,selectcolor="blue")
        self.ZAXIS_TYPE_Menu.menu.add_radiobutton(label="Frequency",variable=self.ZAXIS_TYPE_Var,value=1,selectcolor="blue")
        self.ZAXIS_TYPE_Menu.menu.add_radiobutton(label="Wavelength",variable=self.ZAXIS_TYPE_Var,value=2,selectcolor="blue")


        self.image_accuracy_Label=Label(self.OptionsFrame,text="Image accuracy")
	self.image_accuracy_Label.grid(column=0,row=7,sticky=W,padx=4)
	self.image_accuracy_Entry=Entry(self.OptionsFrame,relief=GROOVE,textvariable=self.image_accuracy,bg="white",selectbackground="yellow",width=6,justify=RIGHT)
	self.image_accuracy_Entry.grid(column=1,row=7,sticky=W)
	self.image_accuracy_Entry.configure(state=DISABLED)

#        self.MapChoice=Radiobutton(self.OptionsFrame,text="Velocity  ",variable=self.FreqVeloAxis,value=1,command=self.ChooseVelo,padx=0)
#        self.MapChoice.grid(row=0,column=2,sticky=W)

#        self.CubeChoice=Radiobutton(self.OptionsFrame,text="Frequency  ",variable=self.FreqVeloAxis,value=2,command=self.ChooseFreq,padx=0)
#        self.CubeChoice.grid(row=1,column=2,sticky=W)

        self.ReferenceFrame=Frame(self,height=80,width=400)
        self.ReferenceFrame.grid(sticky=W)

#        self.Label=Label(self.ReferenceFrame,text=":")
#        self.Label.grid(column=0,row=1,sticky=W,padx=4)
        self.Label=Label(self.ReferenceFrame,text="R.A.")
        self.Label.grid(column=1,row=1)
        self.RefPos_RA_Display=AngleDisplay(self.ReferenceFrame)
        self.RefPos_RA_Display.grid(column=2,row=1)
        self.Label=Label(self.ReferenceFrame,text="[h:m:s]")
        self.Label.grid(column=3,row=1,sticky=W)
        self.Label=Label(self.ReferenceFrame,text="Dec.")
        self.Label.grid(column=1,row=2)
        self.RefPos_DEC_Display=AngleDisplay(self.ReferenceFrame)
        self.RefPos_DEC_Display.grid(column=2,row=2)
        self.Label=Label(self.ReferenceFrame,text="[d:':\"]")
        self.Label.grid(column=3,row=2,sticky=W)
        self.Useref_Button=Checkbutton(self.ReferenceFrame,text="Map Center",variable=self.UseRefPos,selectcolor="Blue")
        self.Useref_Button.grid(column=0,row=1,sticky=W)

	self.RefPos_RA_Display.Angle_signe.set("+")
	self.RefPos_RA_Display.Angle_deg.set(12)
	self.RefPos_DEC_Display.Angle_signe.set("+")

	self.MakeSeparationLine()

        self.MainButtonsFrame=Frame(self,height=80,width=400)
        self.MainButtonsFrame.grid()

       	self.AboutButton=Button(self.MainButtonsFrame,text="About",command=self.display_info,relief=GROOVE,width=6)
        self.AboutButton.grid(row=0,column=0,sticky=W)

       	self.HelpButton=Button(self.MainButtonsFrame,text="Help",command=self.display_help,relief=GROOVE,width=6)
        self.HelpButton.grid(row=0,column=1,sticky=W)

#        self.PreviewButton=Button(self.MainButtonsFrame,text="Field",command=self.PreviewCommand,relief=GROOVE,width=5)
#        self.PreviewButton.grid(row=0,column=2,sticky=W)

        self.ShowButton=Button(self.MainButtonsFrame,text="Show",command=self.ShowCommand,relief=GROOVE,width=6)
        self.ShowButton.grid(row=0,column=3,sticky=W)

        self.RunButton=Button(self.MainButtonsFrame,text="Run",command=self.RunCommand,relief=GROOVE,width=6)
        self.RunButton.grid(row=0,column=4,sticky=W)

        self.QuitButton=Button(self.MainButtonsFrame,text="Quit",command=self.quit,relief=GROOVE,width=6)
        self.QuitButton.grid(row=0,column=5)

    def Update_Size(self):
        self.Apply_window_and_pixel_to_image_size()

#    def Apply_window_and_image_to_pixel_size(self):
#        minX=dms2deg([self.Min_X_Display.Angle_signe.get(),self.Min_X_Display.Angle_deg.get(),self.Min_X_Display.Angle_min.get(),self.Min_X_Display.Angle_sec.get()])
#        maxX=dms2deg([self.Max_X_Display.Angle_signe.get(),self.Max_X_Display.Angle_deg.get(),self.Max_X_Display.Angle_min.get(),self.Max_X_Display.Angle_sec.get()])
#        minY=dms2deg([self.Min_Y_Display.Angle_signe.get(),self.Min_Y_Display.Angle_deg.get(),self.Min_Y_Display.Angle_min.get(),self.Min_Y_Display.Angle_sec.get()])
#        maxY=dms2deg([self.Max_Y_Display.Angle_signe.get(),self.Max_Y_Display.Angle_deg.get(),self.Max_Y_Display.Angle_min.get(),self.Max_Y_Display.Angle_sec.get()])
#        WX=maxX-minX
#        WY=maxY-minY
#        Nx=self.ImageSize_X.get()
#        Ny=self.ImageSize_Y.get()
#        if ((Nx>0) and (Ny>0)):
#            dx=WX/float(Nx)
#            dy=WY/float(Ny)
#            
#        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="arcsecs"):dx=arcsec2deg(self.PixelSize.get())
#        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="arcmins"):dx=arcmin2deg(self.PixelSize.get())
#        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="degrees"):dx=self.PixelSize.get()
#        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="radians"):dx=rad2deg(self.PixelSize.get())
#        Nx=int(math.ceil(WX/dx))
#        Ny=int(math.ceil(WY/dx))
#        self.ImageSize_X.set(Nx)
#        self.ImageSize_Y.set(Ny)

    def Select_all_CO(self):
        self.co10Var.set(1)
        self.co21Var.set(1)
        self.co32Var.set(1)
        self.co43Var.set(1)
        self.co54Var.set(1)
        self.co65Var.set(1)
        self.co76Var.set(1)
        self.co87Var.set(1)
        self.co98Var.set(1)
        self.co109Var.set(1)

    def Deselect_all_CO(self):
        self.co10Var.set(0)
        self.co21Var.set(0)
        self.co32Var.set(0)
        self.co43Var.set(0)
        self.co54Var.set(0)
        self.co65Var.set(0)
        self.co76Var.set(0)
        self.co87Var.set(0)
        self.co98Var.set(0)
        self.co109Var.set(0)

    def Apply_Z_Range(self):
        if (self.Z_LINE_Var.get()==0):
            nu0=constant("nu0_HI")
        else:
            nu0=self.Z_LINE_Var.get()*constant("nu0_CO")
        numin=redshift2freq(self.ZMAX.get(),nu0)
        numax=redshift2freq(self.ZMIN.get(),nu0)        
        if (numin>1000.0):
            self.minObsFreq_Display.Freq.set(numin/1000.0)
            self.CRVALnu_UNIT_Var.set(0)
            self.Set_CRVALnu_UNIT()
        if ((numin>1.0)and(numin<=1000.0)):
            self.minObsFreq_Display.Freq.set(numin)
            self.CRVALnu_UNIT_Var.set(1)
            self.Set_CRVALnu_UNIT()
        if (numin<=1.0):
            self.minObsFreq_Display.Freq.set(numin*1000.0)
            self.CRVALnu_UNIT_Var.set(2)
            self.Set_CRVALnu_UNIT()
        deltanu=(numax-numin)/self.Nfreq.get()
        if (deltanu>1000.0):
            self.SpectralResolution_Display.Freq.set(deltanu/1000.0)
            self.CDELTnu_UNIT_Var.set(0)
            self.Set_CDELTnu_UNIT()
        if ((deltanu>1.0)and(deltanu<=1000.0)):
            self.SpectralResolution_Display.Freq.set(deltanu)
            self.CDELTnu_UNIT_Var.set(1)
            self.Set_CDELTnu_UNIT()
        if (deltanu<=1):
            self.SpectralResolution_Display.Freq.set(deltanu*1000.0)
            if (self.SpectralResolution_Display.Freq.get()==0):
                self.SpectralResolution_Display.Freq.set(default_spectral_width)                                
            self.CDELTnu_UNIT_Var.set(2)
            self.Set_CDELTnu_UNIT()

    def refresh_filename(self):
        self.qid.set("map_"+((self.DB.get()).replace("S3","")+"_"+strftime("%Y-%m-%d %H:%M:%S")).replace(" ","_").replace(":","."))        

    def InitializeSEXSourceTypes(self):
        self.RQAGNVar.set(1)
        self.FRIVar.set(1)
        self.FRIIVar.set(1)
        self.DiskSFGVar.set(1)
        self.NuclearSFGVar.set(1)

    def ResetSEXSourceTypes(self):
        self.InitializeSEXSourceTypes()
        self.CheckGPS()
        self.GPSVar.set(0)

    def Set_BMAJ_UNIT(self):
        self.BMAJ_UNIT_Value.set(self.angle_units[self.BMAJ_UNIT_Var.get()])
    def Set_BMIN_UNIT(self):
        self.BMIN_UNIT_Value.set(self.angle_units[self.BMIN_UNIT_Var.get()])
    def Set_BPA_UNIT(self):
        self.BPA_UNIT_Value.set(self.angle_units[self.BPA_UNIT_Var.get()])
    def Set_CDELTX_UNIT(self):
        self.CDELTX_UNIT_Value.set(self.angle_units[self.CDELTX_UNIT_Var.get()])
    def Set_CDELTnu_UNIT(self):
        self.CDELTnu_UNIT_Value.set(self.frequency_units[self.CDELTnu_UNIT_Var.get()])
    def Set_CRVALnu_UNIT(self):
        self.CRVALnu_UNIT_Value.set(self.frequency_units[self.CRVALnu_UNIT_Var.get()])

    def CheckGPS(self):
        if ((self.FRIVar.get()==1) or (self.FRIIVar.get()==1)):
            self.SEXGPSMenu.configure(state=NORMAL)
        else:
            self.SEXGPSMenu.configure(state=DISABLED)

    def browse_source_list_file(self):
        self.loaded_source_list_file = tkFileDialog.askopenfile(parent=self,mode='rb',title='Choose a file')

    def browse_outputdir(self):
	self.outputdirchoice=tkFileDialog.askdirectory(parent=self,initialdir=self.outputdir.get(),title="Choose a directory")
        if (len(self.outputdirchoice)>0):
            self.outputdir.set(self.outputdirchoice+"/")

    def Initialize_SAX(self,query_file):
        from Config_SAX import HI_INTFLUX,HI_AXIS_RATIO,HI_MAJOR_AXIS_10MAX,HI_LINEWIDTH20,HI_LINEWIDTH50,CO_1_0_INTFLUX,CO_2_1_INTFLUX,CO_3_2_INTFLUX,CO_4_3_INTFLUX,CO_5_4_INTFLUX,CO_6_5_INTFLUX,CO_7_6_INTFLUX,CO_8_7_INTFLUX,CO_9_8_INTFLUX,CO_10_9_INTFLUX,H2_AXIS_RATIO,H2_MAJOR_AXIS_10MAX,CO_LINEWIDTH20,CO_LINEWIDTH50
        self.Continuum_Checkbutton.configure(state=NORMAL)
        self.ContinuumPolarization.configure(state=NORMAL)
        self.GSM_Button.configure(state=NORMAL)
        self.CMB_Button.configure(state=NORMAL)
        self.EOR_Button.configure(state=NORMAL)
        self.EORMenu.configure(state=NORMAL)
        self.Deselect_all_CO_Button.configure(state=NORMAL)
        self.Select_all_CO_Button.configure(state=NORMAL)
        galaxy_items=read_info(query_file,"GALAXY_ITEMS").split(",")
        if ((HI_INTFLUX in galaxy_items)and(HI_AXIS_RATIO in galaxy_items)and(HI_MAJOR_AXIS_10MAX in galaxy_items)and(HI_LINEWIDTH20 in galaxy_items)and(HI_LINEWIDTH50 in galaxy_items)):
            self.HI_Checkbutton.configure(state=NORMAL)
            self.HIMenu.configure(state=NORMAL)
            self.Include_HI.set(1)
        if ((CO_1_0_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co10Var.set(1)
        if ((CO_2_1_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co21Var.set(1)
        if ((CO_3_2_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co32Var.set(1)
        if ((CO_4_3_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co43Var.set(1)
        if ((CO_5_4_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co54Var.set(1)
        if ((CO_6_5_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co65Var.set(1)
        if ((CO_7_6_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co76Var.set(1)
        if ((CO_8_7_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co87Var.set(1)
        if ((CO_9_8_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co98Var.set(1)
        if ((CO_10_9_INTFLUX in galaxy_items)and(H2_AXIS_RATIO in galaxy_items)and(H2_MAJOR_AXIS_10MAX in galaxy_items)and(CO_LINEWIDTH20 in galaxy_items)and(CO_LINEWIDTH50 in galaxy_items)):
            self.CO_Checkbutton.configure(state=NORMAL)
            self.CO_line_menu.configure(state=NORMAL)
            self.Include_CO.set(1)
            self.co109Var.set(1)
        self.SEXSourceTypes.configure(state=DISABLED)
        self.SEXGPSMenu.configure(state=DISABLED)
        #self.ResetSEXSourceTypesButton.configure(state=DISABLED)
        self.Include_Continuum.set(0)
        self.TotalIntensityVar.set(0)
        self.LinearPolarizationVar.set(0)

    def Initialize_SEX(self,query_file):
#        import Config_SEX 
        types=read_info(query_file,"TYPES").split(",")
        if ('RQAGN' in types):self.RQAGNVar.set(1)
        else:
            self.RQAGNVar.set(0)
            self.SEXSourceTypes.menu.entryconfigure(0,state=DISABLED)
        if ('FRI' in types):self.FRIVar.set(1)
        else:
            self.FRIVar.set(0)
            self.SEXSourceTypes.menu.entryconfigure(1,state=DISABLED)
        if ('FRII' in types):self.FRIIVar.set(1)
        else:
            self.FRIIVar.set(0)
            self.SEXSourceTypes.menu.entryconfigure(2,state=DISABLED)
        if ('SFG' in types):self.DiskSFGVar.set(1)
        else:
            self.DiskSFGVar.set(0)
            self.SEXSourceTypes.menu.entryconfigure(3,state=DISABLED)
        if ('SBG' in types):self.NuclearSFGVar.set(1)
        else:
            self.NuclearSFGVar.set(0)
            self.SEXSourceTypes.menu.entryconfigure(4,state=DISABLED)
        GPS=read_info(query_file,"GPS")
        if (GPS=='YES'):
            self.GPSVar.set(0)
            self.SEXGPSMenu.configure(state=NORMAL)
        if (GPS=='NO'):
            self.GPSVar.set(1)
            self.SEXGPSMenu.configure(state=DISABLED)
#        if (GPS=='GPS-only'):self.GPSVar.set(2)
        self.SEXSourceTypes.configure(state=NORMAL)        
        #self.ResetSEXSourceTypesButton.configure(state=NORMAL)

        self.CO_Checkbutton.configure(state=DISABLED)
        self.CO_line_menu.configure(state=DISABLED)
        self.HI_Checkbutton.configure(state=NORMAL)
        self.HIMenu.configure(state=DISABLED)
        self.Include_CO.set(0)
        self.Include_HI.set(0)
        self.Include_Continuum.set(1)
        self.Continuum_Checkbutton.configure(state=NORMAL)
        self.ContinuumPolarization.configure(state=NORMAL)
        self.GSM_Button.configure(state=NORMAL)
        self.CMB_Button.configure(state=NORMAL)
        self.EOR_Button.configure(state=NORMAL)
        self.EORMenu.configure(state=NORMAL)
        self.Deselect_all_CO_Button.configure(state=NORMAL)
        self.Select_all_CO_Button.configure(state=NORMAL)

        self.TotalIntensityVar.set(1)

    def Initialize_redshift_window(self,query_file):
        srw=read_info(query_file,"REDSHIFT").split(",")
        rw=[]
        for s in srw:rw.append(float(s))
        self.ZMIN.set(min(rw))
        self.ZMAX.set(max(rw))

    def Initialize_spatial_window(self,query_file):
        sqw=read_info(query_file,"WINDOW").split(",")
        qw=[]
        for s in sqw:qw.append(float(s))
        
        if (len(qw)==4):
            self.Min_X_From_Query_sgn.set(deg2dms(qw[0])[0])
            self.Min_X_From_Query_deg.set(deg2dms(qw[0])[1])
            self.Min_X_From_Query_min.set(deg2dms(qw[0])[2])
            self.Min_X_From_Query_sec.set(deg2dms(qw[0])[3])
            self.Max_X_From_Query_sgn.set(deg2dms(qw[1])[0])
            self.Max_X_From_Query_deg.set(deg2dms(qw[1])[1])
            self.Max_X_From_Query_min.set(deg2dms(qw[1])[2])
            self.Max_X_From_Query_sec.set(deg2dms(qw[1])[3])
            self.Min_Y_From_Query_sgn.set(deg2dms(qw[2])[0])
            self.Min_Y_From_Query_deg.set(deg2dms(qw[2])[1])
            self.Min_Y_From_Query_min.set(deg2dms(qw[2])[2])
            self.Min_Y_From_Query_sec.set(deg2dms(qw[2])[3])
            self.Max_Y_From_Query_sgn.set(deg2dms(qw[3])[0])
            self.Max_Y_From_Query_deg.set(deg2dms(qw[3])[1])
            self.Max_Y_From_Query_min.set(deg2dms(qw[3])[2])
            self.Max_Y_From_Query_sec.set(deg2dms(qw[3])[3])
        if (len(qw)==3):
            self.Min_X_From_Query_sgn.set(deg2dms(qw[0]-qw[2])[0])
            self.Min_X_From_Query_deg.set(deg2dms(qw[0]-qw[2])[1])
            self.Min_X_From_Query_min.set(deg2dms(qw[0]-qw[2])[2])
            self.Min_X_From_Query_sec.set(deg2dms(qw[0]-qw[2])[3])
            self.Max_X_From_Query_sgn.set(deg2dms(qw[0]+qw[2])[0])
            self.Max_X_From_Query_deg.set(deg2dms(qw[0]+qw[2])[1])
            self.Max_X_From_Query_min.set(deg2dms(qw[0]+qw[2])[2])
            self.Max_X_From_Query_sec.set(deg2dms(qw[0]+qw[2])[3])
            self.Min_Y_From_Query_sgn.set(deg2dms(qw[1]-qw[2])[0])
            self.Min_Y_From_Query_deg.set(deg2dms(qw[1]-qw[2])[1])
            self.Min_Y_From_Query_min.set(deg2dms(qw[1]-qw[2])[2])
            self.Min_Y_From_Query_sec.set(deg2dms(qw[1]-qw[2])[3])
            self.Max_Y_From_Query_sgn.set(deg2dms(qw[1]+qw[2])[0])
            self.Max_Y_From_Query_deg.set(deg2dms(qw[1]+qw[2])[1])
            self.Max_Y_From_Query_min.set(deg2dms(qw[1]+qw[2])[2])
            self.Max_Y_From_Query_sec.set(deg2dms(qw[1]+qw[2])[3])
            
        self.Min_X_Display.Angle_signe.set(self.Min_X_From_Query_sgn.get())
        self.Min_X_Display.Angle_deg.set(self.Min_X_From_Query_deg.get())
        self.Min_X_Display.Angle_min.set(self.Min_X_From_Query_min.get())
        self.Min_X_Display.Angle_sec.set(self.Min_X_From_Query_sec.get())
        self.Min_Y_Display.Angle_signe.set(self.Min_Y_From_Query_sgn.get())
        self.Min_Y_Display.Angle_deg.set(self.Min_Y_From_Query_deg.get())
        self.Min_Y_Display.Angle_min.set(self.Min_Y_From_Query_min.get())
        self.Min_Y_Display.Angle_sec.set(self.Min_Y_From_Query_sec.get())
        
        self.Max_X_Display.Angle_signe.set(self.Max_X_From_Query_sgn.get())
        self.Max_X_Display.Angle_deg.set(self.Max_X_From_Query_deg.get())
        self.Max_X_Display.Angle_min.set(self.Max_X_From_Query_min.get())
        self.Max_X_Display.Angle_sec.set(self.Max_X_From_Query_sec.get())
        self.Max_Y_Display.Angle_signe.set(self.Max_Y_From_Query_sgn.get())
        self.Max_Y_Display.Angle_deg.set(self.Max_Y_From_Query_deg.get())
        self.Max_Y_Display.Angle_min.set(self.Max_Y_From_Query_min.get())
        self.Max_Y_Display.Angle_sec.set(self.Max_Y_From_Query_sec.get())

        self.Min_X_Display.configure(state=DISABLED)
        self.Max_X_Display.configure(state=DISABLED)
        self.Min_Y_Display.configure(state=DISABLED)
        self.Max_Y_Display.configure(state=DISABLED)

        self.Apply_window_and_pixel_to_image_size()

    def Apply_window_and_pixel_to_image_size(self):
        minX=dms2deg([self.Min_X_Display.Angle_signe.get(),self.Min_X_Display.Angle_deg.get(),self.Min_X_Display.Angle_min.get(),self.Min_X_Display.Angle_sec.get()])
        maxX=dms2deg([self.Max_X_Display.Angle_signe.get(),self.Max_X_Display.Angle_deg.get(),self.Max_X_Display.Angle_min.get(),self.Max_X_Display.Angle_sec.get()])
        minY=dms2deg([self.Min_Y_Display.Angle_signe.get(),self.Min_Y_Display.Angle_deg.get(),self.Min_Y_Display.Angle_min.get(),self.Min_Y_Display.Angle_sec.get()])
        maxY=dms2deg([self.Max_Y_Display.Angle_signe.get(),self.Max_Y_Display.Angle_deg.get(),self.Max_Y_Display.Angle_min.get(),self.Max_Y_Display.Angle_sec.get()])
        WX=maxX-minX
        WY=maxY-minY
        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="arcsecs"):dx=arcsec2deg(self.PixelSize.get())
        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="arcmins"):dx=arcmin2deg(self.PixelSize.get())
        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="degrees"):dx=self.PixelSize.get()
        if (self.angle_units[self.CDELTX_UNIT_Var.get()]=="radians"):dx=rad2deg(self.PixelSize.get())
        Nx=int(math.ceil(WX/dx))
        Ny=int(math.ceil(WY/dx))
        self.ImageSize_X.set(Nx)
        self.ImageSize_Y.set(Ny)

    def browse_input(self):
	self.inputchoice=tkFileDialog.askopenfilename(parent=self,title="Choose a .tar or .tar.gz file",filetypes=[('Tarball','*.tar.gz'),('Tarball','*.tar')])
        if (len(self.inputchoice)>0):
            self.input.set(self.inputchoice)
            s=os.path.basename(self.input.get()).split(".")
            self.in_id.set(".".join(s[0:s.index('tar')]))
            self.dir.set(os.path.dirname(self.input.get()))
            
            self.Min_X_From_Query.set(1)
            self.Max_X_From_Query.set(1)
            self.Min_Y_From_Query.set(1)
            self.Max_Y_From_Query.set(1)

#            # CLEAN TMP DIRECTORY
#            os.popen("rm -f "+SCRATCH_DIR+"/*")

            # COPY INPUT QUERY TARBALL TO TMP DIRECTORY
            os.popen("cp "+self.input.get()+" "+SCRATCH_DIR)
            
            # RELOCATE TO TMP DIRECTORY
            os.chdir(SCRATCH_DIR)
                        
            # UNTAR INPUT QUERY TARBALL
            if os.path.isfile(self.in_id.get()+".tar.gz"):
                os.popen("tar xzf "+self.in_id.get()+".tar.gz")
            if os.path.isfile(self.in_id.get()+".tar"):
                os.popen("tar xf "+self.in_id.get()+".tar")
#            # REMOVE TARBALL IN TMP DIRECTORY
#                os.popen("rm -f "+self.in_id.get()+".tar*")
            query_file=self.in_id.get()+".query"

            # DETERMINE WHETHER SEX OR SAX HERE...
            result_file=self.in_id.get()+".result"            
            DB=which_database(result_file)
                        
            if (not(os.path.isfile(query_file))):
                if (DB=="S3SAX"):SAX_create_query_file(SCRATCH_DIR,self.in_id.get())
                if (DB=="S3SEX"):SEX_create_query_file(SCRATCH_DIR,self.in_id.get())
#                os.popen("rm -f "+self.input.get())
#                if os.path.isfile(self.in_id.get()+".tar.gz"):
#                    os.popen("tar zcf "+self.input.get()+" "+self.in_id.get()+".*")
#                if os.path.isfile(self.in_id.get()+".tar"):
#                    os.popen("tar cf "+self.input.get()+" "+self.in_id.get()+".*")                
            self.DB.set(read_info(query_file,"DB"))
            self.MapCubeNameRefresh.configure(state=NORMAL)
            self.refresh_filename()
            if (self.DB.get()=="S3SAX"):
                self.Initialize_SAX(query_file)
            if (self.DB.get()=="S3SEX"):
                self.Initialize_SEX(query_file)
            self.Initialize_spatial_window(query_file)
            self.Initialize_redshift_window(query_file)
#            # READ QUERY RESULT, WINDOW AND STRUCTURE FILES OR INFO FILE
#            # MUST BE BACKWARD-COMPATIBLE
#            query_info_file=self.in_id.get()+'.query.info'
#            if (os.path.isfile(query_info_file)): # INFO FILE EXISTS
#                qi=read_query_info(SCRATCH_DIR+"/"+query_info_file)
##                [i_db,column_list,window,zwindow,types]
#                qw=qi[2]
#                if (qi[0]==0):self.ChooseSEX()
#                if (qi[0]==1):self.ChooseSAX()
#                if (qi[0]==0):
#                    # SELECT TYPES
#                    types=qi[4]
#                    if (1 in types):self.RQAGNVar.set(1)
#                    else:
#                        self.RQAGNVar.set(0)
#                        self.SEXSourceTypes.menu.entryconfigure(0,state=DISABLED)
#                    if (2 in types):self.FRIVar.set(1)
#                    else:
#                        self.FRIVar.set(0)
#                        self.SEXSourceTypes.menu.entryconfigure(1,state=DISABLED)
#                    if (3 in types):self.FRIIVar.set(1)
#                    else:
#                        self.FRIIVar.set(0)
#                        self.SEXSourceTypes.menu.entryconfigure(2,state=DISABLED)
#                    if (4 in types):self.DiskSFGVar.set(1)
#                    else:
#                        self.DiskSFGVar.set(0)
#                        self.SEXSourceTypes.menu.entryconfigure(3,state=DISABLED)
#                    if (5 in types):self.NuclearSFGVar.set(1)
#                    else:
#                        self.NuclearSFGVar.set(0)
#                        self.SEXSourceTypes.menu.entryconfigure(4,state=DISABLED)
##        self.SEXSourceTypes.menu.add_checkbutton(label="FRI",variable=self.FRIVar,selectcolor="blue")
##        self.SEXSourceTypes.menu.add_checkbutton(label="FRII",variable=self.FRIIVar,selectcolor="blue")
##        self.SEXSourceTypes.menu.add_checkbutton(label="Normal galaxies",variable=self.DiskSFGVar,selectcolor="blue")
##        self.SEXSourceTypes.menu.add_checkbutton(label="Starburst galaxies",variable=self.NuclearSFGVar,selectcolor="blue")
#
#            else:
#                self.RQAGNVar.set(1)
#                self.FRIVar.set(1)
#                self.FRIIVar.set(1)
#                self.DiskSFGVar.set(1)
#                self.NuclearSFGVar.set(1)
#                
#                self.SEXSourceTypes.menu.entryconfigure(0,state=NORMAL)
#                self.SEXSourceTypes.menu.entryconfigure(1,state=NORMAL)
#                self.SEXSourceTypes.menu.entryconfigure(2,state=NORMAL)
#                self.SEXSourceTypes.menu.entryconfigure(3,state=NORMAL)
#                self.SEXSourceTypes.menu.entryconfigure(4,state=NORMAL)
#                        
#                query_window_file=self.in_id.get()+'.query.window'
#                qw=read_query_window(SCRATCH_DIR+"/"+query_window_file)
#            os.popen("rm -rf "+self.in_id.get()+"*")


    def Toggle_Min_X_From_Query(self):
        if (self.Min_X_From_Query.get()==1):
            self.Min_X_Display.Angle_signe.set(self.Min_X_From_Query_sgn.get())
            self.Min_X_Display.Angle_deg.set(self.Min_X_From_Query_deg.get())
            self.Min_X_Display.Angle_min.set(self.Min_X_From_Query_min.get())
            self.Min_X_Display.Angle_sec.set(self.Min_X_From_Query_sec.get())
            self.Min_X_Display.configure(state=DISABLED)
        if (self.Min_X_From_Query.get()==0):
            self.Min_X_Display.configure(state=NORMAL)

    def Toggle_Max_X_From_Query(self):
        if (self.Max_X_From_Query.get()==1):
            self.Max_X_Display.Angle_signe.set(self.Max_X_From_Query_sgn.get())
            self.Max_X_Display.Angle_deg.set(self.Max_X_From_Query_deg.get())
            self.Max_X_Display.Angle_min.set(self.Max_X_From_Query_min.get())
            self.Max_X_Display.Angle_sec.set(self.Max_X_From_Query_sec.get())
            self.Max_X_Display.configure(state=DISABLED)
        if (self.Max_X_From_Query.get()==0):
            self.Max_X_Display.configure(state=NORMAL)

    def Toggle_Min_Y_From_Query(self):
        if (self.Min_Y_From_Query.get()==1):
            self.Min_Y_Display.Angle_signe.set(self.Min_Y_From_Query_sgn.get())
            self.Min_Y_Display.Angle_deg.set(self.Min_Y_From_Query_deg.get())
            self.Min_Y_Display.Angle_min.set(self.Min_Y_From_Query_min.get())
            self.Min_Y_Display.Angle_sec.set(self.Min_Y_From_Query_sec.get())
            self.Min_Y_Display.configure(state=DISABLED)
        if (self.Min_Y_From_Query.get()==0):
            self.Min_Y_Display.configure(state=NORMAL)

    def Toggle_Max_Y_From_Query(self):
        if (self.Max_Y_From_Query.get()==1):
            self.Max_Y_Display.Angle_signe.set(self.Max_Y_From_Query_sgn.get())
            self.Max_Y_Display.Angle_deg.set(self.Max_Y_From_Query_deg.get())
            self.Max_Y_Display.Angle_min.set(self.Max_Y_From_Query_min.get())
            self.Max_Y_Display.Angle_sec.set(self.Max_Y_From_Query_sec.get())
            self.Max_Y_Display.configure(state=DISABLED)
        if (self.Max_Y_From_Query.get()==0):
            self.Max_Y_Display.configure(state=NORMAL)

    def Toggle_BSL(self):
        if (self.BuildSourceList.get()==1):
            self.STOButton.configure(state=NORMAL)
        if (self.BuildSourceList.get()==0):
            self.STOButton.configure(state=DISABLED)
            self.SelectedTypes.set(0)

    def set_fullrange(self):
        self.FullRange.set(1-self.FullRange.get())
        if (self.FullRange.get()==1):
            self.BLC_RA_Display.configure(state=DISABLED)
            self.BLC_DEC_Display.configure(state=DISABLED)
            self.TRC_RA_Display.configure(state=DISABLED)
            self.TRC_DEC_Display.configure(state=DISABLED)
        else:
            self.BLC_RA_Display.configure(state=NORMAL)
            self.BLC_DEC_Display.configure(state=NORMAL)
            self.TRC_RA_Display.configure(state=NORMAL)
            self.TRC_DEC_Display.configure(state=NORMAL)

    def set_Limit_BLC_RA(self):
        if (self.Limit_BLC_RA.get()==1):
            self.BLC_RA_Display.configure(state=NORMAL)
        else:
            self.BLC_RA_Display.configure(state=DISABLED)

    def set_Limit_BLC_DEC(self):
        if (self.Limit_BLC_DEC.get()==1):
            self.BLC_DEC_Display.configure(state=NORMAL)
        else:
            self.BLC_DEC_Display.configure(state=DISABLED)

    def set_Limit_TRC_RA(self):
        if (self.Limit_TRC_RA.get()==1):
            self.TRC_RA_Display.configure(state=NORMAL)
        else:
            self.TRC_RA_Display.configure(state=DISABLED)

    def set_Limit_TRC_DEC(self):
        if (self.Limit_TRC_DEC.get()==1):
            self.TRC_DEC_Display.configure(state=NORMAL)
        else:
            self.TRC_DEC_Display.configure(state=DISABLED)


    def reset_refpos(self):
	self.RefPos_RA_Display.Angle_deg.set(0)
	self.RefPos_RA_Display.Angle_min.set(0)
	self.RefPos_RA_Display.Angle_sec.set(0.0)
	self.RefPos_DEC_Display.Angle_deg.set(0)
	self.RefPos_DEC_Display.Angle_min.set(0)
	self.RefPos_DEC_Display.Angle_sec.set(0.0)

    def MakeSeparationLine(self):

        self.SepLine1Canvas=Canvas(self,height=1)
        self.SepLine1Canvas.grid()

        self.SepLine1Canvas=Canvas(self,bg="black",height=1,width=400)
        self.SepLine1Canvas.grid()

        self.SepLine1Canvas=Canvas(self,height=1)
        self.SepLine1Canvas.grid()

    def ChooseQuery(self):
        app.QueryLoadChoice.set(1)
        app.SourceListBrowse.configure(state=DISABLED)
        app.BuildSourceList_Button.configure(state=NORMAL)

    def ChooseLoad(self):
        app.QueryLoadChoice.set(2)
        app.SourceListBrowse.configure(state=NORMAL)
        app.BuildSourceList_Button.configure(state=DISABLED)

    def ChooseSAX(self):	
        app.CatalogChoice.set(1)
        app.SEXSourceTypes.configure(state=DISABLED)
        #app.SmallScaleSourceTypes.configure(state=NORMAL)
        app.Include_Continuum.set(0)
        app.Include_HI.set(1)
        app.Include_CO.set(1)
        app.Continuum_Checkbutton.configure(state=DISABLED)
        app.CO_Checkbutton.configure(state=NORMAL)
        app.Q_Button.configure(state=DISABLED)
        app.U_Button.configure(state=DISABLED)
        app.image_accuracy_Entry.configure(state=DISABLED)
        app.SEXGPSMenu.configure(state=DISABLED)

    def ChooseSEX(self):
        app.CatalogChoice.set(0)
        app.SEXSourceTypes.configure(state=NORMAL)
        #app.SmallScaleSourceTypes.configure(state=DISABLED)
        app.Continuum_Checkbutton.configure(state=NORMAL)
        app.CO_Checkbutton.configure(state=DISABLED)
        app.Q_Button.configure(state=NORMAL)
        app.U_Button.configure(state=NORMAL)
        app.image_accuracy_Entry.configure(state=NORMAL)
        app.SEXGPSMenu.configure(state=NORMAL)

    def ChooseMap(self):	
        app.MapCubeChoice.set(1)
        app.Nfreq.set(1)
	app.Nfreq_Entry.configure(state=DISABLED)

    def ChooseCube(self):
        app.MapCubeChoice.set(2)
	app.Nfreq_Entry.configure(state=NORMAL)

    def ChooseVelo(self):	
        app.FreqVeloAxis.set(1)

    def ChooseFreq(self):
        app.FreqVeloAxis.set(2)

    def GetImageSize(self):
        minX=self.Min_X_Display.seconds()
        maxX=self.Max_X_Display.seconds()
        minY=self.Min_Y_Display.seconds()
        maxY=self.Max_Y_Display.seconds()
        if (self.CDELTX_UNIT_Var.get()==0):dx=self.PixelSize.get()
        if (self.CDELTX_UNIT_Var.get()==1):dx=arcmin2arcsec(self.PixelSize.get())
        if (self.CDELTX_UNIT_Var.get()==2):dx=deg2arcsec(self.PixelSize.get())
        if (self.CDELTX_UNIT_Var.get()==3):dx=rad2arcsec(self.PixelSize.get())
        Nxy=image_size([minX,maxX,minY,maxY],dx)
        Nx=Nxy[0]
        Ny=Nxy[1]
        Nz=self.Nfreq.get()
        return(Nx,Ny,Nz)
        
    def BuildCommand(self):
	self.minX=DoubleVar()
	self.maxX=DoubleVar()
	self.minY=DoubleVar()
	self.maxY=DoubleVar()
        self.minX.set(self.Min_X_Display.seconds())
        self.maxX.set(self.Max_X_Display.seconds())
        self.minY.set(self.Min_Y_Display.seconds())
        self.maxY.set(self.Max_Y_Display.seconds())

        self.windowVar=StringVar()
        self.windowVar.set(self.windowVar.get()+str(self.minX.get())+",")
        self.windowVar.set(self.windowVar.get()+str(self.maxX.get())+",")
        self.windowVar.set(self.windowVar.get()+str(self.minY.get())+",")
        self.windowVar.set(self.windowVar.get()+str(self.maxY.get()))

	self.RefPosVar=StringVar()
	self.RA_RefPos=DoubleVar()
	self.DEC_RefPos=DoubleVar()
        self.RA_RefPos.set(15.0*self.RefPos_RA_Display.seconds()/3600.)
        self.DEC_RefPos.set(self.RefPos_DEC_Display.seconds()/3600.0)

	self.SourceTypesLine=StringVar()
	self.FirstType=IntVar()
	self.FirstType.set(1)
        if self.RQAGNVar.get() == 1:
                self.SourceTypesLine.set(self.SourceTypesLine.get()+"1")
                self.FirstType.set(0)
        if self.FRIVar.get() == 1:
            if self.FirstType.get() == 0:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+",2")
            else:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+"2")
                    self.FirstType.set(0)
        if self.FRIIVar.get() == 1:
            if self.FirstType.get() == 0:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+",3")
            else:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+"3")
                    self.FirstType.set(0)
        if self.DiskSFGVar.get() == 1:
            if self.FirstType.get() == 0:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+",4")
            else:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+"4")
                    self.FirstType.set(0)
        if self.NuclearSFGVar.get() == 1:
            if self.FirstType.get() == 0:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+",5")
            else:
                    self.SourceTypesLine.set(self.SourceTypesLine.get()+"5")
                    self.FirstType.set(0)

        if (self.qid.get()==""):
            self.qid.set(str(time()))

# CHECK THAT INPUT IS SET
        if (self.input.get()==""):
            print "Please select an input .tar.gz file containing query results."
            cmd=""
# CHECK THAT HI AND/OR CONTINUUM IS SET
        if ((self.Include_Continuum.get()==0) and (self.Include_HI.get()==0) and (self.Include_CO.get()==0)):
            print "A least one of the 'Continuum', 'HI line' and 'CO lines' checkboxes must be ticked."
            cmd=""
        if ((self.input.get()!="") and ((self.Include_Continuum.get()!=0) or (self.Include_HI.get()!=0) or (self.Include_CO.get()!=0))):
# HERE CHECK FOR SOURCE LIST PRESENCE
#            # COPY INPUT QUERY TARBALL TO TMP DIRECTORY
#            os.popen("cp "+self.input.get()+" "+SCRATCH_DIR)
#            
#            # RELOCATE TO OUTPUT DIRECTORY
#            os.chdir(SCRATCH_DIR)
#            
#            # UNTAR INPUT QUERY TARBALL
#            if os.path.isfile(self.in_id.get()+".tar.gz"):
#                os.popen("tar xzf "+self.in_id.get()+".tar.gz")
#            if os.path.isfile(self.in_id.get()+".tar"):
#                os.popen("tar xf "+self.in_id.get()+".tar")
#            
#            if (not(os.path.exists(SCRATCH_DIR+"/"+self.in_id.get()+'.sources'))):
#                print "No source list file found. Building it."
#                # BUILD SOURCE LIST FILE
#                if (app.CatalogChoice.get()==0):
#                    source_list_build_cmd=python+" "+ROUTINES_DIR+"sourcelist_script.py --id="+self.in_id.get()+" --types="+(",".join(SEX_GALAXY_TYPES))+" --dir="+self.dir.get()
##                if (app.CatalogChoice.get()==1):
##                    source_list_build_cmd=python+" "+ROUTINES_DIR+"sourcelist_script.py --id="+self.in_id.get()+" --i_db=1 --dir="+self.dir.get()
#                    print source_list_build_cmd
#                    os.popen(source_list_build_cmd)
#            else:
#                print "Source list found"
#                if (self.BuildSourceList.get()!=0):
#                    print "Overwriting existing source list!"
#                    if (self.SelectedTypes.get()!=0):
#                        source_list_build_cmd=python+" "+ROUTINES_DIR+"sourcelist_script.py --id="+self.in_id.get()+" --i_db=0 --types="+self.SourceTypesLine.get()+" --dir="+self.dir.get()
#                    else:
#                        source_list_build_cmd=python+" "+ROUTINES_DIR+"sourcelist_script.py --id="+self.in_id.get()+" --i_db=0 --types=1,2,3,4,5 --dir="+self.dir.get()
#                    print source_list_build_cmd
#                    os.popen(source_list_build_cmd)
#
#            
#            os.popen("rm -rf "+self.in_id.get()+"*")

#            cmd=python+" "+ROUTINES_DIR+"mapmaking_script.py --in="+self.in_id.get()+" --out="+self.qid.get()+" --dir="+self.dir.get()+" --types="+self.SourceTypesLine.get()+" --window="+self.windowVar.get()+" --freqinfo="+(",".join([str(self.minObsFreq_Display.Freq.get()/1000.0),str(self.SpectralResolution_Display.Freq.get()/1000000.0),str(self.Nfreq.get())]))+" --bmaj="+str(self.BeamMajorFWHM.get())+" --bmin="+str(self.BeamMinorFWHM.get())+" --bpa="+str(self.BeamPA.get())+" --noise="+str(self.NoiseLevel.get())+" --pixelsize="+str(self.PixelSize.get())+" --imageaccuracy="+str(self.image_accuracy.get())+" --rarefpos="+str(self.RA_RefPos.get())+" --decrefpos="+str(self.DEC_RefPos.get())
            cmd=python+" "+ROUTINES_DIR+((self.DB.get()).replace("S3",""))+"_map_script.py"
            cmd+=" --in="+self.in_id.get()
            cmd+=" --out="+self.qid.get()
            cmd+=" --dir="+self.dir.get()
            if (self.DB.get()=="S3SEX"):cmd+=" --types="+self.SourceTypesLine.get()
            cmd+=" --window="+self.windowVar.get()
            # MIN FREQ AND DELTA FREQ PASSED ON TO THE SCRIPT MUST BE IN GHz
            cmd+=" --freqinfo="+(",".join([str(self.minObsFreq_Display.Freq.get()/(10.0)**(3*self.CRVALnu_UNIT_Var.get())),str(self.SpectralResolution_Display.Freq.get()/(10.0)**(3*self.CDELTnu_UNIT_Var.get())),str(self.Nfreq.get())]))
            if (self.BMAJ_UNIT_Var.get()==0):cmd+=" --bmaj="+str(self.BeamMajorFWHM.get())
            if (self.BMAJ_UNIT_Var.get()==1):cmd+=" --bmaj="+str(arcmin2arcsec(self.BeamMajorFWHM.get()))
            if (self.BMAJ_UNIT_Var.get()==2):cmd+=" --bmaj="+str(deg2arcsec(self.BeamMajorFWHM.get()))
            if (self.BMAJ_UNIT_Var.get()==3):cmd+=" --bmaj="+str(rad2arcsec(self.BeamMajorFWHM.get()))
            if (self.BMIN_UNIT_Var.get()==0):cmd+=" --bmin="+str(self.BeamMinorFWHM.get())
            if (self.BMIN_UNIT_Var.get()==1):cmd+=" --bmin="+str(arcmin2arcsec(self.BeamMinorFWHM.get()))
            if (self.BMIN_UNIT_Var.get()==2):cmd+=" --bmin="+str(deg2arcsec(self.BeamMinorFWHM.get()))
            if (self.BMIN_UNIT_Var.get()==3):cmd+=" --bmin="+str(rad2arcsec(self.BeamMinorFWHM.get()))
            if (self.BPA_UNIT_Var.get()==0):cmd+=" --bpa="+str(arcsec2rad(self.BeamPA.get()))
            if (self.BPA_UNIT_Var.get()==1):cmd+=" --bpa="+str(arcmin2rad(self.BeamPA.get()))
            if (self.BPA_UNIT_Var.get()==2):cmd+=" --bpa="+str(deg2rad(self.BeamPA.get()))
            if (self.BPA_UNIT_Var.get()==3):cmd+=" --bpa="+str(self.BeamPA.get())
            cmd+=" --noise="+str(self.NoiseLevel.get())
            if (self.CDELTX_UNIT_Var.get()==0):cmd+=" --pixelsize="+str(self.PixelSize.get())
            if (self.CDELTX_UNIT_Var.get()==1):cmd+=" --pixelsize="+str(arcmin2arcsec(self.PixelSize.get()))
            if (self.CDELTX_UNIT_Var.get()==2):cmd+=" --pixelsize="+str(deg2arcsec(self.PixelSize.get()))
            if (self.CDELTX_UNIT_Var.get()==3):cmd+=" --pixelsize="+str(rad2arcsec(self.PixelSize.get()))
            if (self.DB.get()=="S3SEX"):cmd+=" --imageaccuracy="+str(self.image_accuracy.get())
            cmd+=" --rarefpos="+str(self.RA_RefPos.get())
            cmd+=" --decrefpos="+str(self.DEC_RefPos.get())
            if (self.UseRefPos.get()==1):cmd+=" --userefpos"

            if (self.Include_Continuum.get()!=0):
                if ((self.TotalIntensityVar.get()!=0) or (self.LinearPolarizationVar.get()!=0)):
                    cmd+=" --continuum="
                    pols=[]
                    if (self.TotalIntensityVar.get()!=0):pols.append("I")
                    if (self.LinearPolarizationVar.get()!=0):pols.extend(["Q","U"])
                    if (len(pols)>0): cmd+=(",".join(pols))            

            if (self.DB.get()=="S3SEX"):
                if (self.Include_HI.get()!=0): cmd+=" --hi"
            if (self.DB.get()=="S3SAX"):
                if (self.Include_HI.get()!=0): cmd+=" --hi="+str(self.HIVar.get())
                if (self.Include_CO.get()!=0): 
                    if (self.co10Var.get()!=0):cmd+=" --co_1_0"
                    if (self.co21Var.get()!=0):cmd+=" --co_2_1"
                    if (self.co32Var.get()!=0):cmd+=" --co_3_2"
                    if (self.co43Var.get()!=0):cmd+=" --co_4_3"
                    if (self.co54Var.get()!=0):cmd+=" --co_5_4"
                    if (self.co65Var.get()!=0):cmd+=" --co_6_5"
                    if (self.co76Var.get()!=0):cmd+=" --co_7_6"
                    if (self.co87Var.get()!=0):cmd+=" --co_8_7"
                    if (self.co98Var.get()!=0):cmd+=" --co_9_8"
                    if (self.co109Var.get()!=0):cmd+=" --co_10_9"
            if (self.IncludeGSM.get()!=0): cmd+=" --gsm"
            if (self.IncludeEOR.get()!=0): 
                if (self.EORVar.get()==0):cmd+=" --eor=IST"
            if (self.ZAXIS_TYPE_Var.get()==0): cmd+=" --veloaxis"
            if (self.ZAXIS_TYPE_Var.get()==1): cmd+=" --freqaxis"
            if (self.ReverseRA.get()==1):cmd+=" --reversera"
            cmd+=" --zrange="+str(self.ZMIN.get())+","+str(self.ZMAX.get())
            if (self.IncludeCMB.get()==0):cmd+=" --nocmb"

            
#            pols=[]
#            if (self.I.get()!=0):pols.append("I")
#            if (self.Q.get()!=0):pols.append("Q")
#            if (self.U.get()!=0):pols.append("U")
#            if (self.V.get()!=0):pols.append("V")
#            if (len(pols)>0): cmd+=(" --polarization="+(",".join(pols)))            
#            if (self.ReverseRA.get()!=0): cmd+=" --reversera"
#            if (self.FreqVeloAxis.get()==1): cmd+=" --veloaxis"
#            if (self.FreqVeloAxis.get()==2): cmd+=" --freqaxis"
        return(cmd)

    def GetPreviewData(self):
        import numpy
        result_file=(SCRATCH_DIR+"/"+self.in_id.get()+".result").replace("/","/")        
        fp=open(result_file,"r")
        galaxy_items=fp.readline().replace("\n","").split(",")
        if (self.DB.get()=="S3SEX"):
            from Config_SEX import RA,DEC,PA,MAJOR_AXIS,MINOR_AXIS
            x=[]
            y=[]
            major_axis=[]
            minor_axis=[]
            pa=[]
            for line in fp:
                sp=line.split(",")
                x.append(deg2arcsec(float(sp[galaxy_items.index(RA)])))
                y.append(deg2arcsec(float(sp[galaxy_items.index(DEC)])))
                major_axis.append(float(sp[galaxy_items.index(MAJOR_AXIS)]))
                minor_axis.append(float(sp[galaxy_items.index(MINOR_AXIS)]))
                pa.append(rad2deg(float(sp[galaxy_items.index(PA)])))
        if (self.DB.get()=="S3SAX"):
            from Config_SAX import RA,DEC,PA,HI_MAJOR_AXIS_10MAX,HI_AXIS_RATIO,H2_MAJOR_AXIS_10MAX,H2_AXIS_RATIO
            x=[]
            y=[]
            major_axis=[]
            minor_axis=[]
            pa=[]
            if(HI_MAJOR_AXIS_10MAX in galaxy_items):
                major_axis_col=galaxy_items.index(HI_MAJOR_AXIS_10MAX)
                axis_ratio_col=galaxy_items.index(HI_AXIS_RATIO)
            elif(H2_MAJOR_AXIS_10MAX in galaxy_items):
                major_axis_col=galaxy_items.index(H2_MAJOR_AXIS_10MAX)
                axis_ratio_col=galaxy_items.index(H2_AXIS_RATIO)
            else:
                print "Missing info in GetPreviewData"
                sys.exit()
            for line in fp:
                sp=line.split(",")
                x.append(deg2arcsec(float(sp[galaxy_items.index(RA)])))
                y.append(deg2arcsec(float(sp[galaxy_items.index(DEC)])))                
                maj=float(sp[major_axis_col])
                major_axis.append(maj)
                minor_axis.append(float(sp[axis_ratio_col])*maj)
                pa.append(rad2deg(float(sp[galaxy_items.index(PA)])))
        fp.close()
        return(x,y,major_axis,minor_axis,pa)

    def PreviewCommand(self):
	self.minX=DoubleVar()
	self.maxX=DoubleVar()
	self.minY=DoubleVar()
	self.maxY=DoubleVar()
        self.minX.set(self.Min_X_Display.seconds())
        self.maxX.set(self.Max_X_Display.seconds())
        self.minY.set(self.Min_Y_Display.seconds())
        self.maxY.set(self.Max_Y_Display.seconds())
        import numpy
        from pylab import figure, show
        from matplotlib.patches import Ellipse

        PreviewData=self.GetPreviewData()
        Npoints=len(PreviewData[0])

        ells=[]
        for i_object in range(Npoints):
            ells.append(Ellipse(xy=(PreviewData[0][i_object],PreviewData[1][i_object]),
                                height=PreviewData[2][i_object],
                                width=PreviewData[3][i_object],
                                angle=PreviewData[4][i_object]))

        fig = figure()
        a = fig.add_subplot(111, aspect='equal')

        for e in ells:
            a.add_artist(e)
            e.set_clip_box(a.bbox)
#            e.set_alpha(numpy.random.rand())
        a.set_xlim(self.Min_X_Display.seconds(),self.Max_X_Display.seconds())
        a.set_ylim(self.Min_Y_Display.seconds(),self.Max_Y_Display.seconds())

        show()
#        canvas = FigureCanvasTkAgg(f, master=root)
#        canvas.show()
#        canvas.get_tk_widget().pack(side=Tk.TOP, fill=Tk.BOTH, expand=1)

#        toolbar = NavigationToolbar2TkAgg( canvas, root )
#        toolbar.update()
#        canvas._tkcanvas.pack(side=Tk.TOP, fill=Tk.BOTH, expand=1)

#        Tk.mainloop()


    def ShowCommand(self):
        cmd=self.BuildCommand()
        print "With current parameters, S3Map would run the following script command :\n"+cmd
        Nxyz=self.GetImageSize()
        Npix=Nxyz[0]*Nxyz[1]*Nxyz[2]
        size_string=str(Nxyz[0])+" x "+str(Nxyz[1])+" x "+str(Nxyz[2])
        print "The output map is "+size_string+" = "+str(Npix)+" pixels"
        memory=float(Npix)*(8.0) # Memory usage in bytes
        if (math.log10(memory)<3): print "   -> Requires "+str(memory)+" B of memory"
        if ((math.log10(memory)>=3)and(math.log10(memory)<6)): print "   -> Requires "+str(memory/1024.)+" kB of memory"
        if ((math.log10(memory)>=6)and(math.log10(memory)<9)): print "   -> Requires "+str(memory/1024./1024.)+" MB of memory"
        if ((math.log10(memory)>=9)and(math.log10(memory)<12)): print "   -> Requires "+str(memory/1024./1024./1024.)+" GB of memory"
        if (math.log10(memory)>=12): print "   -> Requires "+str(memory/1024./1024./1024./1024.)+" TB of memory"
        if (Npix>Npixmax): print "Total number of pixels exceeds maximum allowed ("+str(Npixmax)+"). You may want to change something..."


    def display_info(self):
        w=Toplevel()
        w.Info_Label=Label(w,text="S-Cubed Interactive Tools [1.0]\n Developed for SKADS by F. Levrier \n University of Oxford \n 2007-2010")
        w.Info_Label.grid(row=0,column=0,padx=10,pady=10)
        w.grid()

    def display_help(self):
	output=os.popen(PDFViewer+" "+Help_File+" &")

    def browse_rootdir(self):
	self.rootdirchoice=tkFileDialog.askdirectory(parent=self,initialdir=self.catrootdir.get(),title="Choose a directory")
	self.catrootdir.set(self.rootdirchoice+"/")

    def ChooseBox(self):	
        app.AreaSearchChoice.set(1)
        self.Min_X_Display.configure(state=NORMAL)
        self.Min_Y_Display.configure(state=NORMAL)
        self.Max_X_Display.configure(state=NORMAL)
        self.Max_Y_Display.configure(state=NORMAL)
        self.Center_X_Display.configure(state=DISABLED)
        self.Center_Y_Display.configure(state=DISABLED)
        self.Radius_Display.configure(state=DISABLED)

    def ChooseDisk(self):	
        app.AreaSearchChoice.set(2)
        self.Min_X_Display.configure(state=DISABLED)
        self.Min_Y_Display.configure(state=DISABLED)
        self.Max_X_Display.configure(state=DISABLED)
        self.Max_Y_Display.configure(state=DISABLED)
        self.Center_X_Display.configure(state=NORMAL)
        self.Center_Y_Display.configure(state=NORMAL)
        self.Radius_Display.configure(state=NORMAL)

    def RunCommand(self):
	cmd=self.BuildCommand()
        print "S3Map running the following script command :\n"+cmd
      	output = os.popen(cmd)
        output.close()
        print "Done"
root=Tk()
app=S3Map_application(root)
app.master.title("S3Map")
app.mainloop()


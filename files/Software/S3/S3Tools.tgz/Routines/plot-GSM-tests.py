import os
import pyfits
import matplotlib
import matplotlib.pyplot
import matplotlib.mpl
import numpy
from common_routines import constant,deg2arcsec,rad2deg,I2Tb
from common_map_routines import channel_boundary_frequencies,channel_boundary_velocities
from GSM_routines import *
from matplotlib.patches import Ellipse

TEST_DIR="../Tests/"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

def plot_GSM_spectrum(FILES,figname):
    fig=matplotlib.pyplot.figure()
    ax=fig.add_subplot(111)
    ax.set_xlabel(r'$\nu$'+' [GHz]',fontsize=20)
    ax.set_ylabel(r'$T$ [K]',fontsize=20)
    for file_gsm in FILES:
        data_gsm=(pyfits.open(TEST_DIR+file_gsm)[0]).data    
        hdr=(pyfits.open(TEST_DIR+file_gsm)[0]).header
#        print hdr
        if (hdr['CUNIT1']=='DEGREE'):dx=abs(deg2arcsec(hdr['CDELT1']))
        if (hdr['CUNIT2']=='DEGREE'):dy=abs(deg2arcsec(hdr['CDELT2']))
        pixel_area=dx*dy*2.3504e-11 # IN STERADIAN
        Nfreqs=hdr['NAXIS3']
        freq_axis=(numpy.arange(Nfreqs)-hdr['CRPIX3']+1)*(hdr['CDELT3']/1e9)+(hdr['CRVAL3']/1e9) # in GHz
        spectrum=numpy.zeros((Nfreqs),dtype=numpy.float64)
        for i_f in range(Nfreqs):spectrum[i_f]=I2Tb(data_gsm[i_f,0,0]/(1e26*pixel_area),1e3*freq_axis[i_f]) # NOW IN K
        ax.loglog(freq_axis,spectrum,'bo')
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()


def fig_spatial_extent(file,figname):
#    print file
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
    Nx=hdr['NAXIS1']
    Ny=hdr['NAXIS2']
    Nfreqs=hdr['NAXIS3']
    # BUILD INTEGRATED IMAGE (ARBITRARY UNITS)    
    intflux=numpy.zeros((Ny,Nx),dtype=numpy.float64)
    for i_f in range(Nfreqs):intflux[:,:]+=(data[i_f,:,:])
    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
    x=(float(hdr['CDELT1'])*(numpy.arange(float(Nx))-float(hdr['CRPIX1'])+1)+float(hdr['CRVAL1'])) # in degrees
    y=(float(hdr['CDELT2'])*(numpy.arange(float(Ny))-float(hdr['CRPIX2'])+1)+float(hdr['CRVAL2'])) # in degrees
    extent=[max(x),min(x),min(y),max(y)]
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern')
    # MAKE IMAGE
    ax1.imshow(numpy.log(intflux), interpolation='nearest',origin='lower',cmap=cmap,extent=extent)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])

    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
#    ax1.xaxis.set_major_locator(majorLocator)
    #ax1.yaxis.set_major_locator(majorLocator)
    ax1.set_xlabel(r'$\alpha$ [$^\circ$]',fontsize=20)
    ax1.set_ylabel(r'$\delta$ [$^\circ$]',fontsize=20)

    # SAVE FIGURE
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

FILES=["gsm-6am-10MHz.fits","gsm-6am-20MHz.fits","gsm-6am-50MHz.fits","gsm-6am-300MHz.fits","gsm-6am-1GHz.fits","gsm-6am-2GHz.fits","gsm-6am-20GHz.fits","gsm-6am-30GHz.fits","gsm-6am-40GHz.fits","gsm-6am-50GHz.fits"]
extension=".png"
#extension=".eps"
plot_GSM_spectrum(FILES,TEST_DIR+"gsm_spectrum"+extension)
fig_spatial_extent("gsm-30deg-1GHz.fits",TEST_DIR+"gsm_30deg"+extension)

import math
import numpy
import pyfits
import os
import scipy
import scipy.signal
import scipy.interpolate
import scipy.special
import types
from common_routines import *
import sys
sys.path.append("../Config/")
from Config_Map import *
from Config_Path import *
from common_map_routines import *
import time
#from ipol import *
#import Image
import scipy.ndimage


##############################################
#### COSMIC MICROWAVE BACKGROUND ROUTINES ####
##############################################

def CMB(freqs): # Returns CMB emission in Jy/sr, for freqs in MHz
    T_CMB=2.725 # in K
    result=[]
    for f in freqs:
        f_Hz=1e6*f
        bnu=(2.0*constant("h")*math.pow(f_Hz,3.0))/(math.pow(constant("c"),2.0)*1e6*(math.exp((constant("h")*f_Hz)/(constant("k")*T_CMB))-1.0))
        result.append(bnu*1e26)
    return(result)

def make_cmb_map(fits_file):
    hdulist=pyfits.open(fits_file)
    hdu=hdulist[0]
    Nx=hdu.header['NAXIS1']
    Ny=hdu.header['NAXIS2']
    Nfreqs=hdu.header['NAXIS3']
    result=numpy.zeros((Nfreqs,Ny,Nx),dtype='f')
    if (hdu.header['CTYPE3']=="FREQ"):
        freqs=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        if (hdu.header['CUNIT3']=="HZ"): freqs/=1e6 # That's what it should be from mapmaking_script.py
        if (hdu.header['CUNIT3']=="KHZ"): freqs/=1e3
        if (hdu.header['CUNIT3']=="GHZ"): freqs*=1e3
        dfreq=hdu.header['CDELT3']
        if (hdu.header['CUNIT3']=="HZ"): dfreq/=1e6 # That's what it should be from mapmaking_script.py
        if (hdu.header['CUNIT3']=="KHZ"): dfreq/=1e3
        if (hdu.header['CUNIT3']=="GHZ"): dfreq*=1e3
    elif (hdu.header['CTYPE3']=="VELO"):
        nu0=constant("nu0_HI") # in MHz # WATCH OUT THIS IS ONLY VALID IF IT'S HI ONLY !!!!
        velos=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        freqs=[]
        for v in velos:
            freqs.append(velo2freq(v,nu0))
    else:
        print "unknown"
    if (hdu.header['CUNIT1']=='DEGREE'):dx=abs(deg2arcsec(hdu.header['CDELT1']))
    if (hdu.header['CUNIT2']=='DEGREE'):dy=abs(deg2arcsec(hdu.header['CDELT2']))
    pixel_area=dx*dy*2.3504e-11 # IN STERADIAN
    CMB_signal=CMB(freqs)
    for i in range(Nfreqs):result[i][:][:]=CMB_signal[i]*pixel_area
    return(result)


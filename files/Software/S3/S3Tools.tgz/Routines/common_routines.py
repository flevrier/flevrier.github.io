import math
import numpy

# Split a list in N parts of lengths as equal as possible. Default is only one part.
def split_list(alist, wanted_parts=1):
    length = len(alist)
    return [ alist[i*length // wanted_parts: (i+1)*length // wanted_parts] 
             for i in range(wanted_parts) ]

def split_seq(seq, size):
    newseq = []
    splitsize = (1.0/size)*len(seq)
    for i in range(size):
        newseq.append(seq[int(round(i*splitsize)):int(round((i+1)*splitsize))])
    return(newseq)
 
def num2str(i,length):
    si=str(i)
    lsi=len(si)
    if (lsi<length):
        for k in range(length-lsi): si='0'+si
    return(si)

def constant(symbol):
    if (symbol=="c"): return(299792.458) # Speed of light, in km/s
    elif (symbol=="h"): return(6.6260693e-34) # Planck constant
    elif (symbol=="k"): return(1.3806505e-23) # Boltzmann constant
    elif (symbol=="e"): return(1.60217653e-19) # Elementary electrical charge
    elif (symbol=="me"): return(9.1093826e-31) # Electron mass
    elif (symbol=="mp"): return(1.67262171e-27) # Proton mass
    elif (symbol=="G"): return(6.6742e-11) # Gravitational constant
    elif (symbol=="Na"): return(6.0221415e23) # Avogadro's number
    elif (symbol=="mu0"): return(12.566370614e-7) # Magnetic permeability
    elif (symbol=="epsilon0"): return(8.854187817e-12) # Electric permittivity
    elif (symbol=="amu"): return(1.66053886e-27)  # Atomic mass unit
    elif (symbol=="nu0_HI"): return(1420.405751) # Rest frequency of the HI line, in MHz
    elif (symbol=="nu0_CO"): return(115271.203) # Rest frequency of the CO(1->0) line, in MHz
    elif (symbol=="H0"): return(72) # Hubble constant, in km/s/Mpc
    else:
        print "Unknown symbol"
        return(0)

def signe(value):
    if (value < 0): return("-")
    else: return("+")

def fwhm2sigma(fwhm):
    return((0.5)*fwhm/math.sqrt(2*math.log(2)))

def sigma2fwhm(sigma):
    return((2.0)*sigma*math.sqrt(2*math.log(2)))

def deg2rad(angle_deg):
    return(math.pi*angle_deg/180.0)

def rad2deg(angle_rad):
    return(180.0*angle_rad/math.pi)

def arcsec2deg(angle_arcsec):
    return(angle_arcsec/3600.0)

def deg2arcsec(angle_deg):
    return(angle_deg*3600.0)

def arcmin2deg(angle_arcmin):
    return(angle_arcmin/60.0)

def deg2arcmin(angle_deg):
    return(angle_deg*60.0)

def arcmin2rad(angle_arcmin):
    return(deg2rad(arcmin2deg(angle_arcmin)))

def rad2arcsec(angle_rad):
    return(deg2arcsec(rad2deg(angle_rad)))

def arcsec2rad(angle_arcsec):
    return(deg2rad(arcsec2deg(angle_arcsec)))

def arcsec2dms(angle_arcsec):
    tmp=math.fabs(angle_arcsec)
    angle_d=math.floor(tmp/(3600.))
    angle_m=math.floor((tmp-(angle_d*3600.))/60.0)
    angle_s=tmp-(angle_d*3600.0)-(angle_m*60.0)
    return(signe(angle_arcsec),int(angle_d),int(angle_m),angle_s)

def deg2dms(angle_deg):
    return(arcsec2dms(deg2arcsec(angle_deg)))

def rad2dms(angle_rad):
    return(arcsec2dms(rad2arcsec(angle_rad)))

def dms2arcsec(dms):
    if (dms[0]=="-"):
        factor=-1.
        result=factor*(dms[3]+(float(dms[2])*60.0)+(float(dms[1])*3600.0))
    elif (dms[0]=="+"): 
        factor=1.
        result=factor*(dms[3]+(float(dms[2])*60.0)+(float(dms[1])*3600.0))
    else: 
        print "Unknown sign"
        result=0
    return(result)

def dms2deg(dms):
    return(arcsec2deg(dms2arcsec(dms)))

def dms2rad(dms):
    return(arcsec2rad(dms2arcsec(dms)))

def arcsec2hms(angle_arcsec):
    tmp=math.fabs(angle_arcsec)/15.0
    angle_h=math.floor(tmp/(3600.))
    angle_m=math.floor((tmp-(angle_h*3600.))/60.0)
    angle_s=tmp-(angle_h*3600.0)-(angle_m*60.0)
    if angle_arcsec<0:
        angle_h=23.0-angle_h
        angle_m=59.0-angle_m
        angle_s=60.0-angle_s
    return("+",int(angle_h),int(angle_m),angle_s)

def deg2hms(angle_deg):
    return(arcsec2hms(deg2arcsec(angle_deg)))

def rad2hms(angle_rad):
    return(arcsec2hms(rad2arcsec(angle_rad)))

def hms2arcsec(hms):
    factor=15.
    if (hms[1] > 11):
        result=factor*(hms[3]+(float(hms[2])*60.0)+(float(hms[1])*3600.0))-deg2arcsec(360.)
    else:
        result=factor*(hms[3]+(float(hms[2])*60.0)+(float(hms[1])*3600.0))
    return(result)

def hms2deg(hms):
    return(arcsec2deg(hms2arcsec(hms)))

def hms2rad(hms):
    return(arcsec2rad(hms2arcsec(hms)))

def arcmin2arcsec(angle_arcmin):
    return(60.0*angle_arcmin)

def arcmin2rad(angle_arcmin):
    return(arcsec2rad(arcmin2arcsec(angle_arcmin)))

def dms_line(dms,separator):
    return(dms[0]+str(dms[1])+separator+str(dms[2])+separator+str(dms[3]))

# COMPUTE THE ANGULAR DISTANCE BETWEEN TWO POINTS GIVEN BY THEIR R.A. AND DECLINATIONS, IN RADIANS. RETRUNED VALUE IS ALSO IN RADIANS
def angular_distance(ra1,dec1,ra2,dec2):
    return(math.acos(math.sin(dec1)*math.sin(dec2)+math.cos(dec1)*math.cos(dec2)*math.cos(ra2-ra1)))

def relativistic_composition(v0,v): # v0 and v should be in km/s
    return((v0+v)/(1.+v0*v/math.pow(constant("c"),2.0)))

def velo2freq(velo,nu0):
    return(nu0*math.sqrt((1.-velo/constant("c"))/(1.+velo/constant("c"))))

def freq2velo(nu,nu0):
    return(constant("c")*(1.-(math.pow(nu/nu0,2.0)))/(1.+(math.pow(nu/nu0,2.0))))

def redshift2freq(redshift,nu0):
    return(nu0/(1.+redshift))

def freq2redshift(nu,nu0):
    return((nu0/nu)-1.)

def redshift2velo(redshift):
    a=math.pow((1.+redshift),2.0)
    return(constant("c")*((a-1.0)/(a+1.0)))

def velo2redshift(velo):
    beta=velo/constant("c")
    return(math.sqrt((1.+beta)/(1.-beta))-1.0)

def redshift2distance(redshift):
    return((redshift/(1.+redshift))*(constant("c")/constant("H0")))

def Tb2I(Tb,nu):
    #nu in MHz, Tb in K, returns I in W/m2/Hz/sr
    return(2.0*math.pow(nu,2.0)*1e6*constant("k")*Tb/math.pow(constant("c"),2.0))

def I2Tb(I,nu):
    #nu in MHz, I in W/m2/Hz/sr, returns Tb in K
    return((math.pow(constant("c"),2.0)*I)/(2.0*math.pow(nu,2.0)*1e6*constant("k")))

def round(f):
    if (math.fabs(f-math.floor(f)) < 0.5): return(int(math.floor(f)))
    else: return(int(math.ceil(f)))

def subset2d(map,limits):
    subNx=limits[1]-limits[0]+1
    subNy=limits[3]-limits[2]+1
    result=numpy.empty((subNx,subNy),map.dtype)
    result[:,:]=map[limits[0]:limits[1]+1,limits[2]:limits[3]+1]
    return(result)

def in_pixel(value,zeropix_value,delta):
    return(int(math.floor((float(value)-float(zeropix_value)+(float(delta)/2.0))/float(delta))))

def grid(N):
    return(numpy.linspace(0.0,float(N-1),N))

def XY(Nx,Ny):
    X=grid(Nx)
    Y=grid(Ny)
    X.resize(Nx,1)
    XX=numpy.tile(X,(1,Ny))
    YY=numpy.tile(Y,(Nx,1))
    return(XX,YY)

def mmultiply(*args):
    ret=args[0]
    for a in args[1:]:
        ret=numpy.multiply(ret,a)
    return(ret)

def total(array):
    ret=sum(array)
    for i in range(1,array.ndim):
        ret=sum(ret)
    return(ret)

def unique(inlist, keepstr=True):
  typ = type(inlist)
  if not typ == list:
    inlist = list(inlist)
  i = 0
  while i < len(inlist):
    try:
      del inlist[inlist.index(inlist[i], i + 1)]
    except:
      i += 1
  if not typ in (str, unicode):
    inlist = typ(inlist)
  else:
    if keepstr:
      inlist = ''.join(inlist)
  return inlist

def array_to_string_array(array):
    result=[]
    for e in array:
        result.append(str(e))
    return(result)

def display_file(file):
    fp=open(file)
    lines=fp.readlines()
    for line in lines:
        print line.replace("\n","")

from Tkinter import *

class DateDisplay(Frame):
	def __init__(self,master):
        	Frame.__init__(self,master,class_="DateDisplay")
        	self.createWidgets()

    	def createWidgets(self):
		self.Year=IntVar()
		self.Month=IntVar()
		self.Day=IntVar()
        	self.Year_Entry=Entry(self,relief=GROOVE,textvariable=self.Year,bg="white",selectbackground="yellow",width=4,justify=RIGHT)
        	self.Month_Entry=Entry(self,relief=GROOVE,textvariable=self.Month,bg="white",selectbackground="yellow",width=2,justify=RIGHT)
        	self.Day_Entry=Entry(self,relief=GROOVE,textvariable=self.Day,bg="white",selectbackground="yellow",width=2,justify=RIGHT)
        	self.Day_Entry.grid(column=0,row=0)
        	self.Month_Entry.grid(column=1,row=0)
        	self.Year_Entry.grid(column=2,row=0)

class AngleDisplay(Frame):
    def __init__(self,master):
        Frame.__init__(self,master,class_="AngleDisplay")
        self.createWidgets()

    def createWidgets(self):

        self.Angle_deg=IntVar()
        self.Angle_min=IntVar()
        self.Angle_sec=DoubleVar()
	self.Angle_signe=StringVar()

	self.Angle_signe_Entry=Entry(self,relief=GROOVE,textvariable=self.Angle_signe,bg="white",selectbackground="yellow",width=1,justify=RIGHT)
	self.Tick1=Label(self,text=":")
	self.Tick2=Label(self,text=":")
        self.Angle_deg_Entry=Entry(self,relief=GROOVE,textvariable=self.Angle_deg,bg="white",selectbackground="yellow",width=3,justify=RIGHT)
        self.Angle_min_Entry=Entry(self,relief=GROOVE,textvariable=self.Angle_min,bg="white",selectbackground="yellow",width=2,justify=RIGHT)
        self.Angle_sec_Entry=Entry(self,relief=GROOVE,textvariable=self.Angle_sec,bg="white",selectbackground="yellow",width=10,justify=RIGHT)
	self.Angle_signe_Entry.grid(column=0,row=0,padx=1)
        self.Angle_deg_Entry.grid(column=1,row=0)
	self.Tick1.grid(column=2,row=0)
        self.Angle_min_Entry.grid(column=3,row=0)
	self.Tick2.grid(column=4,row=0)
        self.Angle_sec_Entry.grid(column=5,row=0)

    def dms_line(self):
	return self.Angle_signe.get()+str(self.Angle_deg.get())+"d"+str(self.Angle_min.get())+"m"+str(self.Angle_sec.get())+"s"

    def hms_line(self):
	return self.Angle_signe.get()+str(self.Angle_deg.get())+"h"+str(self.Angle_min.get())+"m"+str(self.Angle_sec.get())+"s"

    def seconds(self):
	val=((self.Angle_deg.get()*(3600.))+(self.Angle_min.get()*(60.))+self.Angle_sec.get())
	if (self.Angle_signe.get()=="-"):
		return -val
 	else:
		return val
       
    def configure(self,**kwargs):
	self.Angle_signe_Entry.configure(**kwargs)
	self.Angle_deg_Entry.configure(**kwargs)
	self.Angle_min_Entry.configure(**kwargs)
	self.Angle_sec_Entry.configure(**kwargs)

class TimeDisplay(Frame):
    def __init__(self,master):
        Frame.__init__(self,master,class_="TimeDisplay")
        self.createWidgets()

    def createWidgets(self):
        self.Time_hrs=IntVar()
        self.Time_min=IntVar()
        self.Time_sec=DoubleVar()

        self.Time_hrs_Entry=Entry(self,relief=GROOVE,textvariable=self.Time_hrs,bg="white",selectbackground="yellow",width=4,justify=RIGHT)
        self.Time_min_Entry=Entry(self,relief=GROOVE,textvariable=self.Time_min,bg="white",selectbackground="yellow",width=3,justify=RIGHT)
        self.Time_sec_Entry=Entry(self,relief=GROOVE,textvariable=self.Time_sec,bg="white",selectbackground="yellow",width=8,justify=RIGHT)

        self.Time_hrs_Entry.grid(column=0,row=0)
        self.Time_min_Entry.grid(column=1,row=0)
        self.Time_sec_Entry.grid(column=2,row=0)

    def hms_line(self):
	return str(self.Time_hrs.get())+"h"+str(self.Time_min.get())+"m"+str(self.Time_sec.get())+"s"

class FreqDisplay(Frame):
    def __init__(self,master):
        Frame.__init__(self,master,class_="FreqDisplay")
        self.createWidgets()

    def createWidgets(self):
        self.Freq=DoubleVar()
        self.Freq_Entry=Entry(self,relief=GROOVE,textvariable=self.Freq,bg="white",selectbackground="yellow",width=14,justify=RIGHT)
        self.Freq_Entry.grid(column=0,row=0,sticky=W)
       
    def configure(self,**kwargs):
	self.Freq_Entry.configure(**kwargs)

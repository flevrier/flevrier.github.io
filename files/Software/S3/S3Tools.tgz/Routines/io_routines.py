def read_info(query_file,tag):
    fp=open(query_file,"r")
    for line in fp:        
        sp=line.replace("\n","").split("=")
        if (sp[0]==tag):break
    return(sp[1])

def write_query_info(tag_value_array,query_info_file):
    fp=open(query_info_file,'w')
    for tv in tag_value_array:
        fp.writelines([tv[0]+"="+tv[1]+"\n"])
    fp.close()

def read_query_result(file):
    file=open(file,"r")
    fl=file.readlines()
    query_result=[]
    for i in range(len(fl)):
        str_line=fl[i].split()
        line=[]
        for k in range(len(str_line)):
            if (str_line[k]!="None"):line.append(float(str_line[k]))
            else:line.append(str_line[k])
        query_result.append(line)
    return(query_result)

def read_query_info(file): # Needs adapting to new structure
    file=open(file,"r")
    fl=file.readlines()
    for line in fl:
        sp=line.replace("\n","").split("=")
        if (sp[0]=="DB"): i_db=int(sp[1])
        if (sp[0]=="ITEMS"): 
            column_list_no_trim=sp[1].split(", ")
            column_list=[]
            for c in column_list_no_trim:
                column_list.append(c.strip())
        if (sp[0]=="WINDOW"): 
            str_window=sp[1].split(", ")
            window=[]
            for w in str_window:
                window.append(float(w))
        if (sp[0]=="REDSHIFT"): 
            str_zwindow=sp[1].split(", ")
            zwindow=[]
            for z in str_zwindow:
                zwindow.append(float(z))
        if (sp[0]=="TYPES"): 
            str_types=sp[1].split(", ")
            types=[]
            for t in str_types:
                types.append(int(t))
    result=[i_db,column_list,window,zwindow,types]
    return(result)

def write_query_result(query_result,file):
    file_pointer=open(file,'w')
    lines=[]
    for i in range(len(query_result)):
        string_vals=[]
        for j in range(len(query_result[i])):string_vals.append(str(query_result[i][j]))
        lines.append((" ".join(string_vals))+"\n")
    file_pointer.writelines(lines)
    file_pointer.close()

def which_database(result_file):
    fp=open(result_file,"r")
    ITEMS=(fp.readline()).replace("\n","").split(',')
    import sys
    sys.path.append("../Config/")
    from Config_SAX import RA
    if RA in ITEMS: DB="S3SAX"
    from Config_SEX import RA
    if RA in ITEMS: DB="S3SEX"
    fp.close()
    return(DB)

def SAX_create_query_file(directory,tag):
    nu_min_array=[]
    nu_max_array=[]
    for i_line in range(12):
        nu_min_array.append([])
        nu_max_array.append([])
    import sys
    sys.path.append("../Config/")
    from Config_SAX import RA,DEC,Z,HI_LINEWIDTH20,CO_LINEWIDTH20
    from Config_Map import line_width_factor
    from common_routines import redshift2velo,velo2freq,constant
    import os
    SAX_file=directory+"/"+tag+".result"
    outfile=directory+"/"+tag+".query"
    fp=open(SAX_file,"r")
    GALAXY_ITEMS=(fp.readline()).replace("\n","")
    CLUSTER_ITEMS=""
    columns=[]
    indices=[]
    minvals=[]
    maxvals=[]
    for v in [RA,DEC,Z]:
        if v in GALAXY_ITEMS.split(","):
            columns.append(v)
            indices.append((GALAXY_ITEMS.split(",")).index(v))
            minvals.append(100.0)
            maxvals.append(-100.0)
    igal=0
    for line in fp:
        igal+=1
        sp=line.split(",")
        for i in range(len(columns)):
            if (float(sp[indices[i]]) < minvals[i]):minvals[i]=float(sp[indices[i]])
            if (float(sp[indices[i]]) > maxvals[i]):maxvals[i]=float(sp[indices[i]])
        z=float(sp[(GALAXY_ITEMS.split(",")).index(Z)]) # Object redshift
        dv_hi=float(sp[(GALAXY_ITEMS.split(",")).index(HI_LINEWIDTH20)]) # HI Line width at 20% of the peak
        dv_co=float(sp[(GALAXY_ITEMS.split(",")).index(CO_LINEWIDTH20)]) # Molecular Line width at 20% of the peak
        v0=redshift2velo(z) # Central velocity in km/s
        nu_min_array[0].append(velo2freq(v0+line_width_factor*dv_hi,constant("nu0_HI"))/1e3) # Minimum HI frequency to consider for this object, in GHz
        nu_max_array[0].append(velo2freq(v0-line_width_factor*dv_hi,constant("nu0_HI"))/1e3) # Maximum HI frequency to consider for this object, in GHz
        for i_co_line in range(1,11):
            nu_min_array[i_co_line].append(velo2freq(v0+line_width_factor*dv_co,float(i_co_line)*constant("nu0_CO"))/1e3) # Minimum CO(J -> J-1) frequency to consider for this object, in GHz
            nu_max_array[i_co_line].append(velo2freq(v0-line_width_factor*dv_co,float(i_co_line)*constant("nu0_CO"))/1e3) # Maximum CO(J -> J-1) frequency to consider for this object, in GHz
    WINDOW=",".join([str(minvals[columns.index(RA)]),str(maxvals[columns.index(RA)]),str(minvals[columns.index(DEC)]),str(maxvals[columns.index(DEC)])])
    REDSHIFT=",".join([str(minvals[columns.index(Z)]),str(maxvals[columns.index(Z)])])
    DB="S3SAX"
    HI_RANGE=",".join([str(min(nu_min_array[0])),str(max(nu_max_array[0]))])
    CO_1_0_RANGE=",".join([str(min(nu_min_array[1])),str(max(nu_max_array[1]))])
    CO_2_1_RANGE=",".join([str(min(nu_min_array[2])),str(max(nu_max_array[2]))])
    CO_3_2_RANGE=",".join([str(min(nu_min_array[3])),str(max(nu_max_array[3]))])
    CO_4_3_RANGE=",".join([str(min(nu_min_array[4])),str(max(nu_max_array[4]))])
    CO_5_4_RANGE=",".join([str(min(nu_min_array[5])),str(max(nu_max_array[5]))])
    CO_6_5_RANGE=",".join([str(min(nu_min_array[6])),str(max(nu_max_array[6]))])
    CO_7_6_RANGE=",".join([str(min(nu_min_array[7])),str(max(nu_max_array[7]))])
    CO_8_7_RANGE=",".join([str(min(nu_min_array[8])),str(max(nu_max_array[8]))])
    CO_9_8_RANGE=",".join([str(min(nu_min_array[9])),str(max(nu_max_array[9]))])
    CO_10_9_RANGE=",".join([str(min(nu_min_array[10])),str(max(nu_max_array[10]))])
    os.popen("rm -f "+outfile)
    ofp=open(outfile,"w")
    ofp.writelines(["DB="+DB+"\n",
                    "N_OBJECTS="+str(igal)+"\n",
                    "CLUSTER_ITEMS="+CLUSTER_ITEMS+"\n",
                    "GALAXY_ITEMS="+GALAXY_ITEMS+"\n",
                    "WINDOW="+WINDOW+"\n",
                    "REDSHIFT="+REDSHIFT+"\n",
                    "HI_RANGE="+HI_RANGE+"\n",
                    "CO_1_0_RANGE="+CO_1_0_RANGE+"\n",
                    "CO_2_1_RANGE="+CO_2_1_RANGE+"\n",
                    "CO_3_2_RANGE="+CO_3_2_RANGE+"\n",
                    "CO_4_3_RANGE="+CO_4_3_RANGE+"\n",
                    "CO_5_4_RANGE="+CO_5_4_RANGE+"\n",
                    "CO_6_5_RANGE="+CO_6_5_RANGE+"\n",
                    "CO_7_6_RANGE="+CO_7_6_RANGE+"\n",
                    "CO_8_7_RANGE="+CO_8_7_RANGE+"\n",
                    "CO_9_8_RANGE="+CO_9_8_RANGE+"\n",
                    "CO_10_9_RANGE="+CO_10_9_RANGE+"\n"
                    ])
    ofp.close()
    fp.close()

def source_type_from_SF_AGN(sftype,agntype):
    import sys
    sys.path.append("../Config/")
    from Config_SEX import SEX_GALAXY_TYPES
    if ((sftype==0) and (agntype==1)): return(SEX_GALAXY_TYPES[0])
    if ((sftype==0) and (agntype==2)): return(SEX_GALAXY_TYPES[1])
    if ((sftype==0) and (agntype==3)): return(SEX_GALAXY_TYPES[2])
    if ((sftype==0) and (agntype==4)): return("GPS") # GPS
    if ((sftype==1) and (agntype==0)): return(SEX_GALAXY_TYPES[3])
    if ((sftype==2) and (agntype==0)): return(SEX_GALAXY_TYPES[4])

def SEX_create_query_file(directory,tag):
    import sys
    sys.path.append("../Config/")
    from Config_SEX import RA,DEC,MOD_Z,SF_TYPE,AGN_TYPE,GALAXY
    import os
    SEX_file=directory+"/"+tag+".result"
    outfile=directory+"/"+tag+".query"
    fp=open(SEX_file,"r")
    GALAXY_ITEMS=(fp.readline()).replace("\n","")
    CLUSTER_ITEMS=""
    GPS="NO"
    types=[]
    columns=[]
    indices=[]
    minvals=[]
    maxvals=[]
    galaxies=[]
    sftype_col=(GALAXY_ITEMS.split(",")).index(SF_TYPE)
    agntype_col=(GALAXY_ITEMS.split(",")).index(AGN_TYPE)
    galaxy_col=(GALAXY_ITEMS.split(",")).index(GALAXY)
    for v in [RA,DEC,MOD_Z]:
        if v in GALAXY_ITEMS.split(","):
            columns.append(v)
            indices.append((GALAXY_ITEMS.split(",")).index(v))
            minvals.append(100.0)
            maxvals.append(-100.0)
    for line in fp:
        sp=line.split(",")        
        for i in range(len(columns)):
            if (float(sp[indices[i]]) < minvals[i]):minvals[i]=float(sp[indices[i]])
            if (float(sp[indices[i]]) > maxvals[i]):maxvals[i]=float(sp[indices[i]])
        type=source_type_from_SF_AGN(int(sp[sftype_col]),int(sp[agntype_col]))
        galaxy=int(sp[galaxy_col])
        if not(galaxy in galaxies):galaxies.append(galaxy)
        if ((type not in types)and(type!="GPS")):types.append(type)
        if (type=="GPS"):GPS="YES"
    WINDOW=",".join([str(minvals[columns.index(RA)]),str(maxvals[columns.index(RA)]),str(minvals[columns.index(DEC)]),str(maxvals[columns.index(DEC)])])
    REDSHIFT=",".join([str(minvals[columns.index(MOD_Z)]),str(maxvals[columns.index(MOD_Z)])])    
    TYPES=",".join(types)
    DB="S3SEX"
    os.popen("rm -f "+outfile)
    ofp=open(outfile,"w")
    ofp.writelines(["DB="+DB+"\n",
                    "N_OBJECTS="+str(len(galaxies))+"\n",
                    "CLUSTER_ITEMS="+CLUSTER_ITEMS+"\n",
                    "GALAXY_ITEMS="+GALAXY_ITEMS+"\n",
                    "WINDOW="+WINDOW+"\n",
                    "REDSHIFT="+REDSHIFT+"\n",
                    "TYPES="+TYPES+"\n",
                    "GPS="+GPS+"\n"])
    ofp.close()

#def old_SAX_create_query_file(directory,tag):
#    import sys
#    sys.path.append("../Config/")
#    from Config_SAX import RA,DEC,Z
#    import os
#    SAX_file=directory+"/"+tag+".result"
#    outfile=directory+"/"+tag+".query"
#    fp=open(SAX_file,"r")
#    GALAXY_ITEMS=(fp.readline()).replace("\n","")
#    CLUSTER_ITEMS=""
#    columns=[]
#    indices=[]
#    minvals=[]
#    maxvals=[]
#    for v in [RA,DEC,Z]:
#        if v in GALAXY_ITEMS.split(","):
#            columns.append(v)
#            indices.append((GALAXY_ITEMS.split(",")).index(v))
#            minvals.append(100.0)
#            maxvals.append(-100.0)
#    for line in fp:
#        sp=line.split(",")
#        for i in range(len(columns)):
#            if (float(sp[indices[i]]) < minvals[i]):minvals[i]=float(sp[indices[i]])
#            if (float(sp[indices[i]]) > maxvals[i]):maxvals[i]=float(sp[indices[i]])
#    WINDOW=",".join([str(minvals[columns.index(RA)]),str(maxvals[columns.index(RA)]),str(minvals[columns.index(DEC)]),str(maxvals[columns.index(DEC)])])
#    REDSHIFT=",".join([str(minvals[columns.index(Z)]),str(maxvals[columns.index(Z)])])
#    DB="S3SAX"
#    os.popen("rm -f "+outfile)
#    ofp=open(outfile,"w")
#    ofp.writelines(["DB="+DB+"\n","CLUSTER_ITEMS="+CLUSTER_ITEMS+"\n","GALAXY_ITEMS="+GALAXY_ITEMS+"\n","WINDOW="+WINDOW+"\n","REDSHIFT="+REDSHIFT+"\n"])
#    ofp.close()
#    fp.close()

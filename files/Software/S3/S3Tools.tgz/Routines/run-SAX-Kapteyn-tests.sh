#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sax_tarfile="single-sax"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_ratio=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

window_20as="198.6236,218.6236,129.0536,149.0536" # 20" on each side, centered on the source position
window_5as="206.1236,211.1236,136.5536,141.5536" # 5" on each side, centered on the source position
window_1as="208.1236,209.1236,138.5536,139.5536" # 1" on each side, centered on the source position
window_400mas="208.4236,208.8236,138.8536,139.2536" # 0.4" on each side, centered on the source position

window_400mas_tl="208.6236,208.8236,139.0536,139.2536" # 'Top Left' subset of the 0.4" on each side window centered on the source position
window_400mas_tr="208.4236,208.6236,139.0536,139.2536" # 'Top Right' subset of the 0.4" on each side window centered on the source position
window_400mas_bl="208.6236,208.8236,138.8536,139.0536" # 'Bottom Left' subset of the 0.4" on each side window centered on the source position
window_400mas_br="208.4236,208.6236,138.8536,139.0536" # 'Bottom Right' subset of the 0.4" on each side window centered on the source position

window_300mas="208.4736,208.7736,138.9036,139.2036" # 0.3" on each side, centered on the source position
window_200mas="208.5236,208.7236,138.9536,139.1536" # 0.2" on each side, centered on the source position
window_200mas_positive_shift_10mas="208.5336,208.7336,138.9636,139.1636" # 0.2" on each side, with a positive 0.01" shift in X an Y with respect to source position
window_200mas_negative_shift_10mas="208.5136,208.7136,138.9436,139.1436" # 0.2" on each side, with a negative 0.01" shift in X an Y with respect to source position

freqrange_hi_1kHz="0.1330461931086369,0.000001,400" # 400 channels (1kHz) centered on HI central frequency
freqrange_hi_5kHz="0.1330461931086369,0.000005,80" # 80 channels (1kHz) centered on HI central frequency
freqrange_hi_20kHz="0.1330461931086369,0.00002,20" # 20 channels (1kHz) centered on HI central frequency
freqrange_hi_50kHz="0.1330461931086369,0.0001,8" # 8 channels (1kHz) centered on HI central frequency

freqrange_hi_1kHz_lowband="0.1330461931086369,0.000001,160" # 160 channels (1 kHz) on the lower band of the HI signal
freqrange_hi_1kHz_centerband="0.1332061931086369,0.000001,80" # 80 channels (1 kHz) on the lower band of the HI signal
freqrange_hi_1kHz_highband="0.1332861931086369,0.000001,160" # 160 channels (1 kHz) on the lower band of the HI signal

echo '#################################################################################################'
echo '# HI EMISSION FROM SPATIALLY UNRESOLVED SOURCE, VARYING SPECTRAL RESOLUTIONS, KAPTEYN TEMPLATES #'
echo '#################################################################################################'

outfile="sax-unresolved-hi-50kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_50kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-20kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_20kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-5kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#############################################################################################################################'
echo '# HI EMISSION FROM SPATIALLY UNRESOLVED SOURCE, VARYING SPECTRAL RESOLUTIONS, KAPTEYN TEMPLATES, WITH GAUSSIAN BEAM APPLIED #'
echo '#############################################################################################################################'

outfile="sax-unresolved-hi-50kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_50kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-20kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_20kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-5kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_5kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz --bmaj=1.0 --bmin=1.0 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '##########################################################################################################'
echo '# HI EMISSION FROM SOURCE WITH VARYING SPATIAL RESOLUTION, 5 kHz SPECTRAL RESOLUTIONS, KAPTEYN TEMPLATES #'
echo '##########################################################################################################'
outfile="sax-5mas-hi-5kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.005 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-15mas-hi-5kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.015 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '######################################################################################################################################'
echo '# HI EMISSION FROM SOURCE WITH VARYING SPATIAL RESOLUTION, 5 kHz SPECTRAL RESOLUTIONS, KAPTEYN TEMPLATES, WITH GAUSSIAN BEAM APPLIED #'
echo '######################################################################################################################################'
outfile="sax-5mas-hi-5kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.005 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-15mas-hi-5kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.03 --bmin=0.03 --bpa=0.0 --noise=0.0 --pixelsize=0.015 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Kapteyn-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas --freqinfo=$freqrange_hi_5kHz --bmaj=0.002 --bmin=0.002 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#####################################################################'
echo '# TEST CHANNEL SPLITTING ON UNRESOLVED HI 5 kHz SPECTRAL RESOLUTION #'
echo '#####################################################################'
outfile="sax-unresolved-hi-1kHz-low-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_lowband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-center-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_centerband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-unresolved-hi-1kHz-high-Kapteyn"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_20as --freqinfo=$freqrange_hi_1kHz_highband --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.5 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '#################################'
echo '# TEST SPATIAL WINDOW SPLITTING #'
echo '#################################'

outfile="sax-1mas-hi-5kHz-Kapteyn-tl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_tl --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Kapteyn-tr"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_tr --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Kapteyn-bl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_bl --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="sax-1mas-hi-5kHz-Kapteyn-br"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_400mas_br --freqinfo=$freqrange_hi_5kHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=0.001 --rarefpos=180.0 --decrefpos=0.0 --hi=Kapteyn --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

echo '####################################################################'
echo '# TESTING FOR DIFFERENCES WITH REFERENCE FILES USING DIFF COMMANDS #'
echo '####################################################################'
cd ../Tests/
for outfile in *Kapteyn*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done

# Build spectra plots and print out integrated fluxes 
echo '####################################################################'
echo '# BUILDING IMAGES OF SOURCES AND PLOTS OF SPECTRA FOR OUTPUT FILES #'
echo '####################################################################'
cd ../Routines/
python plot-SAX-Kapteyn-tests.py

#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sax_tarfile="single-sax"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_ratio=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

window="198.6236,218.6236,129.0536,149.0536" # 20" on each side, centered on the source position
out_window="0.6236,20.6236,0.0536,20.0536" # 20" on each side, with no source in it
freqrange="0.11,0.1,10000" # 10000 channels (100 MHz wide) starting at 110 MHz : total coverage is 10 MHz -> 1 THz

echo '##########################################################################################'
echo '# HI AND CO EMISSIONS FROM SPATIALLY UNRESOLVED SOURCE (OXFORD TEMPLATES) ADDED WITH CMB #'
echo '##########################################################################################'
outfile="hi-co-cmb"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window --freqinfo=$freqrange --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=5.0 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --co_1_0 --co_2_1 --co_3_2 --co_4_3 --co_5_4 --co_6_5 --co_7_6 --co_8_7 --co_9_8 --co_10_9 --freqaxis
echo '----------------------------------------------------------------'

outfile="cmb"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$out_window --freqinfo=$freqrange --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=5.0 --rarefpos=180.0 --decrefpos=0.0 --hi=Oxford --co_1_0 --co_2_1 --co_3_2 --co_4_3 --co_5_4 --co_6_5 --co_7_6 --co_8_7 --co_9_8 --co_10_9 --freqaxis
echo '----------------------------------------------------------------'

echo '####################################################################'
echo '# TESTING FOR DIFFERENCES WITH REFERENCE FILES USING DIFF COMMANDS #'
echo '####################################################################'
cd ../Tests/
for outfile in *cmb*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done

# Build spectra plots and print out integrated fluxes 
echo '####################################################################'
echo '# COMPUTE INTEGRATED FLUXES FROM DIFFERENCE CUBES AND CMB SPECTRUM #'
echo '####################################################################'
cd ../Routines/
python plot-CMB-tests.py

import math
import numpy
import pyfits
import os
import scipy
import scipy.signal
import scipy.interpolate
import scipy.special
import types
from common_routines import *
import sys
sys.path.append("../Config/")
from Config_Map import *
from Config_Path import *
from common_map_routines import *
import time
#from ipol import *
#import Image
import scipy.ndimage


########################################
#### EPOCH OF REIONIZATION ROUTINES ####
########################################

# HERE ARE DEFINED THE PARAMETERS OF THE EOR TEMPLATES
ist_eor_fmin=57.688416 # MINIMUM FREQUENCY, in MHz
ist_eor_fmax=216.111366 # MAXIMUM FREQUENCY, in MHz
N_ist_eor_templates=2890 # NUMBER OF TEMPLATES
ist_eor_freqs=numpy.linspace(ist_eor_fmin,ist_eor_fmax,num=N_ist_eor_templates) # RETURNS AN ARRAY OF REGULARLY SPACED FREQUENCIES. THIS ASSUMES THAT THE TEMPLATES *ARE* REGULARLY SPACED IN FREQUENCY
ist_eor_pix= arcmin2deg(0.5) #0.003147002049180328 # PIXEL SIZE IN THE TEMPLATES, in degrees 
ist_eor_size=600 #488 # NUMBER OF PIXELS ACROSS A TEMPLATE

def weight_function(fc_out,df_out,fc_in,df_in):
    fmin_out=fc_out-df_out/2.0
    fmax_out=fc_out+df_out/2.0
    fmin_in=fc_in-df_in/2.0
    fmax_in=fc_in+df_in/2.0
    if ((fmax_out<=fmin_in)or(fmin_out>=fmax_in)):
        w=0
    else:
        if ((fmin_in<=fmin_out)and(fmax_in>=fmax_out)):
            w=(fmax_out-fmin_out)/(fmax_in-fmin_in)
        if ((fmin_in>=fmin_out)and(fmax_in<=fmax_out)):
            w=1
        if ((fmin_in<=fmin_out)and(fmax_in<=fmax_out)):
            w=(fmax_in-fmin_out)/(fmax_in-fmin_in)
        if ((fmin_in>=fmin_out)and(fmax_in>=fmax_out)):
            w=(fmax_out-fmin_in)/(fmax_in-fmin_in)
    return(w)

def make_ist_eor_map(fits_file):
    eor_freqs=ist_eor_freqs # in MHz
    dfreq_eor=eor_freqs[1]-eor_freqs[0] # in MHz
    hdulist=pyfits.open(fits_file)
    hdu=hdulist[0]
    Nx=hdu.header['NAXIS1']
    Ny=hdu.header['NAXIS2']
    Nfreqs=hdu.header['NAXIS3']
    result=numpy.zeros((Nfreqs,Ny,Nx),dtype='f')
    if (hdu.header['CTYPE3']=="FREQ"):
        freqs=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        if (hdu.header['CUNIT3']=="HZ"): freqs/=1e6 # That's what it should be from mapmaking_script.py
        if (hdu.header['CUNIT3']=="KHZ"): freqs/=1e3
        if (hdu.header['CUNIT3']=="GHZ"): freqs*=1e3
        dfreq=hdu.header['CDELT3']
        if (hdu.header['CUNIT3']=="HZ"): dfreq/=1e6 # That's what it should be from mapmaking_script.py
        if (hdu.header['CUNIT3']=="KHZ"): dfreq/=1e3
        if (hdu.header['CUNIT3']=="GHZ"): dfreq*=1e3
    elif (hdu.header['CTYPE3']=="VELO"):
        nu0=constant("nu0_HI") # in MHz # WATCH OUT THIS IS ONLY VALID IF IT'S HI ONLY !!!!
        velos=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        freqs=[]
        for v in velos:
            freqs.append(velo2freq(v,nu0))
    else:
        print "unknown"
    if (hdu.header['CUNIT1']=='DEGREE'):pix=deg2arcmin(abs(float(hdu.header['CDELT1'])))
    Nx_in_template=int(math.ceil(pix*Nx/deg2arcmin(ist_eor_pix)))
    Ny_in_template=int(math.ceil(pix*Ny/deg2arcmin(ist_eor_pix)))
    if (Nx_in_template%2==0):Nx_in_template+=1
    if (Ny_in_template%2==0):Ny_in_template+=1
    template_pixel_area=math.pow(deg2arcsec(ist_eor_pix),2.0)*2.3504e-11
    for i in range(Nfreqs):
        weights=numpy.zeros((N_ist_eor_templates),dtype='d')
        for j in range(N_ist_eor_templates):
            weights[j]=weight_function(freqs[i],dfreq,eor_freqs[j],dfreq_eor)
        w_array=numpy.where(weights>0)[0]
        channel=numpy.zeros((Ny_in_template,Nx_in_template),dtype='f') 
        for k in w_array:
            slice_file=IST_EOR_TEMPLATES_DIR+"ist_eor_map_"+num2str(k,4)+".fits"    
            hd=pyfits.open(slice_file)
            slice=hd[0].data  
            # HERE IS A KNOWN BUG : FoV HAS TO BE LESS THAN TEMPLATE FoV OTHERWISE IT CRASHES (NEED TO REPLICATE THE TEMPLATE FIRST)
            channel+=(weights[k]*slice[0,0,0:Ny_in_template,0:Nx_in_template]) # Now in JY/PIXEL
        if (numpy.sum(weights)>0):channel/=numpy.sum(weights)
        channel_transformed=apply_map_transform(channel,pix/deg2arcmin(ist_eor_pix),0.0,0.0,0.0)
        if (numpy.sum(channel_transformed)>0):
            norm=numpy.sum(channel)/numpy.sum(channel_transformed)
            channel_transformed*=norm
        sub_channel_transformed=channel_transformed[0:Ny,0:Nx]
        result[i][:][:]=sub_channel_transformed[:][:]
    return(result)


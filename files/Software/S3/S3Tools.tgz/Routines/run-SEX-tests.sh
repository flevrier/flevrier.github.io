#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sex_tarfile="single-sex"
redshift=1.96970937 # Apparent redshift - this is the one used by default
RA_C=0.00213 # Source right ascension in degrees 
DEC_C=0.0182 # Source declination in degrees 

freqrange="0.15,0.1,180" # 180 channels (100 MHz wide) from 150 MHz to 18 GHz
window_30as="-10.0,20.0,50.0,80.0"
window_30as_tl="7.668,20.0,65.52,80.0"
window_30as_bl="7.668,20.0,50.0,65.52"
window_30as_tr="-10.0,7.668,65.52,80.0"
window_30as_br="-10.0,7.668,50.0,65.52"
window_10am="-300.,300.,-300.,300."
window_60as="-20.,40.,40.,100."
window_600as="-300.,300.,-300.,300."

outfile="sex-100mas"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-3as"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_60as --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=3.0 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-40as"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_600as --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=50.0 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-100mas-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as --freqinfo=$freqrange --bmaj=0.2 --bmin=0.2 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-3as-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_60as --freqinfo=$freqrange --bmaj=6.0 --bmin=6.0 --bpa=0.0 --noise=0.0 --pixelsize=3.0 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-40as-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_600as --freqinfo=$freqrange --bmaj=100.0 --bmin=100.0 --bpa=0.0 --noise=0.0 --pixelsize=50.0 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

####################################################
# TESTING SPATIAL WINDOW CUTTING IN FOUR QUADRANTS #
####################################################

outfile="sex-100mas-tl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as_tl --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-100mas-bl"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as_bl --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-100mas-tr"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as_tr --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

outfile="sex-100mas-br"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SEX_map_script.py --in=$sex_tarfile --out=$outfile --dir=$tests_dir --types=2 --window=$window_30as_br --freqinfo=$freqrange --bmaj=0.01 --bmin=0.01 --bpa=0.0 --noise=0.0 --pixelsize=0.1 --imageaccuracy=20 --rarefpos=180.0 --decrefpos=0.0 --continuum=I --freqaxis --zrange=$redshift,$redshift --nocmb
echo '----------------------------------------------------------------'

echo '####################################################################'
echo '# TESTING FOR DIFFERENCES WITH REFERENCE FILES USING DIFF COMMANDS #'
echo '####################################################################'
cd ../Tests/
for outfile in *sex*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done

# Build spectra plots and print out integrated fluxes 
echo '####################################################################'
echo '# BUILDING IMAGES OF SOURCES AND PLOTS OF SPECTRA FOR OUTPUT FILES #'
echo '####################################################################'
cd ../Routines/
python plot-SEX-tests.py

#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sax_tarfile="single-sax"

freqrange="1.420405751,6.25e-05,1"
window_1deg="7408.6236,11008.6236,7339.0536,10939.0536"

outfile="map-noise"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_1deg --freqinfo=$freqrange --bmaj=2.0 --bmin=2.0 --bpa=0.0 --noise=10.0 --pixelsize=5.0 --rarefpos=180.0 --decrefpos=0.0 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

outfile="map-noise-smeared"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_1deg --freqinfo=$freqrange --bmaj=30.0 --bmin=30.0 --bpa=0.0 --noise=10.0 --pixelsize=5.0 --rarefpos=180.0 --decrefpos=0.0 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb
echo '----------------------------------------------------------------'

# Build spectra plots and print out integrated fluxes 
echo '####################################################################'
echo '# BUILDING IMAGES OF SOURCES AND PLOTS OF SPECTRA FOR OUTPUT FILES #'
echo '####################################################################'
cd ../Routines/
python plot-noise-tests.py

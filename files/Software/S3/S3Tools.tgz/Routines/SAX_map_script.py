import math
import numpy
import sys
import getopt
from common_routines import *
from io_routines import *
from SAX_map_routines import *
from Config_Map import *
from Config_Path import *
from Config_SAX import *

def help():
    output=os.popen(PDFViewer+" "+Help_File+" &")

tstart=time.time()

# DEFAULT SCRIPT ARGUMENTS
hi=0
co_1_0=0
co_2_1=0
co_3_2=0
co_4_3=0
co_5_4=0
co_6_5=0
co_7_6=0
co_8_7=0
co_9_8=0
co_10_9=0
third_axis_unit='FREQ'
rarefpos=180.0
decrefpos=0.0
userefpos=0
dir=OUTPUT_DIR
window=''
in_id="None"
out_id="None"
freq_info=[]
bmaj=0.0
bmin=0.0
bpa=0.0
noise=0.0
pixelsize=0.0
ra_orientation=-1 # R.A. increases from right to left 
zrange=''
flux_limit=0.0 # Flux limit at the observing frequency, in Jy
separate_maps=0
gsm=0
eor=0
continuum=[]
cmb=1
hash=''

# GATHER SCRIPT ARGUMENTS
try:
    opts, args = getopt.getopt(sys.argv[1:], "h",["help","in=","out=","window=","freqinfo=","bmaj=","bmin=","bpa=","noise=","pixelsize=","dir=","hi=","co_1_0","co_2_1","co_3_2","co_4_3","co_5_4","co_6_5","co_7_6","co_8_7","co_9_8","co_10_9","freqaxis","veloaxis","userefpos","rarefpos=","decrefpos=","reversera","zrange=","flux_limit=","separate_maps","gsm","eor=","continuum=","nocmb","hash="])
except getopt.GetoptError:          
    help()                         
    sys.exit(2)                     
for opt, arg in opts:                
    if opt in ("-h", "--help"):      
        help()                     
        sys.exit()
    elif opt in ("--in"): in_id=arg          
    elif opt in ("--out"): out_id=arg        
#    elif opt in ("--types"): 
#        source_types=[]
#        for t in arg.split(","): source_types.append(int(t))
    elif opt in ("--window"): 
        window=[]
        for w in arg.split(","): window.append(float(w))
    elif opt in ("--zrange"): 
        zrange=[]
        for z in arg.split(","): zrange.append(float(z))
    elif opt in ("--freqinfo"): 
        s=arg.split(",")
        freq_info.extend([float(s[0]),float(s[1]),int(s[2])])
    elif opt in ("--bmaj"): bmaj=float(arg)
    elif opt in ("--bmin"): bmin=float(arg)
    elif opt in ("--bpa"): bpa=float(arg)
    elif opt in ("--noise"): noise=float(arg)
    elif opt in ("--pixelsize"): pixelsize=float(arg)
#    elif opt in ("--continuum"): continuum=1
    elif opt in ("--hi"): hi=arg
    elif opt in ("--co_1_0"): co_1_0=1
    elif opt in ("--co_2_1"): co_2_1=1
    elif opt in ("--co_3_2"): co_3_2=1
    elif opt in ("--co_4_3"): co_4_3=1
    elif opt in ("--co_5_4"): co_5_4=1
    elif opt in ("--co_6_5"): co_6_5=1
    elif opt in ("--co_7_6"): co_7_6=1
    elif opt in ("--co_8_7"): co_8_7=1
    elif opt in ("--co_9_8"): co_9_8=1
    elif opt in ("--co_10_9"): co_10_9=1
    elif opt in ("--continuum"):
        for p in arg.split(","): continuum.append(p)
    elif opt in ("--freqaxis"): third_axis_unit='FREQ'
    elif opt in ("--veloaxis"): 
        if ((hi+co_1_0+co_2_1+co_3_2+co_4_3+co_5_4+co_6_5+co_7_6+co_8_7+co_9_8+co_10_9)==1): # THERE MUST BE ONE AND ONLY ONE LINE REQUESTED FOR VELOCITY AXIS TO MAKE ANY SENSE.
            third_axis_unit='VELO'
        else:
            print "There must be one and only one line requested for velocity axis to make any sense. Reverting to frequency axis."
            third_axis_unit='FREQ'
    elif opt in ("--userefpos"): userefpos=1
    elif opt in ("--rarefpos"): rarefpos=float(arg)
    elif opt in ("--decrefpos"): decrefpos=float(arg)
    elif opt in ("--gsm"): gsm=1
    elif opt in ("--eor"):eor=arg
    elif opt in ("--nocmb"):cmb=0
    elif opt in ("--dir"): dir=arg
    elif opt in ("--flux_limit"): flux_limit=float(arg)
    elif opt in ("--reversera"): ra_orientation=1 # R.A. increases from left to right
    elif opt in ("--separate_maps"): separate_maps=1 # Makes separate maps for different lines
    elif opt in ("--hash"):hash=arg
if ((in_id=="None") or (len(freq_info)==0) or (pixelsize==0.0) or ((co_1_0==0) and (co_2_1==0) and (co_3_2==0) and (co_4_3==0) and (co_5_4==0) and (co_6_5==0) and (co_7_6==0) and (co_8_7==0) and (co_9_8==0) and (co_10_9==0) and (hi==0))):
    help()
    sys.exit(2)


# IS THERE A .result FILE SOMEWHERE INSIDE dir ?
print "Looking for a .result file..."
resultfile=os.popen("find  "+dir+" -name "+in_id+".result").read().replace("\n","").replace("//","/")
if (resultfile==""):# IF NO, THEN LOOK FOR A TAR BALL
    print "No .result file found. Looking for a tar ball..."
    tarfile=os.popen("find  "+dir+" -name "+in_id+".tar*").read().replace("\n","").replace("//","/")
    if (tarfile!=""):
        print "Tar ball found. Processing it..."
        # UNTAR IT
        if ".gz" in tarfile:untarflag="-C "+dir+" -zxf"
        else:untarflag="-C "+dir+" -xf"
        untar=os.popen("tar "+untarflag+" "+tarfile)
        untar.close()
        # AND FIND THE .result AND .sql FILES
        resultfile=os.popen("find  "+dir+" -name "+in_id+".result").read().replace("\n","").replace("//","/")
        sqlfile=os.popen("find  "+dir+" -name "+in_id+".sql").read().replace("\n","").replace("//","/")
    else:
        print "No tar ball found. Check your inputs (especially the --dir and --in arguments) !"
        sys.exit(2)
else: # IF YES, THEN THERE SHOULD ALSO BE A SQL FILE
    print "A .result file was found. Looking for a .sql file..."
    sqlfile=os.popen("find  "+dir+" -name "+in_id+".sql").read().replace("\n","").replace("//","/")
    if (sqlfile==""):
        print "No .sql file found. Check your inputs !"
        sys.exit(2)
    else:
        print "A .sql file was found."
RESULT_DIR=os.path.dirname(resultfile)

query_file=(RESULT_DIR+"/"+in_id+'.query').replace("//","/")
print "Looking for a .query file..."
# IF NO QUERY FILE FOUND, IT MUST BE BUILT
if (not(os.path.isfile(query_file))):
    print "No .query file found. Building one..."
    SAX_create_query_file(RESULT_DIR,in_id)
else:
    print "A .query file was found."
# MOVE TO TMP DIRECTORY
#os.chdir(SCRATCH_DIR)

## CLEAN IT
##os.popen("rm -rf "+SCRATCH_DIR+"/*")

# THERE IS ROOM FOR SOME SPEED IMPROVEMENT HERE BY NOT UNTARRING/TARRING CONSTANTLY
# FIND WHAT IS THE INPUT : MUST BE A TARBALL, EITHER .tar OR .tar.gz
#t0=time.time()
#if ((not(os.path.isfile(dir+"/"+in_id+".tar.gz"))) and (not(os.path.isfile(dir+"/"+in_id+".tar")))): # IF NOTHING KNOWN CAN BE FOUND, EXIT
#    print "Input file type not recognized."
#    sys.exit(2)
#else:
#    if os.path.isfile(dir+"/"+in_id+".tar"): # IF PLAIN TARBALL FOUND
#        original_file=(dir+"/"+in_id+".tar").replace("//","/")
#        # COPY TARBALL TO TMP DIRECTORY
#        os.popen("cp "+original_file+" "+SCRATCH_DIR)
#        # UNTAR
#        copied_file=(SCRATCH_DIR+"/"+os.path.basename(original_file)).replace("//","/")
#        os.popen("tar -xf "+copied_file)
#        # REMOVE TARBALL
#        os.popen("rm -f "+copied_file)
#    if os.path.isfile(dir+"/"+in_id+".tar.gz"): # IF GZIPPED TARBALL FOUND
#        original_file=(dir+"/"+in_id+".tar.gz").replace("//","/")
#        # COPY TARBALL TO TMP DIRECTORY
#        os.popen("cp "+original_file+" "+SCRATCH_DIR)
#        # UNTAR
#        copied_file=(SCRATCH_DIR+"/"+os.path.basename(original_file)).replace("//","/")
#        os.popen("tar -zxf "+copied_file)
#        # REMOVE TARBALL
#        os.popen("rm -f "+copied_file)
#t1=time.time()
#print "Preliminary copying and untarring takes "+str(t1-t0)+" seconds"
#
#query_file=(SCRATCH_DIR+"/"+in_id+'.query').replace("//","/")
## IF NO QUERY FILE FOUND, QUERY IS FROM THE ONLINE SAX, AND QUERY FILE MUST BE BUILT
#if (not(os.path.isfile(query_file))):
#    SAX_create_query_file(SCRATCH_DIR,in_id)

# READ QUERY WINDOW IF NONE SPECIFIED
if (window==''):
    sqw=read_info(query_file,"WINDOW").split(",")
    window=[]
    for s in sqw:window.append(deg2arcsec(float(s)))
    print "Using query window ["+(",".join(array_to_string_array(window)))+"] (arcseconds) as mapping window"

# READ QUERY REDSHIFT RANGE IF NONE SPECIFIED
if (zrange==''):
    sqz=read_info(query_file,"REDSHIFT").split(",")
    zrange=[]
    for s in sqz:zrange.append(float(s))
    print "Using query redshift ["+(",".join(array_to_string_array(zrange)))+"] as mapping redshift range"

print "File contains "+read_info(query_file,"N_OBJECTS")+" objects"

# Direction of the central pixel in the whole field, in degrees. Be careful when getting close to zero R.A. Is used only if userefpos is not zero.
offset=[rarefpos,decrefpos]
# Beam parameters [FWHM along major axis (arcseconds), FWHM along minor axis (arcseconds), position angle (radians), scaling, zero level, unit]
beam_info=[bmaj,bmin,bpa,1.0,0.0,'JY/PIXEL']

# Filenames for the output map, catalog, source list, python script and KARMA annotation file
#if (separate_maps==0):
#    full_map=0
map_file=(SCRATCH_DIR+"/"+out_id+'.fits').replace("//","/")
#annotation_file=SCRATCH_DIR+"/"+out_id+'.ann'
#catalog_file=SCRATCH_DIR+"/"+out_id+'.txt'
#information_file=SCRATCH_DIR+"/"+out_id+'.tmp'

map_info={'flux_limit':flux_limit,'window':window,'offset':offset,'pixelsize':pixelsize,'freq_info':freq_info,'hi':hi,'co_1_0':co_1_0,'co_2_1':co_2_1,'co_3_2':co_3_2,'co_4_3':co_4_3,'co_5_4':co_5_4,'co_6_5':co_6_5,'co_7_6':co_7_6,'co_8_7':co_8_7,'co_9_8':co_9_8,'co_10_9':co_10_9,'third_axis_unit':third_axis_unit,'noise':noise,'ra_orientation':ra_orientation,'zrange':zrange,'continuum':continuum,'userefpos':userefpos,'hash':hash}

# READ COLUMN NAMES FROM THE INFO FILE
structure=read_info(query_file,"GALAXY_ITEMS").split(",")

# VERIFY THAT THE NECESSARY INFO IS PRESENT (ESPECIALLY ZTYPE)
#if (ztype not in structure):
#    print ztype+" is not present in the structure file"
#    sys.exit(2)

# Make FITS header information
hdr=SAX_header_info(map_info) 
imsize=image_size(window,pixelsize)

# MAKE BEAM
b=beam(beam_info,pixelsize)    

#if (len(pols)>0): size_string=str(imsize[0])+" x "+str(imsize[1])+" x "+str(freq_info[2])+" x "+str(len(pols))
#else: 
size_string=str(imsize[0])+" x "+str(imsize[1])+" x "+str(freq_info[2])
if (separate_maps!=0): print "Will build "+size_string+" images into separate FITS files"
else: print "Will build "+size_string+" image"
#galaxy_file=(SCRATCH_DIR+"/"+in_id+'.result').replace("//","/")
galaxy_file=(RESULT_DIR+"/"+in_id+'.result').replace("//","/")

t0=time.time()
# BUILD S3 MAP
map=SAX_build_map(galaxy_file,structure,map_info,b)    
t1=time.time()
print "Actually making S3 map takes "+str(t1-t0)+" seconds"


t0=time.time()
write_map_to_fits(map,hdr,beam_info,map_file)
t1=time.time()
print "Writing to FITS takes "+str(t1-t0)+" seconds"

# BUILD CMB SIGNAL (T=2.725 K) UNLESS SPECIFIED BY --nocmb. THIS IS ISOTROPIC : NO DIPOLE OR FLUCTUATIONS....
if (cmb==1):
    print "Making CMB signal"
    from CMB_routines import *
    cmb_map=make_cmb_map(map_file)
    noncmb_hdr=(pyfits.open(map_file)[0]).header
    if (separate_maps==0):
        noncmb_data=(pyfits.open(map_file)[0]).data
        hdu_out=pyfits.PrimaryHDU(cmb_map+noncmb_data)
    else:
        map_file=(SCRATCH_DIR+"/"+out_id+'.CMB.fits').replace("//","/")
        hdu_out=pyfits.PrimaryHDU(cmb_map)
    hdu_out.header=noncmb_hdr
    rm=os.popen("rm -f "+map_file)
    rm.close()
    hdu_out.writeto(map_file)
    if (separate_maps==0): print "Added CMB signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]
    else: print "Wrote CMB signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]

# BUILD GLOBAL SKY MODEL MAP 
if (gsm!=0):
    from GSM_routines import *
    print "Making GSM map(s)"
    gsm_map=make_gsm_map(map_file)
    nongsm_hdr=(pyfits.open(map_file)[0]).header
    if (separate_maps==0):
        nongsm_data=(pyfits.open(map_file)[0]).data
        hdu_out=pyfits.PrimaryHDU(gsm_map+nongsm_data)
    else:
        map_file=(SCRATCH_DIR+"/"+out_id+'.GSM.fits').replace("//","/")
        hdu_out=pyfits.PrimaryHDU(gsm_map)
    hdu_out.header=nongsm_hdr
    rm=os.popen("rm -f "+map_file)
    rm.close()
    hdu_out.writeto(map_file)
    if (separate_maps==0): print "Added GSM signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]
    else: print "Wrote GSM signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]

# BUILD EPOCH OF REIONIZATION SIGNAL MAP
if (eor!=0):
    from EOR_routines import *
    print "Making EOR map(s)"
    if (eor=="IST"):
        print "using IST"
        eor_map=make_ist_eor_map(map_file)
#    print numpy.min(eor_map),numpy.max(eor_map)
    noneor_hdr=(pyfits.open(map_file)[0]).header
    if (separate_maps==0):
        noneor_data=(pyfits.open(map_file)[0]).data
        hdu_out=pyfits.PrimaryHDU(eor_map+noneor_data)
    else:
        map_file=(SCRATCH_DIR+"/"+out_id+'.EOR.fits').replace("//","/")
        hdu_out=pyfits.PrimaryHDU(eor_map)
    hdu_out.header=noneor_hdr
    rm=os.popen("rm -f "+map_file)
    rm.close()
    hdu_out.writeto(map_file)
    if (separate_maps==0): print "Added EOR signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]
    else: print "Wrote EOR signal to "+(map_file.split("/"))[len(map_file.split("/"))-1]
#
## WRITE OUTPUT TO TARBALL
##t0=time.time()
##os.popen("rm -rf "+in_id+".*")


# TARBALL INACTIVE FOR THE MOMENT
#os.popen("tar czf "+out_id+".tar.gz "+out_id+".*")
#os.popen("mv "+out_id+".tar.gz "+dir)
#os.popen("rm -rf "+out_id+".*")

os.popen("mv "+SCRATCH_DIR+"/"+out_id+".fits "+dir)
if (os.path.isfile(SCRATCH_DIR+"/"+out_id+".EOR.fits")):os.popen("mv "+SCRATCH_DIR+"/"+out_id+".EOR.fits "+dir)
if (os.path.isfile(SCRATCH_DIR+"/"+out_id+".GSM.fits")):os.popen("mv "+SCRATCH_DIR+"/"+out_id+".GSM.fits "+dir)
if (os.path.isfile(SCRATCH_DIR+"/"+out_id+".CMB.fits")):os.popen("mv "+SCRATCH_DIR+"/"+out_id+".CMB.fits "+dir)


##t1=time.time()
##print "Making output Tarball takes "+str(t1-t0)+" seconds"
#
###else:
###    print "No source list file exists. You must build one using sourcelist_script.py"
##tend=time.time()
##print "Total time is "+str(tend-tstart)+" seconds"

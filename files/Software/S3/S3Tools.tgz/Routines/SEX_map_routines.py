import math
import numpy
import pyfits
import os
import scipy
import scipy.signal
import scipy.interpolate
import scipy.special
import types
from common_routines import *
import sys
sys.path.append("../Config/")
from Config_SEX import *
from Config_Map import *
from Config_Path import *
import time
#from ipol import *
#import Image
import scipy.ndimage
from common_map_routines import *

############ FAKE HI

def hi_profile_parameters(redshift,vasymp,majaxis,minaxis): # R.W. only
    nu0=constant("nu0_HI")
#    factor_edge_sigma=numpy.random.uniform(low=shape_factors[0],high=shape_factors[1])
    factor_dip_amplitude=numpy.random.uniform(low=shape_factors[2],high=shape_factors[3])
    if (minaxis!=majaxis):
        delta_v=vasymp*math.sin(math.acos(minaxis/majaxis))
        central_velo=freq2velo(redshift2freq(redshift,nu0),nu0)
#        edge_sigma=12.0+6*numpy.random.standard_normal() # Suggested by R.A.
        edge_sigma=12.0+2*numpy.random.standard_normal() # 01/04/2011
        if (edge_sigma < 5.0): edge_sigma=5.0
        if (edge_sigma > 20.0): edge_sigma=20.0
#        edge_sigma=fwhm2sigma(factor_edge_sigma*shape_factors[4]*delta_v)
        maxval=(1.0)/(math.sqrt((2.0)*math.pi)*edge_sigma)
        dip_amplitude=factor_dip_amplitude*maxval
        dip_sigma=shape_factors[5]*delta_v
    else:
        delta_v=vasymp*0.01
        central_velo=freq2velo(redshift2freq(redshift,nu0),nu0)
#        edge_sigma=12.0+6*numpy.random.standard_normal() # Suggested by R.A.
        edge_sigma=12.0+2*numpy.random.standard_normal() # 01/04/2011
        if (edge_sigma < 5.0): edge_sigma=5.0
        if (edge_sigma > 20.0): edge_sigma=20.0
#        edge_sigma=fwhm2sigma(factor_edge_sigma*shape_factors[4]*delta_v)
        maxval=(1.0)/(math.sqrt((2.0)*math.pi)*edge_sigma)
        dip_amplitude=factor_dip_amplitude*maxval
        dip_sigma=shape_factors[5]*delta_v
    return([central_velo,delta_v,edge_sigma,maxval,dip_amplitude,dip_sigma])

def integrated_flux(m_HI,distance):
    return((math.pow(10.0,m_HI)/(math.pow(distance,2.)))*(1./2.36)*(1e-5))

def low_edge_up_to_v(vmax,parameters):
    central_velo=parameters[0]
    delta_v=parameters[1]
    edge_sigma=parameters[2]
    maxval=parameters[3]
    dip_amplitude=parameters[4]
    dip_sigma=parameters[5]
    A=maxval*math.sqrt(2.0*math.pi)*edge_sigma
    delta=dip_amplitude*math.sqrt(2.0*math.pi)*dip_sigma
    result=(A/(2.0))*((2.0)-scipy.special.erfc((vmax-central_velo+delta_v)/(math.sqrt(2.0)*edge_sigma)))
    return(result)

def dip_up_to_v(vmax,parameters):
    central_velo=parameters[0]
    delta_v=parameters[1]
    edge_sigma=parameters[2]
    maxval=parameters[3]
    dip_amplitude=parameters[4]
    dip_sigma=parameters[5]
    A=maxval*math.sqrt(2.0*math.pi)*edge_sigma
    delta=dip_amplitude*math.sqrt(2.0*math.pi)*dip_sigma
    vmin=central_velo-delta_v
    result=(maxval*(vmax-vmin))-((delta/(2.0))*(scipy.special.erfc((vmin-central_velo)/(math.sqrt(2.0)*dip_sigma))-scipy.special.erfc((vmax-central_velo)/(math.sqrt(2.0)*dip_sigma))))
    return(result)

def high_edge_up_to_v(vmax,parameters):
    central_velo=parameters[0]
    delta_v=parameters[1]
    edge_sigma=parameters[2]
    maxval=parameters[3]
    dip_amplitude=parameters[4]
    dip_sigma=parameters[5]
    A=maxval*math.sqrt(2.0*math.pi)*edge_sigma
    delta=dip_amplitude*math.sqrt(2.0*math.pi)*dip_sigma
    result=(A/(2.0))*((1.0)-scipy.special.erfc((vmax-central_velo-delta_v)/(math.sqrt(2.0)*edge_sigma)))
    return(result)

def integrated_profile_up_to_v(vmax,parameters):
    central_velo=parameters[0]
    delta_v=parameters[1]
    edge_sigma=parameters[2]
    maxval=parameters[3]
    dip_amplitude=parameters[4]
    dip_sigma=parameters[5]
    A=maxval*math.sqrt(2.0*math.pi)*edge_sigma
    delta=dip_amplitude*math.sqrt(2.0*math.pi)*dip_sigma
    # CASE 1 : vmax < central_velo-delta_v
    if (vmax<central_velo-delta_v):
        result=low_edge_up_to_v(vmax,parameters)
    # CASE 2 : vmax > central_velo-delta_v and < central_velo+delta_v
    if ((vmax>=central_velo-delta_v) and (vmax<central_velo+delta_v)):
        result=(A/(2.0))+dip_up_to_v(vmax,parameters)
    # CASE 3 : vmax > central_velo+delta_v
    if (vmax>=central_velo+delta_v):
        result=(A/(2.0))+(maxval*(2.0)*delta_v)-(delta*scipy.special.erf(delta_v/(math.sqrt(2.0)*dip_sigma)))+high_edge_up_to_v(vmax,parameters)
    return(result)

def full_integrated_profile(parameters):
    central_velo=parameters[0]
    delta_v=parameters[1]
    edge_sigma=parameters[2]
    maxval=parameters[3]
    dip_amplitude=parameters[4]
    dip_sigma=parameters[5]
    A=maxval*math.sqrt(2.0*math.pi)*edge_sigma
    delta=dip_amplitude*math.sqrt(2.0*math.pi)*dip_sigma
    result=A+(maxval*(2.0)*delta_v)-(delta*scipy.special.erf(delta_v/(math.sqrt(2.0)*dip_sigma)))
    return(result)

def channel_boundary_hi_fluxes(cbv,parameters):
    fluxes=[]
    for vmax in cbv:
        fluxes.append(integrated_profile_up_to_v(vmax,parameters))
    return(fluxes)

def hi_fluxes(cbv,cbhif,int_flux,norm):
    fluxes=[]
    for i in range(len(cbv)-1):
        v1=cbv[i]
        v2=cbv[i+1]
        f1=cbhif[i]
        f2=cbhif[i+1]
        fluxes.append((int_flux/norm)*((f2-f1)/(v2-v1)))
    return(fluxes)

############ CONTINUUM

def type_of_continuum_shape(logfreqs,logfluxes): # D.O.: Watch out that fluxes in the DB are not logs
    slopevals=[]
    for i in range(len(logfluxes)):
        if i>0: slopevals.append((logfluxes[i]-logfluxes[i-1])/(logfreqs[i]-logfreqs[i-1]))
    if (math.fabs(numpy.std(slopevals)/numpy.mean(slopevals)) < epsilon_power_law_sed):# POWER-LAW
        slope=numpy.mean(slopevals)
        return(0,slope)
    else: # LOG-POLYNOMIAL
        p=scipy.polyfit(logfreqs,logfluxes,degree_logpolynomial_fit)        
        return(degree_logpolynomial_fit,p)

def continuum_flux_density(obs_freq,logfreqs,logfluxes,shape): # D.O.: Watch out that fluxes in the DB are not logs
    if (shape[0]==0):
        result=math.pow(10.0,((shape[1]*(math.log10(obs_freq)-logfreqs[0]))+logfluxes[0]))
    else:
        result=math.pow(10.0,scipy.polyval(shape[1],math.log10(obs_freq)))
    return(result)

def continuum_flux(min_freq,max_freq,logfreqs,logfluxes,shape):
    result=0.0
    delta_freq=(max_freq-min_freq)/float(Nsubchan)
    for i in range(Nsubchan):
        c=continuum_flux_density(min_freq+delta_freq*(0.5+float(i)),logfreqs,logfluxes,shape)
        result+=c
    return(result/float(Nsubchan))

def elliptical_template(XY_grids,pixelsize,ra,dec,majaxis,minaxis,pa,crpix,crval):
    X0=((XY_grids[0]-float(crpix[0]))*pixelsize)+crval[0]
    Y0=((XY_grids[1]-float(crpix[1]))*pixelsize)+crval[1]
    X=(X0-ra)*math.cos(pa)-(Y0-dec)*math.sin(pa)
    Y=(X0-ra)*math.sin(pa)+(Y0-dec)*math.cos(pa)
    d2=numpy.multiply(X/minaxis,X/minaxis)+numpy.multiply(Y/majaxis,Y/majaxis)
    sharp=numpy.zeros_like(d2)
    within=numpy.where(d2 < 0.25)
    if (len(within[0])==0):
        sharp[crpix[0],crpix[1]]=1.0
    else:
        for k in range(len(within[0])):
            sharp[within[1][k]][within[0][k]]=1.0
    return(sharp)

def coarsen_image(fine_image,coarse_size):
    Nx=coarse_size[0]
    Ny=coarse_size[1]
    Nx_fine=fine_image.shape[0]
    Ny_fine=fine_image.shape[1]
    factor_x=Nx_fine/Nx
    factor_y=Ny_fine/Ny
    result=numpy.zeros((Ny,Nx),dtype=float)
    i_a=range(Nx)
    j_a=range(Ny)
    for i in i_a:
        is_min=factor_x*i
        is_max=is_min+factor_x
        for j in j_a:
            js_min=factor_y*j
            js_max=js_min+factor_y
            result[i,j]=numpy.sum(fine_image[is_min:is_max,js_min:js_max])

    return(result)

def source_template(ra,dec,majaxis,minaxis,pa,pixelsize,beam,Xref,Yref,ra_orientation,pmin):
    i0=in_pixel(ra,Xref,pixelsize)
    j0=in_pixel(dec,Yref,pixelsize)
    val_i0=Xref+float(i0)*pixelsize
    val_j0=Yref+float(j0)*pixelsize
    if (majaxis==0.0):
        sharp=numpy.ones((1,1))
    else:
        p=int(math.ceil(majaxis/pixelsize))    
        N=2*p+1
        if (p<pmin):
#            print "Need to adapt... THERE APPEARS TO BE A BUG"
            if ((pmin/p)%2==0): factor=pmin/p+1 # NUMBER OF SMALL PIXELS PER BIG PIXEL
            else: factor=pmin/p
            N_hi=factor*N
            p_hi=(N_hi-1)/2
            pixelsize_hi=pixelsize/float(factor)
            XY_grids_hi=XY(N_hi,N_hi)
            sharp_hi=elliptical_template(XY_grids_hi,pixelsize_hi,ra,dec,majaxis,minaxis,pa,[p_hi,p_hi],[val_i0,val_j0])
            sharp=coarsen_image(sharp_hi,[N,N])
        else:
            XY_grids=XY(N,N)
            sharp=elliptical_template(XY_grids,pixelsize,ra,dec,majaxis,minaxis,pa,[p,p],[val_i0,val_j0])
    result2d=apply_beam(sharp,beam)
    result2d=result2d/total(result2d)
    Nx=result2d.shape[1]
    Ny=result2d.shape[0]
    crval=[arcsec2deg(val_i0),arcsec2deg(val_j0),0,0]
    crpix=[result2d.shape[0]/2+1,result2d.shape[1]/2+1,1,0]
    if ra_orientation>0:
        cdelt=[arcsec2deg(pixelsize),arcsec2deg(pixelsize),1.0,1.0]
    else:        
        cdelt=[-arcsec2deg(pixelsize),arcsec2deg(pixelsize),1.0,1.0]
    ctype=['RA---SIN','DEC--SIN','FREQ    ','STOKES  ']
    cunit=['DEGREE  ','DEGREE  ','HZ      ','        ']
    return(result2d,crval,crpix,cdelt,ctype,cunit,Nx,Ny)

def SEX_build_map(result_file,structure,map_parameters,b):
    # GET MAP PARAMETERS
    window=map_parameters['window']
    offset=map_parameters['offset']
    pixelsize=map_parameters['pixelsize']
    freq_info=map_parameters['freq_info']
    hi=map_parameters['hi']
    pmin=map_parameters['pmin']
    continuum=map_parameters['continuum']
    pols=map_parameters['pols']    
    third_axis_unit=map_parameters['third_axis_unit']
    noise=map_parameters['noise']
    ra_orientation=map_parameters['ra_orientation']
    zrange=map_parameters['zrange']
    ztype=map_parameters['ztype']
    zmin=numpy.min(numpy.array(zrange))
    zmax=numpy.max(numpy.array(zrange))

    imsize=image_size(window,pixelsize)
    Nx=imsize[0]
    Ny=imsize[1]

    Nfreqs=freq_info[2]
    i0=in_pixel(window[0],Xref,pixelsize)
    j0=in_pixel(window[2],Yref,pixelsize)
    val_i0=Xref+float(i0)*pixelsize
    val_j0=Yref+float(j0)*pixelsize
    scale=math.pow(10.0,round(math.log10(pixelsize/2.))-1)
    Npol=len(pols)
    if (Npol>1):
        result=numpy.zeros((Npol,Nfreqs,Ny,Nx),dtype=data_type)
        intpd=polarization_degree_pdf(10000)
    else:result=numpy.zeros((Nfreqs,Ny,Nx),dtype=data_type)

    obs_freqs=[]
    delta_freq=freq_info[1]
    for i in range(Nfreqs): obs_freqs.append(freq_info[0]+float(i)*freq_info[1])

#    tst=0.0
#    tflux=0.0
#    tpaste=0.0
    nu0=constant("nu0_HI")
    cbf=channel_boundary_frequencies(freq_info)
    cbv=channel_boundary_velocities(cbf,nu0)
#    print RA
#    print result_file
    fp=open(result_file,"r")
    description_line=fp.readline()
    for line in fp:
        source_info=line.replace("\n","").split(",")
#        print source_info
        ra=deg2arcsec(float(source_info[structure.index(RA)]))
        dec=deg2arcsec(float(source_info[structure.index(DEC)]))
        majaxis=float(source_info[structure.index(MAJOR_AXIS)])
        minaxis=float(source_info[structure.index(MINOR_AXIS)])
        redshift=float(source_info[structure.index(ztype)])
        pa=float(source_info[structure.index(PA)])
        distance=float(source_info[structure.index(DISTANCE)])
        ref_logfluxes=[float(source_info[structure.index(IQUV_CONTINUUM[0][0])]),
                       float(source_info[structure.index(IQUV_CONTINUUM[1][0])]),
                       float(source_info[structure.index(IQUV_CONTINUUM[2][0])]),
                       float(source_info[structure.index(IQUV_CONTINUUM[3][0])]),
                       float(source_info[structure.index(IQUV_CONTINUUM[4][0])])]        
        if (source_info[structure.index(M_HI)]!="NULL"):
            m_hi=float(source_info[structure.index(M_HI)])
            # HERE WE NEED TO COME UP WITH ROTATIONAL INFORMATION
            sftype=int(source_info[structure.index(SF_TYPE)])
            if (sftype==1): #SF - low
                # Corrected 01/04/2011
                vasymp=0.5*(normal_velocity_range[0]+normal_velocity_range[1])+(0.5*(normal_velocity_range[1]-normal_velocity_range[0])/3)*numpy.random.standard_normal()
                parameters=hi_profile_parameters(redshift,vasymp,majaxis,minaxis)
            if (sftype==2): #SF - high
                # Corrected 01/04/2011
                vasymp=0.5*(starburst_velocity_range[0]+starburst_velocity_range[1])+(0.5*(starburst_velocity_range[1]-starburst_velocity_range[0])/3)*numpy.random.standard_normal()
                parameters=hi_profile_parameters(redshift,vasymp,majaxis,minaxis)
        else:
            m_hi=source_info[structure.index(M_HI)]

        # CHECK IF SOURCE HAS A CHANCE OF BEING INSIDE THE MAP
#        print ra,dec,majaxis,window,b[1]
        beam_size_margin=3.0*b[1]
#        print ra+majaxis+beam_size_margin,ra-majaxis-beam_size_margin,dec+majaxis+beam_size_margin,dec-majaxis-beam_size_margin,redshift,zmin,zmax
        if (not((ra+majaxis+beam_size_margin<window[0]) or (ra-majaxis-beam_size_margin>window[1]) or (dec+majaxis+beam_size_margin<window[2]) or (dec-majaxis-beam_size_margin>window[3]) or (redshift<zmin) or (redshift>zmax))):
#            print "Im in"
#            t0=time.time()
            # COMPUTE FLUXES FOR THIS SOURCE
            fluxes=numpy.zeros((Nfreqs))
            if (continuum==1):continuum_shape=type_of_continuum_shape(ref_logfreqs,ref_logfluxes)
            if (hi==1):
#                print m_hi
                if (m_hi>0.0) and (m_hi!="NULL"): # MAKE SURE SOURCES WITH NO HI HAVE NON >0 VALUES
                    
                    # CHECK IF SOURCE REDSHIFT OK WITH BANDWIDTH
                    central_velo=parameters[0]
                    delta_v=parameters[1]
                    edge_sigma=parameters[2]
                    minv=central_velo-delta_v-10.0*edge_sigma
                    maxv=central_velo+delta_v+10.0*edge_sigma
                    maxbw=freq2velo(obs_freqs[0]*1000,nu0)
                    minbw=freq2velo(obs_freqs[Nfreqs-1]*1000,nu0)
                    if (not((minv>maxbw) or (maxv<minbw))):
#                        print source_info
                        int_flux=integrated_flux(m_hi,distance)
                        norm=full_integrated_profile(parameters)
                        cbhif=channel_boundary_hi_fluxes(cbv,parameters)
                        hif=hi_fluxes(cbv,cbhif,int_flux,norm)
                    else:
                        hif=numpy.zeros((Nfreqs))
                else:
                    hif=numpy.zeros((Nfreqs))
            for i in range(Nfreqs): # Loop over frequencies to build source flux
                min_freq=obs_freqs[i]-delta_freq/2.0
                max_freq=obs_freqs[i]+delta_freq/2.0
                if (continuum==1):fluxes[i]+=continuum_flux(min_freq,max_freq,ref_logfreqs,ref_logfluxes,continuum_shape)
                if (hi==1):fluxes[i]+=hif[i]

#            t1=time.time()
#            tflux+=(t1-t0)

            if (numpy.max(fluxes)>0.0):
                # BUILD TEMPLATE IMAGE FOR THE SOURCE
#                t0=time.time()
                template=source_template(ra,dec,majaxis,minaxis,pa,pixelsize,b,Xref,Yref,ra_orientation,pmin)
#                t1=time.time()
#                tst+=(t1-t0)
                # DETERMINE IF SOURCE TEMPLATE HAS AN OVERLAP WITH THE FULL IMAGE
                m0=template[0]
                crval=template[1]
                large_i0=in_pixel(deg2arcsec(crval[0]),Xref,pixelsize)
                large_j0=in_pixel(deg2arcsec(crval[1]),Yref,pixelsize)
                crpix=template[2]
                small_i0=crpix[0]
                small_j0=crpix[1]
                Px=m0.shape[len(m0.shape)-1]
                Py=m0.shape[len(m0.shape)-2]        
                imin_in_large=large_i0-i0-Px/2
                jmin_in_large=large_j0-j0-Py/2
                x=numpy.array(range(imin_in_large,imin_in_large+Px))
                criterion_x=(x>=0)&(x<Nx)
                y=numpy.array(range(jmin_in_large,jmin_in_large+Py))
                criterion_y=(y>=0)&(y<Ny)
                lx=numpy.where(criterion_x)[0]
                ly=numpy.where(criterion_y)[0]
                    
                if ((len(lx)>0) and (len(ly)>0)): # SOURCE TEMPLATE DOES HAVE AN OVERLAP WITH FULL IMAGE
                    lx1=numpy.min(lx)
                    lx2=numpy.max(lx)
                    ly1=numpy.min(ly)
                    ly2=numpy.max(ly)
                    x1=x[lx1]
                    x2=x[lx2]
                    y1=y[ly1]
                    y2=y[ly2]

        # TAKE CARE OF ANNOTATION AND CATALOG ENTRIES                        
#                    make_SEX_information_line(files[3],ra,dec,majaxis,minaxis,pa,m_hi,redshift,distance,vasymp,ref_logfluxes,val_i0,val_j0,galaxy_type,parameters,pixelsize,ra_orientation,Nx,Ny)
#                    t0=time.time()

                    # IN WHICH CASE :
#                    print pols
                    if ((len(pols)>0) and (pols!=["I"])): # POLARISATION IS INCLUDED
                        complex_pol=0.0
#                        complex_pol=ipol(fluxes,obs_freqs,intpd)
                    for i in range(Nfreqs): # LOOP OVER FREQUENCY PLANES
                        # MULTIPLY SOURCE TEMPLATE WITH FLUX AT CURRENT FREQUENCY
                        m=m0*fluxes[i]
                        if ((len(pols)>0) and (pols!=["I"])): # POLARISATION IS INCLUDED                            
#                            Q=(complex_pol[i]).real
#                            U=(complex_pol[i]).imag
#                            m_Q=m0*2.0*fluxes[i] # TEST CASE (OTHERWISE THERE IS A RANDOM PART)
#                            m_U=m0*4.0*fluxes[i] # TEST CASE (OTHERWISE THERE IS A RANDOM PART)
#                            m_Q=m0*Q
#                            m_U=m0*U
                            m_Q=m0*complex_pol
                            m_U=m0*complex_pol
                        # PASTE SOURCE ONTO FULL MAP
                        if (len(pols)>1): # 4 AXES : RA,DEC,FREQ,POL                            
                            i_p=0 # POLARISATION INDEX : 0 <-> I, 1 <-> Q, 2 <-> U                            
                            if ("I" in pols):
                                result[i_p,i,y1:y2+1,x1:x2+1]+=m[ly1:ly2+1,lx1:lx2+1]
                                i_p+=1
                            if ("Q" in pols):
                                result[i_p,i,y1:y2+1,x1:x2+1]+=m_Q[ly1:ly2+1,lx1:lx2+1]
                                i_p+=1
                            if ("U" in pols):
                                result[i_p,i,y1:y2+1,x1:x2+1]+=m_U[ly1:ly2+1,lx1:lx2+1]
                                i_p+=1

# PREVIOUS VERSION ---- MUCH MUCH SLOWER!
#                            for i_s in lx: # LOOP OVER X-INDICES IN THE TEMPLATE FALLING INTO FULL MAP
#                                for j_s in ly: # LOOP OVER Y-INDICES IN THE TEMPLATE FALLING INTO FULL MAP
#                                    i_p=0 # POLARISATION INDEX : 0 <-> I, 1 <-> Q, 2 <-> U
#                                    if ("I" in pols):
#                                        result[i_p,i,y[j_s],x[i_s]]+=m[j_s,i_s]
#                                        i_p+=1
#                                    if ("Q" in pols):
#                                        result[i_p,i,y[j_s],x[i_s]]+=m_Q[j_s,i_s]
#                                        i_p+=1
#                                    if ("U" in pols):
#                                        result[i_p,i,y[j_s],x[i_s]]+=m_U[j_s,i_s]
#                                        i_p+=1

                        else: # 3 AXES : RA,DEC,FREQ
                            result[i,y1:y2+1,x1:x2+1]+=m[ly1:ly2+1,lx1:lx2+1]
# PREVIOUS VERSION ---- MUCH MUCH SLOWER!
#                            for i_s in lx:
#                                for j_s in ly:
#                                    result[i,y[j_s],x[i_s]]+=m[j_s,i_s]

#                t1=time.time()
#                tpaste+=(t1-t0)

    fp.close()

#    print "Total time building source templates is "+str(tst)+" seconds"
#    print "Total time building fluxes is "+str(tflux)+" seconds"
#    print "Total time pasting sources is "+str(tpaste)+" seconds"
#    if (not(os.path.isfile(files[3]))): 
#        print "Warning : no source found inside the mapping window!"
#        os.popen("touch "+files[3])

    # DEAL WITH R.A. AXIS ORIENTATION AND NOISE
    slice=numpy.zeros((Ny,Nx),dtype=data_type)
    for i_f in range(Nfreqs):
        if (len(pols)>1):
            for i_p in range(Npol):
                slice[:][:]=result[i_p][i_f][:][:]
                if ra_orientation<0:
                    slice=numpy.transpose(numpy.rot90(slice))
                if (noise > 0.0):
                    sharp_n=numpy.random.standard_normal((Ny,Nx))
                    sharp_n=sharp_n-numpy.mean(sharp_n)
                    factor=(noise/numpy.std(sharp_n))*1e-9 # NOISE LEVEL IS SPECIFIED IN nJy
                    sharp_n*=factor
                    convolved_n=apply_beam(sharp_n,b)
                    cy=convolved_n.shape[0]/2
                    cx=convolved_n.shape[1]/2
                    n=convolved_n[cy-Ny/2:cy-Ny/2+Ny,cx-Nx/2:cx-Nx/2+Nx]
                    slice+=n
                result[i_p][i_f][:][:]=slice[:][:]
        else:
            slice[:][:]=result[i_f][:][:]
            if ra_orientation<0:
                slice=numpy.transpose(numpy.rot90(slice))
            if (noise > 0.0):
                sharp_n=numpy.random.standard_normal((Ny,Nx))
                sharp_n=sharp_n-numpy.mean(sharp_n)
                factor=(noise/numpy.std(sharp_n))*1e-9 # NOISE LEVEL IS SPECIFIED IN nJy
                sharp_n*=factor
                convolved_n=apply_beam(sharp_n,b)
                cy=convolved_n.shape[0]/2
                cx=convolved_n.shape[1]/2
                n=convolved_n[cy-Ny/2:cy-Ny/2+Ny,cx-Nx/2:cx-Nx/2+Nx]
                slice+=n
            result[i_f][:][:]=slice[:][:]
    return(result)

def SEX_header_info(map_parameters):
    # GET MAP PARAMETERS
    window=map_parameters['window']
    offset=map_parameters['offset']
    pixelsize=map_parameters['pixelsize']
    freq_info=map_parameters['freq_info']
    hi=map_parameters['hi']
    pmin=map_parameters['pmin']
    continuum=map_parameters['continuum']
    pols=map_parameters['pols']    
    third_axis_unit=map_parameters['third_axis_unit']
    noise=map_parameters['noise']
    ra_orientation=map_parameters['ra_orientation']
    zrange=map_parameters['zrange']
    ztype=map_parameters['ztype']
    userefpos=map_parameters['userefpos']

    zmin=numpy.min(numpy.array(zrange))
    zmax=numpy.max(numpy.array(zrange))
    Nx=in_pixel(window[1],Xref,pixelsize)-in_pixel(window[0],Xref,pixelsize)
    Ny=in_pixel(window[3],Yref,pixelsize)-in_pixel(window[2],Yref,pixelsize)

    # BUILD REFERENCES AND UNITS
    ctype=['RA---TAN','DEC--TAN']    
    cunit=['DEGREE  ','DEGREE  ']
#    print 'userefpos',userefpos
    if (userefpos==0):
        crval=[arcsec2deg(Xref+pixelsize*float(in_pixel(window[0],Xref,pixelsize))),arcsec2deg(Xref+pixelsize*float(in_pixel(window[2],Xref,pixelsize)))]
        if ra_orientation>0:
            crpix=[1,1]
            cdelt=[arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
        else:        
            crpix=[Nx,1]
            cdelt=[-arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
    else:
        if(Nx%2): # ODD
            crvalx=offset[0]
            crpixx=Nx/2+1
        else: # EVEN
            crvalx=offset[0]-ra_orientation*arcsec2deg(pixelsize/2.0)
            crpixx=Nx/2
        if(Ny%2): #ODD
            crvaly=offset[1]
            crpixy=Ny/2+1
        else: # EVEN
            crvaly=offset[1]-arcsec2deg(pixelsize/2.0)
            crpixy=Ny/2
        crval=[crvalx,crvaly]
        crpix=[crpixx,crpixy]
#        print crval,crpix
        if ra_orientation>0:
            cdelt=[arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
        else:        
            cdelt=[-arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
    if (third_axis_unit=='FREQ'):
        crval.append(freq_info[0]*1e9)
        crpix.append(1)
        ctype.append('FREQ    ')
        cunit.append('HZ      ')
        cdelt.append(freq_info[1]*1e9)
    # WARNING : USE VELOCITY AXIS ONLY IF A SINGLE LINE IS PLOTTED - NEEDS FIXING !
    if (third_axis_unit=='VELO'):
        print "WHICH LINE ?"
        crval.append(freq2velo(freq_info[0]*1e3,constant("nu0_CO")))
        crpix.append(1)
        ctype.append('VELO    ')
        cunit.append('KM/S    ')
        cdelt.append(-constant("c")*freq_info[1]*1e3/constant("nu0_CO"))
    if (len(pols)>1):
        crval.append(1)
        crpix.append(1)
        ctype.append('STOKES  ')
        cunit.append('        ')
        cdelt.append(1)
    return([crval,crpix,cdelt,ctype,cunit])

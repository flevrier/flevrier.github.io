import math
import numpy
import pyfits
import os
import scipy
import scipy.signal
import scipy.interpolate
import scipy.special
import types
from common_routines import *
import sys
sys.path.append("../Config/")
from Config_SAX import *
from Config_Map import *
from Config_Path import *
import time
#from ipol import *
#import Image
import scipy.ndimage
from common_map_routines import *

def SAX_build_map(galaxy_file,structure,map_parameters,b):
    # GET MAP PARAMETERS
    window=map_parameters['window']
    offset=map_parameters['offset']
    pixelsize=map_parameters['pixelsize']
    freq_info=map_parameters['freq_info']
    hi=map_parameters['hi']
    co_1_0=map_parameters['co_1_0']
    co_2_1=map_parameters['co_2_1']
    co_3_2=map_parameters['co_3_2']
    co_4_3=map_parameters['co_4_3']
    co_5_4=map_parameters['co_5_4']
    co_6_5=map_parameters['co_6_5']
    co_7_6=map_parameters['co_7_6']
    co_8_7=map_parameters['co_8_7']
    co_9_8=map_parameters['co_9_8']
    co_10_9=map_parameters['co_10_9']
    third_axis_unit=map_parameters['third_axis_unit']
    noise=map_parameters['noise']
    ra_orientation=map_parameters['ra_orientation']
    zrange=map_parameters['zrange']
    continuum=map_parameters['continuum']
    hash=map_parameters['hash']
#    id=0
    # COMPUTE IMAGE SIZE
    imsize=image_size(window,pixelsize)
    Nx=imsize[0]
    Ny=imsize[1]
    Nfreqs=freq_info[2]

    # DEFINE BEAM SIZE MARGIN FOR DETERMINING IF GALAXY MAY BE IN MAP (FACTOR 3 IS ARBITRARY, TO ENSURE WE DON'T LOSE ANYTHING)
    beam_margin=3.0*b[1]

    # COMPUTE X AND Y REFERENCE PIXELS
    i0=in_pixel(window[0],Xref,pixelsize)
    j0=in_pixel(window[2],Yref,pixelsize)
    val_i0=Xref+float(i0)*pixelsize
    val_j0=Yref+float(j0)*pixelsize

    # COMPUTE FREQUENCY AXIS
    obs_freqs=[]
    delta_freq=freq_info[1] # Channel width in GHz
    for i in range(Nfreqs): obs_freqs.append(freq_info[0]+float(i)*freq_info[1]) # Channel centers in GHz

    # ALLOCATE RESULT CUBE
    result=numpy.zeros((Nfreqs,Ny,Nx),dtype=data_type)

    # OPEN LIST OF GALAXIES
    fp=open(galaxy_file,"r")     
    
    # READ FIRST LINE - WHICH CONTAINS ATTRIBUTE NAMES IN THE ONLINE SAX-SKY QUERY RESULT FORMAT
    description_line=fp.readline()
    
    # GET NUMBER OF LINES
    numlines=int(os.popen('wc -l '+galaxy_file).read().split()[0])-1

    # INITIALIZE NUMBER COUNT
    igal=1

    # LOOP OVER GALAXIES
    for line in fp:
#        print igal,numlines
#        igal+=1
        galaxy_info=line.replace("\n","").split(",")

        # GET LINE-INDEPENDENT DATA
        galaxy_id=galaxy_info[structure.index(GALAXY)]
        ra=deg2arcsec(float(galaxy_info[structure.index(RA)]))
        dec=deg2arcsec(float(galaxy_info[structure.index(DEC)]))
        redshift=float(galaxy_info[structure.index(Z)])
        position_angle=float(galaxy_info[structure.index(PA)])
        inclination=float(galaxy_info[structure.index(INCLINATION)])
        distance=float(galaxy_info[structure.index(DISTANCE)])

        # GET TEMPLATE-TYPE DEPENDENT DATA
        if (hi=="Oxford"):rmolc=float(galaxy_info[structure.index(RMOLC)])
        if (hi=="Kapteyn"):hubble_type=float(galaxy_info[structure.index(HUBBLE_TYPE)])

        # HI MAPPING REQUESTED
        if (hi!=0): 

            # GET HI SPECIFIC DATA
            hi_axis_ratio=float(galaxy_info[structure.index(HI_AXIS_RATIO)])
            hi_major_axis_10max=float(galaxy_info[structure.index(HI_MAJOR_AXIS_10MAX)])
            hi_line_width_20=float(galaxy_info[structure.index(HI_LINEWIDTH20)])
            hi_line_width_50=float(galaxy_info[structure.index(HI_LINEWIDTH50)])
            hi_integrated_flux=float(galaxy_info[structure.index(HI_INTFLUX)])
#            print hi_integrated_flux
            # CHECK IF HI EMISSION HAS A CHANCE OF BEING INSIDE THE MAPPED VOLUME (FACTOR 3 BEFORE hi_line_width_20 IS ARBITRARY, TO ENSURE WE DON'T LOSE ANYTHING)
            if in_map(ra,dec,redshift,hi_major_axis_10max,3.0*hi_line_width_20,window,beam_margin,constant("nu0_HI"),freq_info):

                # CHECK IF HI INTEGRATED FLUX NON ZERO
                if (hi_integrated_flux>0.0):
                    id_hi=str(galaxy_id)+"_hi_"+hi                    
                    # RETRIEVE TEMPLATE HI CUBE AND PERFORM NECESSARY TRANSFORMS (SCALING, ROTATION, ...)
                    if (hi=="Oxford"):

                        # RETRIEVE ADEQUATE TEMPLATE CUBE FILE AND READ IT INTO ARRAY                        
                        hi_template_file_basename=get_DO_template_file(rmolc,inclination,"HI")
                        # FIND OUT IF FITS EXISTS
                        hi_template_file=SAX_TEMPLATES_DIR+"FITS/"+hi_template_file_basename+".fits" # Retrieve adequate template cube
                        #print hi_template_file
                        if(os.path.isfile(hi_template_file)): # YES
                            hdu_in=pyfits.open(hi_template_file)
                            hi_template_array0=(hdu_in[0]).data
                            # "CONVERSION" TO numpy.float64
                            hi_template_array=numpy.zeros(hi_template_array0.shape,dtype=numpy.float64)
                            hi_template_array[:][:][:]=hi_template_array0[:][:][:]
                            hdu_in.close()
                        else: # NO, THEN BUILD ONE, IT WILL BE FASTER FOR LATER JOBS
                            fits_file=hi_template_file
                            hi_template_file=SAX_TEMPLATES_DIR+"ascii/"+hi_template_file_basename # Retrieve adequate template cube
                            hi_template_array=DO_template2array(hi_template_file) # Read template cube file into array
                            os.popen("rm -f "+fits_file)
                            hdu=pyfits.PrimaryHDU(hi_template_array)
                            hdu.writeto(fits_file)

                        # RETRIEVE TEMPLATE PROFILE : NECESSARY FOR SCALING ACCORDING TO INTEGRATED EMISSION
                        profile_fp=open(SAX_TEMPLATES_DIR+"line_profiles/"+hi_template_file_basename,"r")
                        hi_template_profile=numpy.array([float(line.replace("\n","")) for line in profile_fp.readlines()])
                        profile_fp.close()

                        # READ TEMPLATE FILE'S LINE WIDTH : template_linewidth_50 GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE WIDTH ABOVE 50% OF THE PEAK
                        lwfp=open(SAX_TEMPLATES_DIR+"line_widths_HI.txt","r")
                        for lwline in lwfp:
                            lwsp=lwline.split()
                            if (lwsp[0]==hi_template_file_basename):
                                hi_template_linewidth_50=float(lwsp[1])
                                break
                        lwfp.close()
                        
                        # READ TEMPLATE FILE'S SPATIAL WIDTH : template_major_axis_10max GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE SPATIAL WIDTH AT 10% OF THE PEAK
                        swfp=open(SAX_TEMPLATES_DIR+"spatial_widths_HI.txt","r")
                        for swline in swfp:
                            swsp=swline.split()
                            if (swsp[0]==hi_template_file_basename):
                                hi_template_major_axis_10max=float(swsp[2])
                                break
                        swfp.close()

#                        hi_cube=DO_galaxy_cube(hi_template_array,hi_major_axis_10max,hi_line_width_20,hi_line_width_50,hi_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,constant("nu0_HI"),"HI",hi_template_linewidth_50,hi_template_major_axis_10max,hi_template_profile)
                        hi_cube=DO_galaxy_cube(hi_template_array,hi_major_axis_10max,hi_line_width_20,hi_line_width_50,hi_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,constant("nu0_HI"),"HI",hi_template_linewidth_50,hi_template_major_axis_10max,hi_template_profile,hash,id_hi)

                    if (hi=="Kapteyn"):
                        hi_cube=RB_galaxy_cube(hubble_type,hi_major_axis_10max,inclination,hi_line_width_20,hi_line_width_50,hi_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,constant("nu0_HI"),hash,id_hi)
#                        hi_cube=RB_galaxy_cube(hubble_type,hi_major_axis_10max,inclination,hi_line_width_20,hi_line_width_50,hi_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,constant("nu0_HI"))

                    # PASTE SINGLE SOURCE CUBE ONTO RESULT CUBE
                    if (hi_cube!=0):paste_single_cube_on_full_cube(hi_cube,result,Xref,Yref,pixelsize,i0,j0,Nx,Ny)

        # CO MAPPING IS REQUESTED
        if ((co_1_0!=0) or (co_2_1!=0) or (co_3_2!=0) or (co_4_3!=0) or (co_5_4!=0) or (co_6_5!=0) or (co_7_6!=0) or (co_8_7!=0) or (co_9_8!=0) or (co_10_9!=0)): 
            
            # GET RMOLC, IN CASE NO OXFORD HI REQUESTED
            rmolc=float(galaxy_info[structure.index(RMOLC)])

            # INITIALIZE TEMPLATE ARRAY EXISTENCE FLAG TO ZERO
            co_template_array_exists=0

            # GET CO SPECIFIC DATA
            h2_axis_ratio=float(galaxy_info[structure.index(H2_AXIS_RATIO)])
            h2_major_axis_10max=float(galaxy_info[structure.index(H2_MAJOR_AXIS_10MAX)])
            co_line_width_20=float(galaxy_info[structure.index(CO_LINEWIDTH20)])
            co_line_width_50=float(galaxy_info[structure.index(CO_LINEWIDTH50)])

            co_lines=[[co_1_0,constant("nu0_CO"),CO_1_0_INTFLUX,"CO_1_0"],
                      [co_2_1,2.0*constant("nu0_CO"),CO_2_1_INTFLUX,"CO_2_1"],
                      [co_3_2,3.0*constant("nu0_CO"),CO_3_2_INTFLUX,"CO_3_2"],
                      [co_4_3,4.0*constant("nu0_CO"),CO_4_3_INTFLUX,"CO_4_3"],
                      [co_5_4,5.0*constant("nu0_CO"),CO_5_4_INTFLUX,"CO_5_4"],
                      [co_6_5,6.0*constant("nu0_CO"),CO_6_5_INTFLUX,"CO_6_5"],
                      [co_7_6,7.0*constant("nu0_CO"),CO_7_6_INTFLUX,"CO_7_6"],
                      [co_8_7,8.0*constant("nu0_CO"),CO_8_7_INTFLUX,"CO_8_7"],
                      [co_9_8,9.0*constant("nu0_CO"),CO_9_8_INTFLUX,"CO_9_8"],
                      [co_10_9,10.0*constant("nu0_CO"),CO_10_9_INTFLUX,"CO_10_9"]]
            for co_line in co_lines:                
                # CO (J -> J-1) EMISSION LINE
                # CHECK IF CO EMISSION HAS A CHANCE OF BEING INSIDE THE MAPPED VOLUME (FACTOR 3 BEFORE co_line_width_20 IS ARBITRARY, TO ENSURE WE DON'T LOSE ANYTHING)
                if (co_line[0]!=0)and(in_map(ra,dec,redshift,h2_major_axis_10max,3.0*co_line_width_20,window,beam_margin,co_line[1],freq_info)):
                    id_co=str(galaxy_id)+"_hi_"+co_line[3]
                    # GET CO(J -> J-1) SPECIFIC DATA
                    co_line_integrated_flux=float(galaxy_info[structure.index(co_line[2])])
#                    print co_line_integrated_flux
                    # CHECK IF CO(J -> J-1) INTEGRATED FLUX NON ZERO
                    if (co_line_integrated_flux>0.0):
                    # RETRIEVE TEMPLATE CO CUBE AND PERFORM NECESSARY TRANSFORMS (SCALING, ROTATION, ...)
                        if(co_template_array_exists==0): # RETRIEVE TEMPLATE CO CUBE FROM FILE
                            co_template_file_basename=get_DO_template_file(rmolc,inclination,"CO")
                            co_template_file=SAX_TEMPLATES_DIR+"FITS/"+co_template_file_basename+".fits" # Retrieve adequate template cube
                            # FIND OUT IF FITS EXISTS
                            if(os.path.isfile(co_template_file)): # YES
                                co_template_array0=(pyfits.open(co_template_file)[0]).data
                                # "CONVERSION" TO numpy.float64
                                co_template_array=numpy.zeros(co_template_array0.shape,dtype=numpy.float64)
                                co_template_array[:][:][:]=co_template_array0[:][:][:]
                            else: # NO, THEN BUILD ONE, IT WILL BE FASTER FOR LATER JOBS
                                fits_file=co_template_file
                                co_template_file=SAX_TEMPLATES_DIR+"ascii/"+co_template_file_basename # Retrieve adequate template cube
                                co_template_array=DO_template2array(co_template_file) # Read template cube file into array    
                                os.popen("rm -f "+fits_file)
                                hdu=pyfits.PrimaryHDU(co_template_array)
                                hdu.writeto(fits_file)
                            # RETRIEVE TEMPLATE PROFILE : NECESSARY FOR SCALING ACCORDING TO INTEGRATED EMISSION
                            profile_fp=open(SAX_TEMPLATES_DIR+"line_profiles/"+co_template_file_basename,"r")                            
                            co_template_profile=numpy.array([float(line.replace("\n","")) for line in profile_fp.readlines()])
                            profile_fp.close()
                            # READ TEMPLATE FILE'S LINE WIDTH : template_linewidth_50 GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE WIDTH ABOVE 50% OF THE PEAK
                            lwfp=open(SAX_TEMPLATES_DIR+"line_widths_CO.txt","r")
                            for lwline in lwfp:
                                lwsp=lwline.split()
                                if (lwsp[0]==co_template_file_basename):
                                    co_template_linewidth_50=float(lwsp[1])
                                    break
                            lwfp.close()
                            # READ TEMPLATE FILE'S SPATIAL WIDTH : template_major_axis_10max GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE SPATIAL WIDTH AT 10% OF THE PEAK
                            swfp=open(SAX_TEMPLATES_DIR+"spatial_widths_CO.txt","r")
                            for swline in swfp:
                                swsp=swline.split()
                                if (swsp[0]==co_template_file_basename):
                                    co_template_major_axis_10max=float(swsp[2])
                                    break
                            swfp.close()
                            co_template_array_exists=1
#                        co_cube=DO_galaxy_cube(co_template_array,h2_major_axis_10max,co_line_width_20,co_line_width_50,co_line_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,co_line[1],"CO",co_template_linewidth_50,co_template_major_axis_10max,co_template_profile)
                        co_cube=DO_galaxy_cube(co_template_array,h2_major_axis_10max,co_line_width_20,co_line_width_50,co_line_integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,co_line[1],"CO",co_template_linewidth_50,co_template_major_axis_10max,co_template_profile,hash,id_co)

                    # PASTE SINGLE SOURCE CUBE ONTO RESULT CUBE
                        if (co_cube!=0):paste_single_cube_on_full_cube(co_cube,result,Xref,Yref,pixelsize,i0,j0,Nx,Ny)

    fp.close()

    # DEAL WITH R.A. AXIS ORIENTATION AND NOISE
    slice=numpy.zeros((Ny,Nx),dtype=data_type)
    for i_f in range(Nfreqs):
        slice[:][:]=result[i_f][:][:]
        if ra_orientation<0:
            slice=numpy.transpose(numpy.rot90(slice))
        if (noise > 0.0):
            sharp_n=numpy.random.standard_normal((Ny,Nx))
            sharp_n=sharp_n-numpy.mean(sharp_n)
            factor=(noise/numpy.std(sharp_n))*1e-9 # NOISE LEVEL IS SPECIFIED IN nJy
            sharp_n*=factor
            convolved_n=apply_beam(sharp_n,b)
            cy=convolved_n.shape[0]/2
            cx=convolved_n.shape[1]/2
            n=convolved_n[cy-Ny/2:cy-Ny/2+Ny,cx-Nx/2:cx-Nx/2+Nx]
            slice+=n
        result[i_f][:][:]=slice[:][:]


    return(result)

def SAX_header_info(map_parameters):
    # GET MAP PARAMETERS
    window=map_parameters['window']
    offset=map_parameters['offset']
    pixelsize=map_parameters['pixelsize']
    freq_info=map_parameters['freq_info']
    third_axis_unit=map_parameters['third_axis_unit']
    noise=map_parameters['noise']
    ra_orientation=map_parameters['ra_orientation']
    zrange=map_parameters['zrange']
    userefpos=map_parameters['userefpos']
    zmin=numpy.min(numpy.array(zrange))
    zmax=numpy.max(numpy.array(zrange))
    Nx=in_pixel(window[1],Xref,pixelsize)-in_pixel(window[0],Xref,pixelsize)
    Ny=in_pixel(window[3],Yref,pixelsize)-in_pixel(window[2],Yref,pixelsize)

    # BUILD REFERENCES AND UNITS
    ctype=['RA---TAN','DEC--TAN']    
    cunit=['DEGREE  ','DEGREE  ']

    if (userefpos==0):
        crval=[arcsec2deg(Xref+pixelsize*float(in_pixel(window[0],Xref,pixelsize))),arcsec2deg(Xref+pixelsize*float(in_pixel(window[2],Xref,pixelsize)))]
        if ra_orientation>0:
            crpix=[1,1]
            cdelt=[arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
        else:        
            crpix=[Nx,1]
            cdelt=[-arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
    else:
        if(Nx%2): # ODD
            crvalx=offset[0]
            crpixx=Nx/2+1
        else: # EVEN
            crvalx=offset[0]-ra_orientation*arcsec2deg(pixelsize/2.0)
            crpixx=Nx/2
        if(Ny%2): #ODD
            crvaly=offset[1]
            crpixy=Ny/2+1
        else: # EVEN
            crvaly=offset[1]-arcsec2deg(pixelsize/2.0)
            crpixy=Ny/2
        crval=[crvalx,crvaly]
        crpix=[crpixx,crpixy]

        if ra_orientation>0:
            cdelt=[arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
        else:        
            cdelt=[-arcsec2deg(pixelsize),arcsec2deg(pixelsize)]
    if (third_axis_unit=='FREQ'):
        crval.append(freq_info[0]*1e9)
        crpix.append(1)
        ctype.append('FREQ    ')
        cunit.append('HZ      ')
        cdelt.append(freq_info[1]*1e9)
    # WARNING : USE VELOCITY AXIS ONLY IF A SINGLE LINE IS PLOTTED - NEEDS FIXING !
    if (third_axis_unit=='VELO'):
        crval.append(freq2velo(freq_info[0]*1e3,constant("nu0_CO")))
        crpix.append(1)
        ctype.append('VELO    ')
        cunit.append('KM/S    ')
        cdelt.append(-constant("c")*freq_info[1]*1e3/constant("nu0_CO"))
    return([crval,crpix,cdelt,ctype,cunit])

#############################################
### HIGH-RESOLUTION HI FROM RENSE BOOMSMA ###
#############################################

def hubble2galaxy(hubble_type):
    if (hubble_type<=2.5): return("S0-Sab")
    if ((hubble_type>2.5) and (hubble_type<=4.5)): return("Sb-Sbc")
    if ((hubble_type>4.5) and (hubble_type<=6.5)): return("Sc-Scd")
    if ((hubble_type>6.5) and (hubble_type<=7.5)): return("Sd")
    if ((hubble_type>7.5)): return("Sdm")

def closest_markup(value,markups):
    diagnostic=numpy.zeros((len(markups)),dtype=float)
    for i in range(len(markups)): diagnostic[i]=math.fabs(markups[i]-value)
    return(markups[numpy.where(diagnostic==numpy.min(diagnostic))[0][0]])

def hi_profile(template_cube):
    Nx=template_cube.header['NAXIS1']
    Ny=template_cube.header['NAXIS2']
    Nz=template_cube.header['NAXIS3']
    Dv=template_cube.header['CDELT3']
    data=template_cube.data.astype("Float32")
    f=10000 # A factor for building a smooth profile using interpolating splines
    new_Nz=(f*Nz)+1
    slice=numpy.zeros((Ny,Nx),dtype=data_type)
    v=numpy.zeros((Nz),dtype=data_type)
    profile=numpy.zeros((Nz),dtype=data_type)
    for i in range(Nz):
        v[i]=Dv*(float(i)-float(Nz/2))
        slice[:][:]=data[i][:][:]
        profile[i]=total(slice)
    tck=scipy.interpolate.splrep(v,profile)
    new_v=(numpy.max(v)-numpy.min(v))*(grid(new_Nz)/float(new_Nz-1))+numpy.min(v)
    new_p=scipy.interpolate.splev(new_v,tck,der=0)
    return(new_v,new_p)

def hi_line_width(hi_profile,cutoff):   
    v=hi_profile[0]
    p=hi_profile[1]
    Nz=len(v)    
    above=numpy.where(p>cutoff*numpy.max(p))[0]
    return(v[above[len(above)-1]]-v[above[0]])

def make_all_widths(cutoff):
    hi_widths_file=hi_template_directory+"hi_widths_"+str(cutoff)+".txt"
    files=os.popen("ls "+hi_template_directory+hi_template_prefix+"*.fits").readlines()
    os.popen("rm -f "+hi_widths_file)
    lines=[]
    for file in files:
        name=file.split("/")[len(file.split("/"))-1].replace("\n","")
        hdulist=pyfits.open(file)
        hi_cube=hdulist[0]
        profile=hi_profile(hi_cube)
        lw=hi_line_width(profile,cutoff)
        line=name+"\t"+str(lw)
        lines.append(line+"\n")
    fp=open(hi_widths_file,"w")
    fp.writelines(lines)  
    fp.close()

def read_widths_file(widths_file):
    fp=open(widths_file,"r")
    names=[]
    widths=[]
    for line in fp:
        sp=line.split()
        names.append(sp[0])
        widths.append(float(sp[1].replace("\n","")))
    return(names,widths)


def get_RB_template_file(hubble_type,major_axis,inclination,hi_linewidth,pixelsize):
    galaxy_types=["S0-Sab","Sb-Sbc","Sc-Scd","Sd","Sdm"]
    velocity_markups=[
        [100.,150.,200.,250.,300.],
        [100.,150.,200.,250.,300.],
        [100.,150.,200.,250.,300.],
        [100.,150.,200.,250.,300.],
        [50.,75.,100.,125.]]
    galaxy_type=hubble2galaxy(hubble_type)
    galaxy_type_index=galaxy_types.index(galaxy_type)
    inclination_markup=closest_markup(rad2deg(inclination),inclination_markups)
    nw=read_widths_file(KAPTEYN_TEMPLATES_DIR+"hi_widths_0.5.txt")
    widths=[]
    files=[]
    for v in velocity_markups[galaxy_type_index]:
        file="template_"+galaxy_type+"_"+str(int(v))+"_"+str(inclination_markup)+".fits"
        index=numpy.where(numpy.array(nw[0])==file)[0][0]
        files.append(nw[0][index])
        widths.append(nw[1][index])
    template=files[widths.index(closest_markup(hi_linewidth,widths))]
    hi_template_redshift=0.0045 # HI template cubes assumed redshift
    hi_template_diameters=[22.0,22.0,22.0,22.0,16.0] # HI template cubes assumed diameter, in kpc
    hi_template_pixelsize=0.3563333333 # template pixel size, in kpc
    return(template)


def get_DO_template_file(rmolc,inclination,hi_or_co):
    rmolc_markup=closest_markup(10*rmolc,rmolc_markups) #rmolc_markups go from 0 to 89 (10 times actual, integers)
    if (rmolc_markup<10):rmolc_markup_str="0."+str(rmolc_markup)
    else:rmolc_markup_str=str(rmolc_markup)[0]+"."+str(rmolc_markup)[1]
    inclination_markup=closest_markup(rad2deg(inclination),inclination_markups)
    if (inclination_markup<10):str_inclination_markup="0"+str(inclination_markup)
    else:str_inclination_markup=str(inclination_markup)
    template="template_"+hi_or_co+"_"+str_inclination_markup+"_"+rmolc_markup_str
    return(template)


def DO_template2array(template_file):
    Nx=151
    Ny=151
    Nv=101
    array=numpy.zeros((Nv,Ny,Nx),dtype=numpy.float64)
    fp=open(template_file,"r")
    while 1:
        line=fp.readline().replace("\n","")        
        if (line==""):break
        sp=line.split()
        ix=int(sp[0])+Nx/2
        iy=int(sp[1])+Ny/2
        iv=int(sp[2])+Nv/2
        array[iv][iy][ix]=float(sp[3])
    return(array)

def DO_line_profile(PPV_array):
    result=numpy.zeros((PPV_array.shape[0]),dtype=float)
    slice=numpy.zeros((PPV_array.shape[2],PPV_array.shape[1]),dtype=float)
    for i in range(PPV_array.shape[0]):
        slice[:][:]=PPV_array[i][:][:]
        result[i]=slice.sum()
    return(result)

def DO_major_axis_profile(PPV_array):
    result=numpy.zeros((PPV_array.shape[2]),dtype=float)
    coldens=numpy.zeros((PPV_array.shape[2],PPV_array.shape[1]),dtype=float)
    for i in range(PPV_array.shape[0]):
        coldens[:][:]+=PPV_array[i][:][:]
    Nx=151
    Ny=151
    for i in range(PPV_array.shape[2]):
        result[i]=coldens[Ny/2][i]
    return(result)


def DO_galaxy_cube(array,major_axis_10max,line_width_20,line_width_50,integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,nu0,line_identifier,template_linewidth_50,template_major_axis_10max,template_profile,hash,id):
    # EXTRACT TEMPLATE CUBE DIMENSIONS
    Nx=array.shape[len(array.shape)-1]
    Ny=array.shape[len(array.shape)-2]
    Nfreqs=array.shape[len(array.shape)-3]
    # READ FREQUENCY WINDOW REQUESTED
    freq0=freq_info[0] # Central frequency of the first pixel (GHz)
    dfreq=freq_info[1] # Frequency width per channel (GHz)
    Nchans=freq_info[2] # Number of channels
    # DETERMINE FULL FREQUENCY AND VELOCITY WINDOW REQUESTED ---- WARNING : VELOCITIES ARE REVERSED WITH RESPECT TO FREQUENCIES. IN THIS CASE, WE EVENTUALLY NEED TO RE-INVERT THE THIRD AXIS
    wf_vals=(grid(Nchans)*dfreq*1000.0)+freq0*1000.0 # Central frequencies of the channels (MHz)
    wfmin=wf_vals[0]-dfreq*500.0 # Minimum frequency in the lowest-frequency channel (MHz)
    wfmax=wf_vals[Nchans-1]+dfreq*500.0 # Maximum frequency in the highest-frequency channel (MHz)
    wvmin=freq2velo(wfmax,nu0) # Minimum line-of-sight velocity in the requested range (km/s)
    wvmax=freq2velo(wfmin,nu0) # Maximum line-of-sight velocity in the requested range (km/s)
    cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
    cbv=channel_boundary_velocities(cbf,nu0)[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax.
    wv_vals=[0.5*(cbv[i+1]+cbv[i]) for i in range(Nchans)] # Line-of-sight velocities at the channels' centers (km/s)
    # FREQUENCY WINDOW WITH POSSIBLY NONZERO SIGNAL FROM THE GALAXY
    f0=redshift2freq(redshift,nu0) # Central frequency of the galaxy's signal (MHz)
    v0=freq2velo(f0,nu0) # Central line-of-sight velocity of the galaxy's signal (km/s)
#    vmin=v0-line_width_20 # "Minimum" velocity of the galaxy (km/s) - BUGGED !
#    vmax=v0+line_width_20 # "Maximum" velocity of the galaxy (km/s) - BUGGED !
#    print "BUGGED",vmin,vmax
    vmin=relativistic_composition(v0,-line_width_20) # "Minimum" velocity of the galaxy (km/s) - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
    vmax=relativistic_composition(v0,line_width_20) # "Maximum" velocity of the galaxy (km/s) - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
#    print "CORRECTED",vmin,vmax
    # CHECK COMPATIBILITY
    if ((vmin>wvmax)or(vmax<wvmin)): # VELOCITY RANGE CONSIDERED HAS ZERO SIGNAL
        return(0)
    else:
        # DETERMINE FREQUENCY/VELOCITY SCALING AND SHIFT
        dv=line_width_50/template_linewidth_50 # Third-axis size of a pixel in the template (km/s)
#        print line_width_50,template_linewidth_50,dv
#        v_vals=dv*(grid(Nfreqs)-Nfreqs/2)+v0 # Line-of-sight velocities at the center of each pixel in the template (km/s)  - BUGGED !
#        print "BUGGED",v_vals
        v_vals=relativistic_composition(v0,dv*(grid(Nfreqs)-Nfreqs/2)) # Line-of-sight velocities at the center of each pixel in the template (km/s)  - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
#        print "CORRECTED",v_vals
        # DETERMINE SPATIAL SCALING AND SHIFT
        spatial_ratio=(template_major_axis_10max)/(major_axis_10max/pixelsize) # Ratio between the desired spatial pixel size and the template spatial pixel size. This is used to stretch or squeeze.
        template_pixelsize=pixelsize/spatial_ratio

        i_val=Xref+float(in_pixel(ra,Xref,template_pixelsize))*template_pixelsize # R.A. of the center of the template pixel in which the galaxy falls
        j_val=Yref+float(in_pixel(dec,Yref,template_pixelsize))*template_pixelsize # Declination of the center of the template pixel in which the galaxy falls
        dx=(ra-i_val)/template_pixelsize # Shift in X between the galaxy's center point and the center of the central pixel in the template cube (pixels)
        dy=(dec-j_val)/template_pixelsize # Shift in Y between the galaxy's center point and the center of the central pixel in the template cube (pixels)
#        print ra
        ra_vals=template_pixelsize*(numpy.arange(Nx)-float(Nx/2))+ra # Values of the R.A. at the center of each pixel in the template (arcsec)
        dec_vals=template_pixelsize*(numpy.arange(Ny)-float(Ny/2))+dec # Values of the declination at the center of each pixel in the template (arcsec)

        # CONVERT POSITION ANGLE TO DEGREES (MAJOR AXIS ALONG X) 
        angle=rad2deg(position_angle)-90.0
        # APPLY SO-DEFINED GEOMETRIC TRANSFORMS + REVERT THIRD AXIS TO GO BACK TO FREQUENCY SPACE
#        result=revert_frequency_axis_in_template(apply_cube_transform(array,spatial_ratio,angle,v_vals,cbv,ra_vals,dec_vals,pixelsize,template_pixelsize))
        result=revert_frequency_axis_in_template(apply_cube_transform(array,spatial_ratio,angle,v_vals,cbv,ra_vals,dec_vals,pixelsize,template_pixelsize,hash,id))
#        print result.shape
        # APPLY SPATIAL BEAM
        result=apply_beam(result,b)
        # NORMALIZE FOR LINE FLUX
#        intensity_scaling=integrated_flux/(dv*(template_profile.sum())) - BUGGED !
        # THIS IS CORRECTED ON 06/03/2012 AND 07/03/2012
        template_boundary_velocities=relativistic_composition(v0,dv*(grid(Nfreqs+1)-Nfreqs/2.)) # Line-of-sight velocities at the boundaries of each pixel in the template (km/s)  - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
        intflux_template=0.0
        for i_f in range(Nfreqs):
            if (template_profile[i_f]>0.0):intflux_template+=(template_profile[i_f]*(template_boundary_velocities[Nfreqs-i_f]-template_boundary_velocities[Nfreqs-i_f-1]))
        intensity_scaling=integrated_flux/intflux_template
        result*=intensity_scaling

#        # DETERMINE WHETHER LINE IS RESOLVED OR NOT
#        print result.shape
#        i_chan_of_max=numpy.where(result==numpy.max(result))[0][0]
#        print numpy.max(result[i_chan_of_max-1,:,:]),numpy.max(result)
        # INCLUDE REFERENCE PIXELS FOR PASTING ONTO MASTER CUBE
        i0=in_pixel(ra,Xref,pixelsize)
        j0=in_pixel(dec,Yref,pixelsize)
#        crpix=[i0-1,j0+1,Nchans/2]
        crpix=[i0,j0,Nchans/2]
        return(result,crpix)

def RB_galaxy_cube(hubble_type,major_axis_10max,inclination,line_width_20,line_width_50,integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,nu0,hash,id):
#def RB_galaxy_cube(hubble_type,major_axis_10max,inclination,line_width_20,line_width_50,integrated_flux,ra,dec,redshift,b,position_angle,pixelsize,freq_info,nu0):
    # RETRIEVE ADEQUATE TEMPLATE CUBE FILE AND READ IT INTO ARRAY
    tmp=get_RB_template_file(hubble_type,major_axis_10max,inclination,line_width_50,pixelsize)
    file=KAPTEYN_TEMPLATES_DIR+tmp
    hdu_in=read_file(file)
    array=hdu_in.data.astype(numpy.float64)
    # EXTRACT TEMPLATE CUBE DIMENSIONS
    Nx=hdu_in.header['NAXIS1']
    Ny=hdu_in.header['NAXIS2']
    Nfreqs=hdu_in.header['NAXIS3']
    # BUILD PROFILE
    template_profile=numpy.zeros((Nfreqs),dtype=numpy.float64)
    for i_f in range(Nfreqs):template_profile[i_f]=(array[i_f,:,:]).sum()
    # READ FREQUENCY WINDOW REQUESTED
    freq0=freq_info[0] # Central frequency of the first pixel (GHz)
    dfreq=freq_info[1] # Frequency width per channel (GHz)
    Nchans=freq_info[2] # Number of channels
    # DETERMINE FULL FREQUENCY AND VELOCITY WINDOW REQUESTED ---- WARNING : VELOCITIES ARE REVERSED WITH RESPECT TO FREQUENCIES. IN THIS CASE, WE EVENTUALLY NEED TO RE-INVERT THE THIRD AXIS
    wf_vals=(grid(Nchans)*dfreq*1000.0)+freq0*1000.0 # Central frequencies of the channels (MHz)
    wfmin=wf_vals[0]-dfreq*500.0 # Minimum frequency in the lowest-frequency channel (MHz)
    wfmax=wf_vals[Nchans-1]+dfreq*500.0 # Maximum frequency in the highest-frequency channel (MHz)
    wvmin=freq2velo(wfmax,nu0) # Minimum line-of-sight velocity in the requested range (km/s)
    wvmax=freq2velo(wfmin,nu0) # Maximum line-of-sight velocity in the requested range (km/s)
    cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
    cbv=channel_boundary_velocities(cbf,nu0)[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax.
    wv_vals=[0.5*(cbv[i+1]+cbv[i]) for i in range(Nchans)] # Line-of-sight velocities at the channels' centers (km/s)
    # FREQUENCY WINDOW WITH POSSIBLY NONZERO SIGNAL FROM THE GALAXY
    f0=redshift2freq(redshift,nu0) # Central frequency of the galaxy's signal (MHz)
    v0=freq2velo(f0,nu0) # Central line-of-sight velocity of the galaxy's signal (km/s)
#    vmin=v0-line_width_20 # "Minimum" velocity of the galaxy (km/s) - BUGGED !
#    vmax=v0+line_width_20 # "Maximum" velocity of the galaxy (km/s) - BUGGED !
#    print "BUGGED",vmin,vmax
    vmin=relativistic_composition(v0,-line_width_20) # "Minimum" velocity of the galaxy (km/s) - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
    vmax=relativistic_composition(v0,line_width_20) # "Maximum" velocity of the galaxy (km/s) - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
#    print "CORRECTED",vmin,vmax
    # CHECK COMPATIBILITY
    if ((vmin>wvmax)or(vmax<wvmin)): # VELOCITY RANGE CONSIDERED HAS ZERO SIGNAL
        return(0)
    else:
        # DETERMINE FREQUENCY/VELOCITY SCALING AND SHIFT
        # READ TEMPLATE FILE'S LINE WIDTH : template_line_width_50 GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE WIDTH ABOVE 50% OF THE PEAK
        lwfp=open(KAPTEYN_TEMPLATES_DIR+"hi_widths_0.5.txt","r")
        template_channel_width=5.0 # WIDTH OF A SINGLE CHANNEL IN A TEMPLATE CUBE, IN KM/S
        for lwline in lwfp:
            lwsp=lwline.split()
            if (lwsp[0]==tmp):
                template_line_width_50=float(lwsp[1])/template_channel_width
                break
        dv=line_width_50/template_line_width_50 
#        print line_width_50,template_linewidth_50,dv
#        v_vals=dv*(grid(Nfreqs)-Nfreqs/2)+v0 # Line-of-sight velocities at the center of each pixel in the template (km/s)  - BUGGED !
#        print "BUGGED",v_vals
        v_vals=relativistic_composition(v0,dv*(grid(Nfreqs)-Nfreqs/2)) # Line-of-sight velocities at the center of each pixel in the template (km/s)  - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
#        print "CORRECTED",v_vals
        # DETERMINE SPATIAL SCALING AND SHIFT
        # READ TEMPLATE FILE'S SPATIAL WIDTH : template_major_axis_10max GIVES THE NON-INTEGER NUMBER OF PIXELS CORRESPONDING TO THE SPATIAL WIDTH AT 10% OF THE PEAK
        swfp=open(KAPTEYN_TEMPLATES_DIR+"spatial_widths.txt","r")
        for swline in swfp:
            swsp=swline.split()
            if (swsp[0]==tmp):template_major_axis_10max=float(swsp[1])
        spatial_ratio=(template_major_axis_10max)/(major_axis_10max/pixelsize) # Ratio between the desired spatial pixel size and the template spatial pixel size. This is used to stretch or squeeze.
        template_pixelsize=pixelsize/spatial_ratio
        i_val=Xref+float(in_pixel(ra,Xref,template_pixelsize))*template_pixelsize
        j_val=Yref+float(in_pixel(dec,Yref,template_pixelsize))*template_pixelsize
        dx=(ra-i_val)/template_pixelsize # Shift in X between the galaxy's center point and the center of the central pixel in the template cube (pixels)
        dy=(dec-j_val)/template_pixelsize # Shift in Y between the galaxy's center point and the center of the central pixel in the template cube (pixels)
        ra_vals=template_pixelsize*(numpy.arange(Nx)-float(Nx/2))+ra # Values of the R.A. at the center of each pixel in the template (arcsec)
        dec_vals=template_pixelsize*(numpy.arange(Ny)-float(Ny/2))+dec # Values of the declination at the center of each pixel in the template (arcsec)

        # CONVERT POSITION ANGLE TO DEGREES (MAJOR AXIS ALONG Y) 
        angle=rad2deg(position_angle)
        # APPLY SO-DEFINED GEOMETRIC TRANSFORMS + REVERT THIRD AXIS TO GO BACK TO FREQUENCY SPACE
#        result=revert_frequency_axis_in_template(apply_cube_transform(array,spatial_ratio,angle,v_vals,cbv,ra_vals,dec_vals,pixelsize,template_pixelsize))
        result=revert_frequency_axis_in_template(apply_cube_transform(array,spatial_ratio,angle,v_vals,cbv,ra_vals,dec_vals,pixelsize,template_pixelsize,hash,id))

        # APPLY SPATIAL BEAM
        result=apply_beam(result,b)
        # NORMALIZE FOR LINE FLUX
#        intensity_scaling=integrated_flux/(dv*(template_profile.sum())) - BUGGED !
        # THIS IS CORRECTED ON 06/03/2012 AND 07/03/2012
        template_boundary_velocities=relativistic_composition(v0,dv*(grid(Nfreqs+1)-Nfreqs/2.)) # Line-of-sight velocities at the boundaries of each pixel in the template (km/s)  - CORRECTED FOR RELATIVISTIC COMPOSITION 03.2012
        intflux_template=0.0
        for i_f in range(Nfreqs):
            if (template_profile[i_f]>0.0):intflux_template+=(template_profile[i_f]*(template_boundary_velocities[Nfreqs-i_f]-template_boundary_velocities[Nfreqs-i_f-1]))
        intensity_scaling=integrated_flux/intflux_template
        result*=intensity_scaling
        # INCLUDE REFERENCE PIXELS FOR PASTING ONTO MASTER CUBE
        i0=in_pixel(ra,Xref,pixelsize)
        j0=in_pixel(dec,Yref,pixelsize)
#        crpix=[i0-1,j0+1,Nchans/2]
        crpix=[i0,j0,Nchans/2]
        return(result,crpix)

def make_SAX_information_line(ra,dec,majaxis,minaxis,pa,I_HI,redshift,distance,HI_linewidth,val_i0,val_j0,pixelsize,ra_orientation,Nx,Ny):
    if (ra_orientation<0):
        if (Nx-((ra-val_i0)/pixelsize)>=0.0):            
            catalog_line=str(Nx-((ra-val_i0)/pixelsize))+' '
            catalog_line+=str((dec-val_j0)/pixelsize+1.)+' '
            catalog_line+=(str(majaxis)+' ')
            catalog_line+=(str(minaxis)+' ')
            catalog_line+=(str(rad2deg(pa))+' ')
            catalog_line+=(str(I_HI)+' ')
            catalog_line+=(str(redshift)+' ')
            catalog_line+=(str(distance)+' ')
            catalog_line+=(str(HI_linewidth)+' ')
            catalog_line+="\n"
            print catalog_line



#        i_val_out=Xref+float(in_pixel(ra,Xref,pixelsize))*pixelsize # R.A. of the center of the output map pixel in which the galaxy falls
#        j_val_out=Yref+float(in_pixel(dec,Yref,pixelsize))*pixelsize # Declination of the center of the output map pixel in which the galaxy falls
#        dx_out=(ra-i_val_out)/pixelsize # Shift in X between the galaxy's center point and the center of the central pixel in the output cube (pixels)
#        dy_out=(dec-j_val_out)/pixelsize # Shift in Y between the galaxy's center point and the center of the central pixel in the output cube (pixels)
#        condition_x1=(abs(ra+major_axis_10max*abs(math.sin(position_angle))-i_val_out)<(pixelsize/2.0))
#        condition_x2=(abs(ra-major_axis_10max*abs(math.sin(position_angle))-i_val_out)<(pixelsize/2.0))
#        condition_y1=(abs(dec+major_axis_10max*abs(math.cos(position_angle))-j_val_out)<(pixelsize/2.0))
#        condition_y2=(abs(dec-major_axis_10max*abs(math.cos(position_angle))-j_val_out)<(pixelsize/2.0))
#        apply_rotate_and_shift=not((condition_x1)and(condition_x2)and(condition_y1)and(condition_y2))
#        condition_x1=(abs(ra+major_axis_10max-i_val_out)<(pixelsize/2.0))
#        condition_x2=(abs(ra-major_axis_10max-i_val_out)<(pixelsize/2.0))
#        condition_y1=(abs(dec+major_axis_10max-j_val_out)<(pixelsize/2.0))
#        condition_y2=(abs(dec-major_axis_10max-j_val_out)<(pixelsize/2.0))
#        print "-----------------------"
#        print "X ",ra,i_val_out,major_axis_10max,pixelsize,condition_x1,condition_x2
#        print "Y ",dec,j_val_out,major_axis_10max,pixelsize,condition_y1,condition_y2



#    cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
#    cbv=channel_boundary_velocities(cbf,constant("nu0_HI"))[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax. 
#    cbv=channel_boundary_velocities(cbf,3.0*constant("nu0_CO"))[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax. 
#    intflux=0.0
#    for i_f in range(Nfreqs):
#        intflux+=(cbv[Nfreqs-i_f]-cbv[Nfreqs-i_f-1])*((result[i_f,:,:]).sum())
#    print result[:,46,45]
#    print "intflux",intflux,hi_integrated_flux
#    print numpy.min(result),numpy.max(result)

#    print result.sum()

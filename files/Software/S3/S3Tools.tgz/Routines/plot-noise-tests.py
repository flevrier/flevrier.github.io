import os
import pyfits
import matplotlib
import matplotlib.pyplot
import matplotlib.mpl
import numpy
import math
from common_routines import constant,deg2arcmin,rad2deg
from common_map_routines import channel_boundary_frequencies,channel_boundary_velocities
from matplotlib.patches import Ellipse


TEST_DIR="../Tests/"

def fig_spatial_extent(file,figname):
#    print file
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
    Nx=hdr['NAXIS1']
    Ny=hdr['NAXIS2']
    Nfreqs=hdr['NAXIS3']
    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
    x=deg2arcmin(float(hdr['CDELT1']))*(numpy.arange(float(Nx))-float(hdr['CRPIX1'])+1)#+deg2arcsec(float(hdr['CRVAL1']))
    y=deg2arcmin(float(hdr['CDELT2']))*(numpy.arange(float(Ny))-float(hdr['CRPIX2'])+1)#+deg2arcsec(float(hdr['CRVAL2']))
    extent=[max(x),min(x),min(y),max(y)]
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern_r')
    # MAKE IMAGE
    ax1.imshow(data[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])

    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
#    ax1.xaxis.set_major_locator(majorLocator)
    #ax1.yaxis.set_major_locator(majorLocator)
    ax1.set_xlabel(r"$\alpha$ [']",fontsize=20)
    ax1.set_ylabel(r"$\delta$ [']",fontsize=20)

    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

def plot_histogram(file,noise_level,figname,overlay):
# INITIALIZE FIGURE
    fig=matplotlib.pyplot.figure()
    ax=fig.add_subplot(111)
    ax.set_xlabel('Pixel value'+' [Jy]',fontsize=16)
    ax.set_ylabel('Probability Distribution Function',fontsize=16)
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
#    print data.shape
    data_1D=[]
    for i in range(hdr['NAXIS1']):
        for j in range(hdr['NAXIS2']):
            data_1D.append(data[0,j,i])
#    numpy.reshape(data,720*720)
    pdf,bins,patches=matplotlib.pyplot.hist(data_1D,bins=50,normed=True,histtype='step')
    if (overlay):
        y = matplotlib.mlab.normpdf( bins, 0.0, noise_level/1e9)
        l = matplotlib.pyplot.plot(bins, y, 'r-', linewidth=1)

#    print len(pdf)
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

extension=".png"
#extension=".eps"
fig_spatial_extent("map-noise.fits",TEST_DIR+"noise-10nJy"+extension)
fig_spatial_extent("map-noise-smeared.fits",TEST_DIR+"noise-10nJy-smeared"+extension)
plot_histogram("map-noise.fits",10.0,TEST_DIR+"histo-noise-10nJy"+extension,True)
plot_histogram("map-noise-smeared.fits",10.0,TEST_DIR+"histo-noise-10nJy-smeared"+extension,False)

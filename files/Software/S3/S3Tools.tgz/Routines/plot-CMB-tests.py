import os
import pyfits
import matplotlib
import matplotlib.pyplot
import matplotlib.mpl
import numpy
from common_routines import constant,deg2arcsec,rad2deg
from common_map_routines import channel_boundary_frequencies,channel_boundary_velocities
from CMB_routines import CMB
from matplotlib.patches import Ellipse

TEST_DIR="../Tests/"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

def print_integrated_flux(file_hi_co_cmb,file_cmb,expected_integrated_flux,channel_span,nu0,x,y,line):
    data_hi_co_cmb=(pyfits.open(TEST_DIR+file_hi_co_cmb)[0]).data    
    data_cmb=(pyfits.open(TEST_DIR+file_cmb)[0]).data    
    hdr=(pyfits.open(TEST_DIR+file_cmb)[0]).header
    Nfreqs=hdr['NAXIS3']
    freq_info=[hdr['CRVAL3']/1e9,hdr['CDELT3']/1e9,Nfreqs]
    cbf=channel_boundary_frequencies(freq_info) # Frequencies at the channels' boundaries (GHz). Nchans+1 values : First value is wfmin/1000.0 and last value is wfmax/1000.0
    cbv=channel_boundary_velocities(cbf,nu0)[::-1] # Line-of-sight velocities at the channels' boundaries (km/s). Nchans+1 values : First value is wvmin and last value is wvmax.
    intflux=0.0
    for i_f in channel_span:
        intflux+=(cbv[Nfreqs-i_f]-cbv[Nfreqs-i_f-1])*(data_hi_co_cmb[i_f,y,x]-data_cmb[i_f,y,x])
    print " * "+line+" ----> "+str(intflux)+" Jy.km/s when expected integrated flux is "+str(expected_integrated_flux)+" Jy.km/s"

def plot_CMB_spectrum(file_cmb,figname):
    data_cmb=(pyfits.open(TEST_DIR+file_cmb)[0]).data    
    hdr=(pyfits.open(TEST_DIR+file_cmb)[0]).header
    if (hdr['CUNIT1']=='DEGREE'):dx=abs(deg2arcsec(hdr['CDELT1']))
    if (hdr['CUNIT2']=='DEGREE'):dy=abs(deg2arcsec(hdr['CDELT2']))
    pixel_area=dx*dy*2.3504e-11 # IN STERADIAN
    Nfreqs=hdr['NAXIS3']
    freq_axis=(numpy.arange(Nfreqs)-hdr['CRPIX3']+1)*(hdr['CDELT3']/1e9)+(hdr['CRVAL3']/1e9) # in GHz
    spectrum=numpy.zeros((Nfreqs),dtype=numpy.float64)
    for i_f in range(Nfreqs):spectrum[i_f]=data_cmb[i_f,0,0]/pixel_area

    fig=matplotlib.pyplot.figure()
    ax=fig.add_subplot(111)
    ax.set_xlabel(r'$\nu$'+' [GHz]')
    ax.set_ylabel('Flux density [Jy/sr]')
    ax.plot(freq_axis,spectrum,'bo',freq_axis,CMB(freq_axis*1e3),'r-')
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

print_integrated_flux("hi-co-cmb.fits","cmb.fits",HI,range(0,4),constant("nu0_HI"),1,2,"HI      ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_1,range(100,112),constant("nu0_CO"),1,2,"CO(1-0) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_2,range(200,224),2.0*constant("nu0_CO"),1,2,"CO(2-1) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_3,range(300,336),3.0*constant("nu0_CO"),1,2,"CO(3-2) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_4,range(400,448),4.0*constant("nu0_CO"),1,2,"CO(4-3) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_5,range(500,560),5.0*constant("nu0_CO"),1,2,"CO(5-4) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_6,range(600,672),6.0*constant("nu0_CO"),1,2,"CO(6-5) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_7,range(700,784),7.0*constant("nu0_CO"),1,2,"CO(7-6) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_8,range(800,896),8.0*constant("nu0_CO"),1,2,"CO(8-7) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_9,range(900,1008),9.0*constant("nu0_CO"),1,2,"CO(9-8) ")
print_integrated_flux("hi-co-cmb.fits","cmb.fits",CO_10,range(1000,1120),10.0*constant("nu0_CO"),1,2,"CO(10-9)")

#extension=".eps"
extension=".png"
plot_CMB_spectrum("cmb.fits",TEST_DIR+"cmb_spectrum"+extension)

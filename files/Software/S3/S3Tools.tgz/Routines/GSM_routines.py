import math
import numpy
import pyfits
import os
import scipy
import scipy.signal
import scipy.interpolate
import scipy.special
import types
from common_routines import *
import sys
sys.path.append("../Config/")
from Config_Map import *
from Config_Path import *
import time
#from ipol import *
#import Image
import scipy.ndimage


###################################
#### GLOBAL SKY MODEL ROUTINES ####
###################################

def make_pixel_positions_file(Nx,Ny,outfile):
    os.popen("rm -f "+outfile)
    file=open(outfile,"w")
#    print outfile
    lines=[]
    for i in range(Nx):
        for j in range(Ny):
            lines.append(str(i)+" "+str(j)+"\n")
    file.writelines(lines)  
    file.close()

def make_galactic_coordinates_file(fits_file,pp_file,gc_file):
    output=os.popen(WCS_DIR+"xy2sky -g "+fits_file+" @"+pp_file).readlines()
    os.popen("rm -f "+gc_file)
    file=open(gc_file,"w")
    file.writelines(output)  
    file.close()
 
def build_healpix_gsm_maps(freqs):
    pwd=os.popen("pwd").readlines()[0].replace("\n","")
    for f in freqs:
        os.chdir(GSM_DIR)
        if (not(os.path.isfile("outfile_"+str(f)))):
            gsm_cmd="./gsm "+str(f)#+" > outfile_"+str(f)
            print gsm_cmd
            gsm_process=os.popen(gsm_cmd)
            gsm_process.close()
            outfiles_list_process=os.popen("ls -t outfile_*")
            outfiles_list=outfiles_list_process.readlines()
            outfiles_list_process.close()
            mv_process=os.popen("mv "+outfiles_list[0].replace('\n','')+" "+"outfile_"+str(f))
            mv_process.close()
        else:
            print "outfile_"+str(f)+" already exists. No need to rebuild it."
    os.chdir(pwd)


def nside2npix(nside):
    return(12*nside*nside)

def ang2pix_ring(nside,theta,phi):
    npix=nside2npix(nside)
    pion2=math.pi/2.0
    twopi=2.0*math.pi
    nl2   = 2*nside
    nl4   = 4*nside
    ncap  = nl2*(nside-1)
    cth0 = 2.0/3.0
    cth_in = math.cos(theta)
    phi_in=phi%twopi
#phi_in = phi + (phi LE 0.d0)*twopi
    if ((cth_in<=cth0) and (cth_in>-cth0)):
        tt=phi_in/pion2
        jp=long(nside*(0.5 + tt - cth_in*0.75))
        jm=long(nside*(0.5 + tt + cth_in*0.75))
        ir = (nside + 1) + jp - jm
        if (ir%2==0): k=1
        else: k=0
        ip=long((jp+jm+k +(1-nside))/2)+ 1
        if (ip>nl4): ip-=nl4
        ipring=ncap + nl4*(ir-1) + ip - 1
    if (cth_in>cth0):
        tt=phi_in/pion2
        tp=tt%1.0
        tmp=math.sqrt(3.0*(1.0-abs(cth_in)))
        jp=long(nside*tp*tmp)
        jm=long(nside*(1.0-tp)*tmp)
        ir=jp+jm+1
        ip=long(tt*ir)+1
        ir4=4*ir
        if (ip>ir4): ip-=ir4
        ipring=2*ir*(ir-1) + ip - 1
    if (cth_in<=-cth0):
        tt=phi_in/pion2
        tp=tt%1.0
        tmp=math.sqrt(3.0*(1.0-abs(cth_in)))
        jp=long(nside*tp*tmp)
        jm=long(nside*(1.0-tp)*tmp)
        ir=jp+jm+1
        ip=long(tt*ir)+1
        ir4=4*ir
        if (ip>ir4): ip-=ir4
        ipring=npix-2*ir*(ir-1) + ip - 1
    return(ipring)
       
def make_gsm_map(fits_file):
    nside=512
    npix=(12)*nside*nside
    hpx_area=4.0*math.pi*math.pow(rad2deg(1.0),2.0)/npix
#    print hpx_area
    # FIRST GET fits_file info
    hdulist=pyfits.open(fits_file)
    hdu=hdulist[0]
    Nx=hdu.header['NAXIS1']
    Ny=hdu.header['NAXIS2']
#    print Nx,Ny
    Nfreqs=hdu.header['NAXIS3']
    nu0=constant("nu0_HI") # in MHz
    if (hdu.header['CTYPE3']=="FREQ"):
        freqs=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        if (hdu.header['CUNIT3']=="HZ"): freqs/=1e6 # That's what it should be from mapmaking_script.py
        if (hdu.header['CUNIT3']=="KHZ"): freqs/=1e3
        if (hdu.header['CUNIT3']=="GHZ"): freqs*=1e3
    elif (hdu.header['CTYPE3']=="VELO"):
        velos=(grid(Nfreqs)-hdu.header['CRPIX3']+1)*hdu.header['CDELT3']+hdu.header['CRVAL3']
        freqs=[]
        for v in velos:
            freqs.append(velo2freq(v,nu0))
    else:
        print "unknown"
    if (hdu.header['CUNIT1']=='DEGREE'):dx=abs(deg2arcsec(hdu.header['CDELT1']))
    if (hdu.header['CUNIT2']=='DEGREE'):dy=abs(deg2arcsec(hdu.header['CDELT2']))
    pixel_area=dx*dy*2.3504e-11 # IN STERADIAN
#    sqpx_area=abs(hdu.header['CDELT1'])*abs(hdu.header['CDELT2'])
#    print sqpx_area,hpx_area
    pp_file=SCRATCH_DIR+"pp"
    gc_file=SCRATCH_DIR+"gc"
    # THEN MAKE A PIXEL POSITIONS FILE 
    make_pixel_positions_file(Nx,Ny,pp_file)
    # THEN BUILD THE CORRESPONDING GALACTIC COORDINATES FILE
    make_galactic_coordinates_file(fits_file,pp_file,gc_file)
    # THEN MAKE HEALPIX GSM MAPS FOR ALL FREQUENCIES
    build_healpix_gsm_maps(freqs)
    # THEN MAKE EMPTY ARRAY OF THE CORRECT SIZE
    result=numpy.zeros(hdu.data.shape,dtype=data_type)    
    mapping=numpy.zeros((Ny,Nx),dtype=long)
    # THEN WE NEED TO GET THE HEALPIX PIXEL CORRESPONDING TO EACH OF THESE GALACTIC COORDINATES
    fp=open(gc_file,"r")
    for line in fp:    
        sp=line.replace("\n","").split()
#        print sp
        ix=float(sp[3])
        iy=float(sp[4])
        gal_lon=float(sp[0])
        gal_lat=float(sp[1])  
        phi=deg2rad(gal_lon)
        theta=math.pi/2.0-deg2rad(gal_lat)
        ihpx=ang2pix_ring(nside,theta,phi)
        mapping[iy][ix]=ihpx
#    min_mapping=numpy.min(mapping)
#    max_mapping=numpy.max(mapping)
    mapping_values=numpy.unique(mapping)
    for i_f in range(Nfreqs):
        gsm_file=GSM_DIR+"outfile_"+str(freqs[i_f])
        fp=open(gsm_file,"r")
        fpl=fp.readlines()
        for im in mapping_values:
            w=numpy.where(mapping==im)
            v=Tb2I(float(fpl[int(im)].replace("\n","")),freqs[i_f]) # THIS GIVES THE SPECIFIC INTENSITY IN W/m2/Hz/sr
            v*=1e26*pixel_area # NOW IN Jy/PIXEL
            if (hdu.header['NAXIS']==4):
                for k in range(len(w[0])): result[0][i_f][w[0][k]][w[1][k]]=v
            if (hdu.header['NAXIS']==3):
                for k in range(len(w[0])): result[i_f][w[0][k]][w[1][k]]=v
    return(result)


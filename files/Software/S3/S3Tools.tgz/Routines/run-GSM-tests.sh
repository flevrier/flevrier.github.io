#!/bin/bash

# Get directory information
routines_dir=$PWD"/"
cd ..
tests_dir=$PWD"/Tests"
cd Routines/

sax_tarfile="single-sax"
# Data for the galaxy read from the .result file
RA=0.057951 # Source right ascension in degrees 208.6236"
DEC=0.038626 # Source declination in degrees 139.0536"
Z=9.66001 # Source apparent redshift
HI=2.39e-08 # HI integrated flux (Jy.km/s)
CO_1=8.43e-06 # CO(1-0) integrated flux (Jy.km/s)
CO_2=3.35e-05 # CO(2-1) integrated flux (Jy.km/s)
CO_3=7.48e-05 # CO(3-2) integrated flux (Jy.km/s)
CO_4=0.000131 # CO(4-3) integrated flux (Jy.km/s)
CO_5=0.000201 # CO(5-4) integrated flux (Jy.km/s)
CO_6=0.000284 # CO(6-5) integrated flux (Jy.km/s)
CO_7=0.000377 # CO(7-6) integrated flux (Jy.km/s)
CO_8=0.000479 # CO(8-7) integrated flux (Jy.km/s)
CO_9=0.000548 # CO(9-8) integrated flux (Jy.km/s)
CO_10=0.000442 # CO(10-9) integrated flux (Jy.km/s)
PA=0.071 # Disk position angle counted positively east from north (radians)
HI_AXIS_ratio=0.152 # Minor-to-major axis ratio of the HI disk
HI_MAJOR_AXIS_10MAX=0.15 # Major axis of the HI disk measured at 10% of the peak of the surface brightness in HI (arcseconds)
H2_AXIS_RATIO=0.152 # Minor-to-major axis ratio of the H2 disk
H2_MAJOR_AXIS_10MAX=0.0335 # Major axis of the H2 disk measured at 10% of the peak of the surface brightness in H2 (arcseconds)
HI_WIDTH20=232 # Observed width of the HI line at 20% of the peak luminosity (km/s)
CO_WIDTH20=298 # Observed width of the CO lines at 20% of the peak luminosity (km/s)

window_6am="200.,560,-180.,180." # 6' on each side
window_30deg="-54000.,54000,-54000.,54000." # 10deg on each side

freqrange_10MHz="0.01,0.005,1" # 1 channel (5 kHz) centered on 10 MHz
freqrange_20MHz="0.02,0.005,1" # 1 channel (5 kHz) centered on 20 MHz
freqrange_50MHz="0.05,0.005,1" # 1 channel (5 kHz) centered on 50 MHz
freqrange_300MHz="0.3,0.005,1" # 1 channel (5 kHz) centered on 300 MHz
freqrange_1GHz="1.0,0.005,1" # 1 channel (5 kHz) centered on 1 GHz
freqrange_2GHz="2.0,0.005,1" # 1 channel (5 kHz) centered on 2 GHz
freqrange_20GHz="20.0,0.005,1" # 1 channel (5 kHz) centered on 20 GHz
freqrange_30GHz="30.0,0.005,1" # 1 channel (5 kHz) centered on 30 GHz
freqrange_40GHz="40.0,0.005,1" # 1 channel (5 kHz) centered on 40 GHz
freqrange_50GHz="50.0,0.005,1" # 1 channel (5 kHz) centered on 50 GHz


outfile="gsm-6am-10MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_10MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-20MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_20MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-50MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_50MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-300MHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_300MHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-1GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_1GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-2GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_2GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-20GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_20GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-30GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_30GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-40GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_40GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-6am-50GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_6am --freqinfo=$freqrange_50GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=360. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

outfile="gsm-30deg-1GHz"
echo '>>>> BUILDING FILE '$outfile
python ${routines_dir}SAX_map_script.py --in=$sax_tarfile --out=$outfile --dir=$tests_dir --window=$window_30deg --freqinfo=$freqrange_1GHz --bmaj=0.0001 --bmin=0.0001 --bpa=0.0 --noise=0.0 --pixelsize=3600. --rarefpos=193.27673613 --decrefpos=26.98027940 --userefpos --hi=Oxford --freqaxis --zrange=9.66001,9.66001 --nocmb --gsm
echo '----------------------------------------------------------------'

echo '####################################################################'
echo '# TESTING FOR DIFFERENCES WITH REFERENCE FILES USING DIFF COMMANDS #'
echo '####################################################################'
cd ../Tests/
for outfile in *gsm*.fits; do
    echo 'Testing '$outfile' for differences with reference file. No other output means no difference...'
    diff $outfile Reference/$outfile
done

# Build spectra plots and print out integrated fluxes 
echo '##################################################################################################'
echo '# BUILD GSM SPECTRUM AT A SINGLE LOCATION OVER 10 MHz - 50 GHz AND LARGE SCALE EMISSION AT 1 GHz #'
echo '##################################################################################################'
cd ../Routines/
python plot-GSM-tests.py

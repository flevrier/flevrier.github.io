import os
import pyfits
import matplotlib
import matplotlib.pyplot
import matplotlib.mpl
import numpy
import math
from common_routines import constant,deg2arcsec,rad2deg
from common_map_routines import channel_boundary_frequencies,channel_boundary_velocities
from matplotlib.patches import Ellipse


TEST_DIR="../Tests/"
# Data for the galaxy read from the .result file

#DATA FOR NORTH LOBE 
# 0.00215,0.01942,0.016,8.748,1.917,-7.3235,NULL,NULL,NULL,-7.7783,NULL,NULL,NULL,-8.0489,NULL,NULL,NULL,-8.4543,NULL,NULL,NULL,-8.8807,NULL,NULL,NULL
RA_N=0.00215 # Source right ascension in degrees 
DEC_N=0.01942 # Source declination in degrees 
PA_N=0.016 # Disk position angle counted positively east from north (radians)
MAJOR_AXIS_N=8.748 # Major axis (arcseconds)
MINOR_AXIS_N=1.917 # Minor axis (arcseconds)
Z_N=1.96970937 # Source apparent redshift
I_151_N=-7.3235
I_610_N=-7.7783
I_1400_N=-8.0489
I_4860_N=-8.4543
I_18000_N=-8.8807

#DATA FOR SOUTH LOBE 
# 0.00211,0.01699,0.016,8.748,1.917,-7.3235,NULL,NULL,NULL,-7.7783,NULL,NULL,NULL,-8.0489,NULL,NULL,NULL,-8.4543,NULL,NULL,NULL,-8.8807,NULL,NULL,NULL
RA_S=0.00211 # Source right ascension in degrees 
DEC_S=0.01699 # Source declination in degrees 
PA_S=0.016 # Disk position angle counted positively east from north (radians)
MAJOR_AXIS_S=8.748 # Major axis (arcseconds)
MINOR_AXIS_S=1.917 # Minor axis (arcseconds)
Z_S=1.96970937 # Source apparent redshift
I_151_S=-7.3235
I_610_S=-7.7783
I_1400_S=-8.0489
I_4860_S=-8.4543
I_18000_S=-8.8807

#DATA FOR CORE
# 0.00213,0.0182,0,0,0,-9.7709,NULL,NULL,NULL,-9.7127,NULL,NULL,NULL,-9.7792,NULL,NULL,NULL,-10.0201,NULL,NULL,NULL,-10.4565,NULL,NULL,NULL
RA_C=0.00213 # Source right ascension in degrees 
DEC_C=0.0182 # Source declination in degrees 
PA_C=0.0 # Disk position angle counted positively east from north (radians)
MAJOR_AXIS_C=0.0 # Major axis (arcseconds)
MINOR_AXIS_C=0.0 # Minor axis (arcseconds)
Z_C=1.96970937 # Source apparent redshift
I_151_C=-9.7709
I_610_C=-9.7127
I_1400_C=-9.7792
I_4860_C=-10.0201
I_18000_C=-10.4565

# TOTAL FLUXES DATA
I_151_T=-7.0217
I_610_T=-7.4748
I_1400_T=-7.7438
I_4860_T=-8.1474
I_18000_T=-8.5739


def fig_spatial_extent(file,ras,decs,major_axes,minor_axes,pas,figname):
#    print file
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
    Nx=hdr['NAXIS1']
    Ny=hdr['NAXIS2']
    Nfreqs=hdr['NAXIS3']
    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
    x=deg2arcsec(float(hdr['CDELT1']))*(numpy.arange(float(Nx))-float(hdr['CRPIX1'])+1)+deg2arcsec(float(hdr['CRVAL1']))
    y=deg2arcsec(float(hdr['CDELT2']))*(numpy.arange(float(Ny))-float(hdr['CRPIX2'])+1)+deg2arcsec(float(hdr['CRVAL2']))
    extent=[max(x)-deg2arcsec(float(hdr['CDELT1']))/2.0,min(x)+deg2arcsec(float(hdr['CDELT1']))/2.0,min(y)-deg2arcsec(float(hdr['CDELT2']))/2.0,max(y)+deg2arcsec(float(hdr['CDELT2']))/2.0]
#    extent=[max(x),min(x),min(y),max(y)]
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern_r')
    # MAKE IMAGE
    im=ax1.imshow(data[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])

    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
#    ax1.xaxis.set_major_locator(majorLocator)
    #ax1.yaxis.set_major_locator(majorLocator)
    ax1.set_xlabel(r'$\alpha$ ["]',fontsize=20)
    ax1.set_ylabel(r'$\delta$ ["]',fontsize=20)

    matplotlib.pyplot.axhline(y=deg2arcsec(DEC_C),xmin=0,xmax=1,color='red')
    matplotlib.pyplot.axvline(x=deg2arcsec(RA_C),ymin=0,ymax=1,color='red')
    # ADD CROSS AT CENTRAL LOCATION
#    matplotlib.pyplot.scatter([deg2arcsec(RA)],[deg2arcsec(DEC)],marker="+")
    # ADD ELLIPSE
    for i in range(len(ras)):
        e=Ellipse(xy=[deg2arcsec(ras[i]),deg2arcsec(decs[i])], width=major_axes[i], height=minor_axes[i], angle=90.0-rad2deg(pas[i]),fill=False)
        ax1.add_artist(e)
        e.set_clip_box(ax1.bbox)
#    e.set_alpha(0.5)
    # SAVE FIGURE
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

def fig_cut_window(file_tl,file_bl,file_tr,file_br,figname):
#    for file in files:
    hdu_tl=pyfits.open(TEST_DIR+file_tl)[0]
    hdr_tl=hdu_tl.header
    data_tl=hdu_tl.data
    hdu_tr=pyfits.open(TEST_DIR+file_tr)[0]
    hdr_tr=hdu_tr.header
    data_tr=hdu_tr.data
    hdu_bl=pyfits.open(TEST_DIR+file_bl)[0]
    hdr_bl=hdu_bl.header
    data_bl=hdu_bl.data
    hdu_br=pyfits.open(TEST_DIR+file_br)[0]
    hdr_br=hdu_br.header
    data_br=hdu_br.data

    # BUILD FIGURE LAYOUT
    fig = matplotlib.pyplot.figure()
    majorLocator   = matplotlib.pyplot.MultipleLocator(5)
    # SPECIFY COLOR MAP
    cmap=matplotlib.pyplot.get_cmap('gist_stern_r')

    tl=fig.add_subplot(2,2,1)
    x_tl=deg2arcsec(float(hdr_tl['CDELT1']))*(numpy.arange(float(hdr_tl['NAXIS1']))-float(hdr_tl['CRPIX1'])+1)+deg2arcsec(float(hdr_tl['CRVAL1']))
    y_tl=deg2arcsec(float(hdr_tl['CDELT2']))*(numpy.arange(float(hdr_tl['NAXIS2']))-float(hdr_tl['CRPIX2'])+1)+deg2arcsec(float(hdr_tl['CRVAL2']))
    extent_tl=[max(x_tl)-deg2arcsec(float(hdr_tl['CDELT1']))/2.0,min(x_tl)+deg2arcsec(float(hdr_tl['CDELT1']))/2.0,min(y_tl)-deg2arcsec(float(hdr_tl['CDELT2']))/2.0,max(y_tl)+deg2arcsec(float(hdr_tl['CDELT2']))/2.0]
#    extent_tl=[max(x_tl),min(x_tl),min(y_tl),max(y_tl)]
    # MAKE IMAGE
    tl.imshow(data_tl[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent_tl,vmax=2.14e-10)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
#    tl.set_xlabel(r'$\alpha$ ["]',fontsize=20)
    tl.set_ylabel(r'$\delta$ ["]',fontsize=20)

    tr=fig.add_subplot(2,2,2)
    x_tr=deg2arcsec(float(hdr_tr['CDELT1']))*(numpy.arange(float(hdr_tr['NAXIS1']))-float(hdr_tr['CRPIX1'])+1)+deg2arcsec(float(hdr_tr['CRVAL1']))
    y_tr=deg2arcsec(float(hdr_tr['CDELT2']))*(numpy.arange(float(hdr_tr['NAXIS2']))-float(hdr_tr['CRPIX2'])+1)+deg2arcsec(float(hdr_tr['CRVAL2']))
    extent_tr=[max(x_tr)-deg2arcsec(float(hdr_tr['CDELT1']))/2.0,min(x_tr)+deg2arcsec(float(hdr_tr['CDELT1']))/2.0,min(y_tr)-deg2arcsec(float(hdr_tr['CDELT2']))/2.0,max(y_tr)+deg2arcsec(float(hdr_tr['CDELT2']))/2.0]
#    extent_tr=[max(x_tr),min(x_tr),min(y_tr),max(y_tr)]
    # MAKE IMAGE
    tr.imshow(data_tr[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent_tr,vmax=2.14e-10)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
#    tr.set_xlabel(r'$\alpha$ ["]',fontsize=20)
#    tr.set_ylabel(r'$\delta$ ["]',fontsize=20)

    bl=fig.add_subplot(2,2,3)
    x_bl=deg2arcsec(float(hdr_bl['CDELT1']))*(numpy.arange(float(hdr_bl['NAXIS1']))-float(hdr_bl['CRPIX1'])+1)+deg2arcsec(float(hdr_bl['CRVAL1']))
    y_bl=deg2arcsec(float(hdr_bl['CDELT2']))*(numpy.arange(float(hdr_bl['NAXIS2']))-float(hdr_bl['CRPIX2'])+1)+deg2arcsec(float(hdr_bl['CRVAL2']))
    extent_bl=[max(x_bl)-deg2arcsec(float(hdr_bl['CDELT1']))/2.0,min(x_bl)+deg2arcsec(float(hdr_bl['CDELT1']))/2.0,min(y_bl)-deg2arcsec(float(hdr_bl['CDELT2']))/2.0,max(y_bl)+deg2arcsec(float(hdr_bl['CDELT2']))/2.0]
#    extent_bl=[max(x_bl),min(x_bl),min(y_bl),max(y_bl)]
    # MAKE IMAGE
    bl.imshow(data_bl[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent_bl,vmax=2.14e-10)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
    bl.set_xlabel(r'$\alpha$ ["]',fontsize=20)
    bl.set_ylabel(r'$\delta$ ["]',fontsize=20)

    br=fig.add_subplot(2,2,4)
    x_br=deg2arcsec(float(hdr_br['CDELT1']))*(numpy.arange(float(hdr_br['NAXIS1']))-float(hdr_br['CRPIX1'])+1)+deg2arcsec(float(hdr_br['CRVAL1']))
    y_br=deg2arcsec(float(hdr_br['CDELT2']))*(numpy.arange(float(hdr_br['NAXIS2']))-float(hdr_br['CRPIX2'])+1)+deg2arcsec(float(hdr_br['CRVAL2']))
    extent_br=[max(x_br)-deg2arcsec(float(hdr_br['CDELT1']))/2.0,min(x_br)+deg2arcsec(float(hdr_br['CDELT1']))/2.0,min(y_br)-deg2arcsec(float(hdr_br['CDELT2']))/2.0,max(y_br)+deg2arcsec(float(hdr_br['CDELT2']))/2.0]
#    extent_br=[max(x_br),min(x_br),min(y_br),max(y_br)]
    # MAKE IMAGE
    br.imshow(data_br[0,:,:], interpolation='nearest',origin='lower',cmap=cmap,extent=extent_br,vmax=2.14e-10)#,extent=[0,50,float(minval)*50./1024.,float(maxval)*50./1024.])
    br.set_xlabel(r'$\alpha$ ["]',fontsize=20)
#    br.set_ylabel(r'$\delta$ ["]',fontsize=20)

    # SAVE FIGURE
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

def plot_spectra_generic(file,expected_fluxes_array,figname):
# INITIALIZE FIGURE
    fig=matplotlib.pyplot.figure()
    ax=fig.add_subplot(111)
    ax.set_xlabel(r'$\nu$'+' [MHz]',fontsize=20)
    ax.set_ylabel('Flux density [Jy]',fontsize=20)
    hdu=pyfits.open(TEST_DIR+file)[0]
    hdr=hdu.header
    data=hdu.data
    Nfreqs=hdr['NAXIS3']
    freq_axis=(numpy.arange(Nfreqs)-hdr['CRPIX3']+1)*(hdr['CDELT3']/1e6)+(hdr['CRVAL3']/1e6) # in MHz
    spectrum=numpy.zeros((Nfreqs),dtype=numpy.float64)
    c_spectrum=numpy.zeros((Nfreqs),dtype=numpy.float64)
    for i_f in range(Nfreqs):
        spectrum[i_f]=(data[i_f,:,:]).sum()
        c_spectrum[i_f]=data[i_f,155,122]-data[i_f,153,122]
    ax.loglog(freq_axis,spectrum,'b-')
    ax.loglog(freq_axis,c_spectrum,'r-')

    REF_FREQS=[151.,610.,1400.,4860.,18000.]
    for i in range(len(expected_fluxes_array)):
        expected_fluxes=expected_fluxes_array[i]
        if (i==0):
            for i_f in range(len(expected_fluxes)):ax.loglog([REF_FREQS[i_f]],[expected_fluxes[i_f]],'o')
        if (i==1):
            ax.loglog(REF_FREQS,expected_fluxes,'s',color='b')
        if (i==2):
            ax.loglog(REF_FREQS,expected_fluxes,'x',color='b')
        if (i==3):
            ax.loglog(REF_FREQS,expected_fluxes,'d',color='r')
    matplotlib.pyplot.xlim(130,20000)
    matplotlib.pyplot.savefig(figname)
#    matplotlib.pyplot.show()

extension=".png"
#extension=".eps"
fig_spatial_extent("sex-100mas.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-100mas"+extension)
fig_spatial_extent("sex-3as.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-3as"+extension)
fig_spatial_extent("sex-40as.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-40as"+extension)
fig_spatial_extent("sex-100mas-smeared.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-100mas-smeared"+extension)
fig_spatial_extent("sex-3as-smeared.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-3as-smeared"+extension)
fig_spatial_extent("sex-40as-smeared.fits",[RA_N,RA_S,RA_C],[DEC_N,DEC_S,DEC_C],[MAJOR_AXIS_N,MAJOR_AXIS_S,MAJOR_AXIS_C],[MINOR_AXIS_N,MINOR_AXIS_S,MINOR_AXIS_C],[PA_N,PA_S,PA_C],TEST_DIR+"extent-sex-40as-smeared"+extension)

plot_spectra_generic("sex-100mas.fits",[[math.pow(10.0,I_151_T),math.pow(10.0,I_610_T),math.pow(10.0,I_1400_T),math.pow(10.0,I_4860_T),math.pow(10.0,I_18000_T)],
                                        [math.pow(10.0,I_151_N),math.pow(10.0,I_610_N),math.pow(10.0,I_1400_N),math.pow(10.0,I_4860_N),math.pow(10.0,I_18000_N)],
                                        [math.pow(10.0,I_151_S),math.pow(10.0,I_610_S),math.pow(10.0,I_1400_S),math.pow(10.0,I_4860_S),math.pow(10.0,I_18000_S)],
                                        [math.pow(10.0,I_151_C),math.pow(10.0,I_610_C),math.pow(10.0,I_1400_C),math.pow(10.0,I_4860_C),math.pow(10.0,I_18000_C)]],TEST_DIR+"spectrum-sex"+extension)

fig_cut_window("sex-100mas-tl.fits","sex-100mas-bl.fits","sex-100mas-tr.fits","sex-100mas-br.fits",TEST_DIR+"sex-cut-window-test"+extension)

import math

class attribute:
    def __init__(self,name,type,null,unit,description):
        self.name=name
        self.type=type
        self.null=null
        self.unit=unit
        self.description=description

# Reference frequencies in GHz
REF_FREQS=[0.151,0.61,1.4,4.86,18.]
ref_logfreqs=[]
for freq in REF_FREQS: ref_logfreqs.append(math.log10(freq))

STOKES=["I","Q","U","V"]

SEX_GALAXY_TYPES=["RQAGN","FRI","FRII","SFG","SBG"]

# Attribute names
COMPONENT="component"
CLUSTER="cluster"
GALAXY="galaxy"
SF_TYPE="sftype"
AGN_TYPE="agntype"
STRUCTURE="structure"
RA="right_ascension"
DEC="declination"
DISTANCE="distance"
Z="redshift"
MOD_Z="modified_redshift"
PA="position_angle"
MAJOR_AXIS="major_axis"
MINOR_AXIS="minor_axis"
IQUV_CONTINUUM=[]
for freq in REF_FREQS: IQUV_CONTINUUM.append(["i_"+str(int(1000*freq)),"q_"+str(int(1000*freq)),"u_"+str(int(1000*freq)),"v_"+str(int(1000*freq))])
ITOT_CONTINUUM=[]
for freq in REF_FREQS: ITOT_CONTINUUM.append("itot_"+str(int(1000*freq)))
M_HI="m_hi"
COS_VA="cos_va"
VIRIAL_MASS="virial_mass"
VIRIAL_RADIUS="virial_radius"
VELOCITY_DISPERSION="velocity_dispersion"

# Database name
SEX_DB_NAME="S3SEX"

#########################
###   CLUSTER TABLE   ###
#########################

SEX_CLUSTER_TABLE_NAME="Clusters"
SEX_CLUSTER_TABLE_ATTRIBUTES=[
    attribute(CLUSTER,"INT(10) UNSIGNED","NOT NULL","","Cluster identifier"),
    attribute(RA,"DOUBLE","NOT NULL","degrees","Cluster right ascension"),
    attribute(DEC,"DOUBLE","NOT NULL","degrees","Cluster declination"),
    attribute(Z,"DOUBLE","NOT NULL","","Hubble flow cluster redshift"),
    attribute(MOD_Z,"DOUBLE","NOT NULL","","Actual cluster redshift"),
    attribute(VIRIAL_MASS,"DOUBLE","NOT NULL","Msun/h","Virial mass"),
    attribute(VIRIAL_RADIUS,"DOUBLE","NOT NULL","Mpc/h","Virial radius"),
    attribute(VELOCITY_DISPERSION,"DOUBLE","NOT NULL","km/s","Velocity dispersion")
]
SEX_CLUSTER_TABLE_KEY=0 
SEX_CLUSTER_TABLE_INDICES=[[]]
SEX_CLUSTER_TABLE_ENGINE="MyISAM"
SEX_CLUSTER_TABLE_CHARSET="latin1"
SEX_CLUSTER_ITEMS_DEFAULT=[]

########################
###   GALAXY TABLE   ###
########################

SEX_GALAXY_TABLE_NAME="Galaxies"
SEX_GALAXY_TABLE_ATTRIBUTES=[
    attribute(GALAXY,"BIGINT(20) UNSIGNED","NOT NULL","","Galaxy identifier"),
    attribute(CLUSTER,"INT(10) UNSIGNED","NOT NULL","","Cluster identifier"),
    attribute(SF_TYPE,"SMALLINT(5) UNSIGNED","NOT NULL","","Star-formation type identifier"),
    attribute(AGN_TYPE,"SMALLINT(5) UNSIGNED","NOT NULL","","AGN type identifier"),
    attribute(RA,"DOUBLE","NOT NULL","degrees","Galaxy right ascension"),
    attribute(DEC,"DOUBLE","NOT NULL","degrees","Galaxy declination"),
    attribute(DISTANCE,"DOUBLE","NOT NULL","Mpc","Comoving distance"),
    attribute(Z,"DOUBLE","NOT NULL","","Hubble flow redshift"),
    attribute(MOD_Z,"DOUBLE","NOT NULL","","Actual redshift")]
for i_freq in range(len(REF_FREQS)): 
    SEX_GALAXY_TABLE_ATTRIBUTES.append(attribute(ITOT_CONTINUUM[i_freq],"DOUBLE","NOT NULL","log10(Jy)","Total intensity I @ "+str(REF_FREQS[i_freq])+" GHz"))
SEX_GALAXY_TABLE_ATTRIBUTES.extend([attribute(M_HI,"DOUBLE","NULL","log10(Msun)","HI Mass"),attribute(COS_VA,"DOUBLE","NULL","","Cosine of viewing angle")])
SEX_GALAXY_TABLE_KEY=0 
SEX_GALAXY_TABLE_INDICES=[["ra_index","BTREE","`"+RA+"` ASC"],["dec_index","BTREE","`"+DEC+"` ASC"]]
SEX_GALAXY_TABLE_ENGINE="MyISAM"
SEX_GALAXY_TABLE_CHARSET="latin1"
SEX_GALAXY_ITEMS_DEFAULT=[GALAXY,SF_TYPE,AGN_TYPE,RA,DEC,DISTANCE,Z,M_HI]

###########################
###   COMPONENT TABLE   ###
###########################

SEX_COMPONENT_TABLE_NAME="Components"
SEX_COMPONENT_TABLE_ATTRIBUTES=[
    attribute(COMPONENT,"BIGINT(20) UNSIGNED","NOT NULL","","Component identifier"),
    attribute(GALAXY,"BIGINT(20) UNSIGNED","NOT NULL","","Galaxy identifier"),
    attribute(STRUCTURE,"SMALLINT(5) UNSIGNED","NOT NULL","","Structure type identifier"),
    attribute(RA,"DOUBLE","NOT NULL","degrees","Right ascension"),
    attribute(DEC,"DOUBLE","NOT NULL","degrees","Declination"),
    attribute(PA,"DOUBLE","NOT NULL","radians","Position angle"),
    attribute(MAJOR_AXIS,"DOUBLE","NOT NULL","arcsec","Major axis"),
    attribute(MINOR_AXIS,"DOUBLE","NOT NULL","arcsec","Minor axis")]
for i_freq in range(len(REF_FREQS)): 
    SEX_COMPONENT_TABLE_ATTRIBUTES.append(attribute(IQUV_CONTINUUM[i_freq][0],"DOUBLE","NOT NULL","log10(Jy)","Stokes "+STOKES[0]+" @ "+str(REF_FREQS[i_freq])+" GHz"))
    for i_pol in range(1,4):
        SEX_COMPONENT_TABLE_ATTRIBUTES.append(attribute(IQUV_CONTINUUM[i_freq][i_pol],"DOUBLE","NULL","log10(Jy)","Stokes "+STOKES[i_pol]+" @ "+str(REF_FREQS[i_freq])+" GHz"))
SEX_COMPONENT_TABLE_KEY=0
SEX_COMPONENT_TABLE_INDICES=[[]]
SEX_COMPONENT_TABLE_ENGINE="MyISAM"
SEX_COMPONENT_TABLE_CHARSET="latin1"
SEX_COMPONENT_ITEMS_DEFAULT=[COMPONENT,GALAXY,RA,DEC,PA,MAJOR_AXIS,MINOR_AXIS,IQUV_CONTINUUM[0][0],IQUV_CONTINUUM[1][0],IQUV_CONTINUUM[2][0],IQUV_CONTINUUM[3][0],IQUV_CONTINUUM[4][0]]

import math

class attribute:
    def __init__(self,name,type,null,unit,description):
        self.name=name
        self.type=type
        self.null=null
        self.unit=unit
        self.description=description

# Attribute names
GALAXY="id"
GAVO_GALAXY="galaxyid"
BOX="box"
RA="ra"
DEC="decl"
DISTANCE="distance"
Z="zapparent"
HUBBLE_TYPE="hubbletype"
HI_MASS="himass"
H2_MASS="h2mass"
HI_INTFLUX="hiintflux"
CO_1_0_INTFLUX="cointflux_1"
CO_2_1_INTFLUX="cointflux_2"
CO_3_2_INTFLUX="cointflux_3"
CO_4_3_INTFLUX="cointflux_4"
CO_5_4_INTFLUX="cointflux_5"
CO_6_5_INTFLUX="cointflux_6"
CO_7_6_INTFLUX="cointflux_7"
CO_8_7_INTFLUX="cointflux_8"
CO_9_8_INTFLUX="cointflux_9"
CO_10_9_INTFLUX="cointflux_10"
PA="diskpositionangle"
INCLINATION="diskinclination"
SCALERADIUS="gasscaleradius"
RMOLC="rmolc"
HI_AXIS_RATIO="hiaxisratio"
HI_MAJOR_AXIS_MSUNPC="himajoraxis_msunpc"
HI_MAJOR_AXIS_MAX="himajoraxis_max"
HI_MAJOR_AXIS_50MAX="himajoraxis_50max"
HI_MAJOR_AXIS_10MAX="himajoraxis_10max"
HI_MAJOR_AXIS_HALFMASS="himajoraxis_halfmass"
H2_AXIS_RATIO="h2axisratio"
H2_MAJOR_AXIS_MSUNPC="h2majoraxis_msunpc"
H2_MAJOR_AXIS_50MAX="h2majoraxis_50max"
H2_MAJOR_AXIS_10MAX="h2majoraxis_10max"
H2_MAJOR_AXIS_HALFMASS="h2majoraxis_halfmass"
BALANCE_MAJOR_AXIS="balancemajoraxis"
HI_LUM_CENTER="hilumcenter"
HI_LUM_PEAK="hilumpeak"
HI_LINEWIDTHPEAK="hiwidthpeak"
HI_LINEWIDTH50="hiwidth50"
HI_LINEWIDTH20="hiwidth20"
CO_LUM_CENTER="columcenter"
CO_LUM_PEAK="columpeak"
CO_LINEWIDTHPEAK="cowidthpeak"
CO_LINEWIDTH50="cowidth50"
CO_LINEWIDTH20="cowidth20"
CO_FILLING_FACTOR="cofillingfactor"
CLUSTER="cluster"
GAVO_CLUSTER="gavo_cluster"
GAVO_SNAPSHOT="gavo_snapshot"
VIRIAL_MASS="virial_mass"
BOUND_MASS="bound_mass"
VIRIAL_RADIUS="virial_radius"
VIRIAL_VELOCITY="virial_velocity"


# Database name
SAX_DB_NAME="S3SAX"

#########################
###   CLUSTER TABLE   ###
#########################

SAX_CLUSTER_TABLE_NAME="Clusters"
SAX_CLUSTER_TABLE_ATTRIBUTES=[
    attribute(CLUSTER,"INT(10) UNSIGNED","NOT NULL","","Cluster identifier"),
    attribute(GAVO_CLUSTER,"BIGINT(20) UNSIGNED","NOT NULL","","Cluster identifier in DeLucia2006a"),
    attribute(RA,"DOUBLE","NOT NULL","degrees","Cluster right ascension"),
    attribute(DEC,"DOUBLE","NOT NULL","degrees","Cluster declination"),
    attribute(DISTANCE,"DOUBLE","NOT NULL","Mpc","Comoving distance"),
    attribute(Z,"DOUBLE","NOT NULL","","Hubble flow cluster redshift"),
    attribute(VIRIAL_MASS,"DOUBLE","NOT NULL","Msun/h","Virial mass"),
    attribute(BOUND_MASS,"DOUBLE","NOT NULL","Msun/h","Bound mass"),
    attribute(VIRIAL_RADIUS,"DOUBLE","NOT NULL","Mpc/h","Virial radius"),
    attribute(VIRIAL_VELOCITY,"DOUBLE","NOT NULL","km/s","Virial velocity")
]
SAX_CLUSTER_TABLE_KEY=0 
SAX_CLUSTER_TABLE_INDICES=[[]]
SAX_CLUSTER_TABLE_ENGINE="MyISAM"
SAX_CLUSTER_TABLE_CHARSET="latin1"
SAX_CLUSTER_ITEMS_DEFAULT=[]

########################
###   GALAXY TABLE   ###
########################

SAX_GALAXY_TABLE_NAME="galaxies_line"
SAX_GALAXY_TABLE_ATTRIBUTES=[
    attribute(GALAXY,"BIGINT(20) UNSIGNED","NOT NULL","","Galaxy identifier"),
#    attribute(CLUSTER,"INT(10) UNSIGNED","NOT NULL","","Cluster identifier"),
    attribute(GAVO_GALAXY,"BIGINT(20) UNSIGNED","NOT NULL","","Galaxy identifier in DeLucia2006a"),
    attribute(BOX,"INT(20) UNSIGNED","NOT NULL","","Box index in the mock observing cone"),
#    attribute(GAVO_CLUSTER,"BIGINT(20) UNSIGNED","NOT NULL","","Cluster identifier in DeLucia2006a"),
#    attribute(GAVO_SNAPSHOT,"BIGINT(20) UNSIGNED","NOT NULL","","Snapshot in Millenium simulation and DeLucia2006a"),
    attribute(RA,"DOUBLE","NOT NULL","degrees","Galaxy right ascension"),
    attribute(DEC,"DOUBLE","NOT NULL","degrees","Galaxy declination"),
    attribute(DISTANCE,"DOUBLE","NOT NULL","Mpc","Comoving distance"),
    attribute(Z,"DOUBLE","NOT NULL","","Hubble flow redshift"),
    attribute(HUBBLE_TYPE,"DOUBLE","NOT NULL","","Numerical Hubble type"),
    attribute(HI_MASS,"DOUBLE","NOT NULL","Msun","HI Mass"),
    attribute(H2_MASS,"DOUBLE","NOT NULL","Msun","H2 Mass"),
    attribute(HI_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","HI velocity-integrated flux"),
    attribute(CO_1_0_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(1-0) velocity-integrated flux"),
    attribute(CO_2_1_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(2-1) velocity-integrated flux"),
    attribute(CO_3_2_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(3-2) velocity-integrated flux"),
    attribute(CO_4_3_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(4-3) velocity-integrated flux"),
    attribute(CO_5_4_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(5-4) velocity-integrated flux"),
    attribute(CO_6_5_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(6-5) velocity-integrated flux"),
    attribute(CO_7_6_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(7-6) velocity-integrated flux"),
    attribute(CO_8_7_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(8-7) velocity-integrated flux"),
    attribute(CO_9_8_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(9-8) velocity-integrated flux"),
    attribute(CO_10_9_INTFLUX,"DOUBLE","NOT NULL","Jy.km/s","CO(10-9) velocity-integrated flux"),
    attribute(PA,"DOUBLE","NOT NULL","radians","Position angle from North towards East"),
    attribute(INCLINATION,"DOUBLE","NOT NULL","radians","Disk inclination (0=face-on;pi/2=edge-on)"),
    attribute(SCALERADIUS,"DOUBLE","NOT NULL","kpc","Exponential scale radius for the cold gas disk"),
    attribute(RMOLC,"DOUBLE","NOT NULL","","H2/HI surface density ratio at the disk center"),
    attribute(HI_AXIS_RATIO,"DOUBLE","NOT NULL","","HI minor axis to major axis ratio"),
    attribute(HI_MAJOR_AXIS_MSUNPC,"DOUBLE","NOT NULL","arcsec","HI-radius where Sigma_HI is 1 Msun per parsec square"),
    attribute(HI_MAJOR_AXIS_MAX,"DOUBLE","NOT NULL","arcsec","HI-radius where Sigma_HI is maximal"),
    attribute(HI_MAJOR_AXIS_50MAX,"DOUBLE","NOT NULL","arcsec","HI-radius where Sigma_HI is 50% of its maximum"),
    attribute(HI_MAJOR_AXIS_10MAX,"DOUBLE","NOT NULL","arcsec","HI-radius where Sigma_HI is 10% of its maximum"),
    attribute(HI_MAJOR_AXIS_HALFMASS,"DOUBLE","NOT NULL","arcsec","HI-radius containing half of the HI-mass"),
    attribute(H2_AXIS_RATIO,"DOUBLE","NOT NULL","","H2 minor axis to major axis ratio"),
    attribute(H2_MAJOR_AXIS_MSUNPC,"DOUBLE","NOT NULL","arcsec","H2-radius where Sigma_H2 is 1 Msun per parsec square"),
    attribute(H2_MAJOR_AXIS_50MAX,"DOUBLE","NOT NULL","arcsec","H2-radius where Sigma_H2 is 50% of its maximum"),
    attribute(H2_MAJOR_AXIS_10MAX,"DOUBLE","NOT NULL","arcsec","H2-radius where Sigma_H2 is 10% of its maximum"),
    attribute(H2_MAJOR_AXIS_HALFMASS,"DOUBLE","NOT NULL","arcsec","H2-radius containing half of the H2-mass"),
    attribute(BALANCE_MAJOR_AXIS,"DOUBLE","NOT NULL","arcsec","Radius where Sigma_HI=Sigma_H2"),
    attribute(HI_LUM_CENTER,"DOUBLE","NOT NULL","s/km","Normalized central luminosity density at rest-frame"),
    attribute(HI_LUM_PEAK,"DOUBLE","NOT NULL","s/km","Normalized peak luminosity density at rest-frame"),
    attribute(HI_LINEWIDTHPEAK,"DOUBLE","NOT NULL","km/s","Line width between the two horns of the HI-line profile"),
    attribute(HI_LINEWIDTH50,"DOUBLE","NOT NULL","km/s","Line width at 50% of peak luminosity density"),
    attribute(HI_LINEWIDTH20,"DOUBLE","NOT NULL","km/s","Line width at 20% of peak luminosity density"),
    attribute(CO_LUM_CENTER,"DOUBLE","NOT NULL","s/km","Normalized central luminosity density at rest-frame"),
    attribute(CO_LUM_PEAK,"DOUBLE","NOT NULL","s/km","Normalized peak luminosity density at rest-frame"),
    attribute(CO_LINEWIDTHPEAK,"DOUBLE","NOT NULL","km/s","Line width between the two horns of the molecular line profiles"),
    attribute(CO_LINEWIDTH50,"DOUBLE","NOT NULL","km/s","Line width at 50% of peak luminosity density"),
    attribute(CO_LINEWIDTH20,"DOUBLE","NOT NULL","km/s","Line width at 20% of peak luminosity density"),
    attribute(CO_FILLING_FACTOR,"DOUBLE","NOT NULL","","CO filling factor in velocity and space [0-1]")]
SAX_GALAXY_TABLE_KEY=0 
SAX_GALAXY_TABLE_INDICES=[["ra_index","BTREE","`"+RA+"` ASC"],["dec_index","BTREE","`"+DEC+"` ASC"]]
SAX_GALAXY_TABLE_ENGINE="MyISAM"
SAX_GALAXY_TABLE_CHARSET="latin1"
SAX_GALAXY_ITEMS_DEFAULT=[GALAXY,RA,DEC,DISTANCE,Z,HUBBLE_TYPE,HI_INTFLUX,PA,INCLINATION,HI_AXIS_RATIO,HI_MAJOR_AXIS_MSUNPC,HI_MAJOR_AXIS_10MAX,HI_LINEWIDTH50]

# S-Cubed Interactive Tools root directory
S3TOOLS_PATH="/Path/To/Tools/"

# Directory where routines can be found
ROUTINES_DIR=S3TOOLS_PATH+"Routines/"

# Scratch directory where temporary files are stored
SCRATCH_DIR=S3TOOLS_PATH+"Tmp/"

# Documentation directory
DOC_DIR=S3TOOLS_PATH+"Doc/"

# Directory where the post-processed results, maps, catalogs and annotation files will be placed
OUTPUT_DIR=S3TOOLS_PATH+"Output/"

# Directory where the basic functionality tests are run, and where the reference files are located
TESTS_DIR=S3TOOLS_PATH+"Tests/"

# Directory where the shell script jobs are placed for parallel computing
JOBS_DIR=S3TOOLS_PATH+"Jobs/"

# Help file
Help_File=DOC_DIR+"S3Tools.pdf"

# WCS Tools binaries directory
WCS_DIR="/Path/To/WCS/bin/"

# Directory under which to find Global Sky Model (A. Tegmark et al. 2008)
GSM_DIR="/Path/To/GSM/"

# Python executable
python="python"

# PDF Viewer
PDFViewer="acroread"

# Directory under which to find the HI and CO templates for SAX made by Danail Obreschkow [University of Oxford]
SAX_TEMPLATES_DIR="/Path/To/Oxford_Templates/"

# Directory under which to find the IQU templates for SAX made by Tigran Arshakian [Max-Planck Institut fur Radioastronomie]
MPIFR_TEMPLATES_DIR="/Path/To/MPIFR_Templates/"

# Directory under which to find the EoR signal from Mario Santos (IST)
IST_EOR_TEMPLATES_DIR="/Path/To/IST_Templates/"

# Directory under which to find the HI and CO templates for SAX made by Rense Boomsma [Kapteyn Institute]
KAPTEYN_TEMPLATES_DIR="/Path/To/Kapteyn_Templates/"

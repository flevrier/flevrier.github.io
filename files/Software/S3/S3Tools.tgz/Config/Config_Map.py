# Spatial frame
#ra_orientation=1 # R.A. increases from left to right 
#ra_orientation=-1 # R.A. increases from right to left [DEFAULT VALUE]
Xref=0.0 # Conventional reference X position for the reference pixel
Yref=0.0 # Conventional reference Y position for the reference pixel

# Python data type: "f" for single precision floats, "d" for double precision floats 
data_type="d"

# Velocity range for normal star-forming galaxies, in km/s [SEX ONLY]
normal_velocity_range=[40.,140.]

# Velocity range for starburst galaxies, in km/s [SEX ONLY]
starburst_velocity_range=[20.,70.]

# Maximum standard deviation of slopes leading to a power-law fit. Above that value leads to a log-polynomial fit. [SEX ONLY]
epsilon_power_law_sed=0.001

# Degree of the log-polynomial fit [SEX ONLY]
degree_logpolynomial_fit=3

# Shape factors for HI profiles [SEX ONLY]
shape_factors=[0.3,1.0,0.0,0.3,2.0,0.3,5.0]

# Number of sub-channels to use to compute continuum flux in any given channel [SEX ONLY]
Nsubchan=100L

inclination_markups=range(0,91,2) # Markups for disk inclination values [SAX ONLY]
rmolc_markups=range(90) # x10 markups for the H2/HI surface density ratio at the disk center [SAX ONLY]

# Default spectral channel width in kHz : used when computed spectral width in S3Map returns 0
default_spectral_width=62.5

# Maximum number of pixels for a single output cube or map (20 Mpix corresponds to approximately 150 MB in memory)
Npixmax=20000000L

# How many times the line width at 20% of the peak should be allowed on each side of the line center to make sure we get all the emission from a given object in a given line
line_width_factor=1.0 


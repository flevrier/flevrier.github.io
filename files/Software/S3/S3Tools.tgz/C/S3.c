// Compile with:
// gcc -Wall -O2 -fPIC -c S3.c && gcc -shared -Wl,-soname,libS3.so -o libS3.so S3.o

# include <stdio.h>

void weighting(int n1,int n2,int n3,int xmin,int xmax,int ymin,int ymax,double w_xmin,double w_xmax,double w_ymin,double w_ymax,double* data_in,double* data_out)
{
  int i1,i2,i3,i_data,i_weights;
  double value,weight_x,weight_y;
  for (i3 = 0; i3 < n3; ++i3)
    {
      value=0.0;
      for (i1 = xmin; i1 <= xmax; ++i1)
	{
	  weight_x=1.0;
	  if (i1==xmin)
	    {
	      weight_x=w_xmin;
	    }
	  if (i1==xmax)
	    {
	      weight_x=w_xmax;
	    }	  
	  for (i2 = ymin; i2 <= ymax; ++i2)
	    {
	      weight_y=1.0;
	      if (i2==ymin)
		{
		  weight_y=w_ymin;
		}
	      if (i2==ymax)
		{
		  weight_y=w_ymax;
		}
	      i_data=i1 + n1 * (i2 + n2 * i3);
	      value=value+(weight_x*weight_y*data_in[i_data]);	      
	    }
  	}
      data_out[i3]=value;
    }
}

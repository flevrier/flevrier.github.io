# Import modules.
import numpy
import ctypes
import pyfits
from time import time
import math

# Load a custom-made shared C library.
_mylib = ctypes.cdll.LoadLibrary(ROUTINES_DIR+"libS3.so")

# Define Python-callable function(s) from the shared object library.
def weighting(n1,n2,n3,xmin,xmax,ymin,ymax,w_xmin,w_xmax,w_ymin,w_ymax,data_in,data_out):
    return _mylib.weighting( ctypes.c_int(n1), 
    		ctypes.c_int(n2), ctypes.c_int(n3), 
                ctypes.c_int(xmin), ctypes.c_int(xmax), 
                ctypes.c_int(ymin), ctypes.c_int(ymax), 
                ctypes.c_double(w_xmin),ctypes.c_double(w_xmax),
                ctypes.c_double(w_ymin),ctypes.c_double(w_ymax),            
            data_in.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            data_out.ctypes.data_as(ctypes.POINTER(ctypes.c_double)) )

# Load a custom-made shared C library.
_mylib = ctypes.cdll.LoadLibrary("libS3.so")

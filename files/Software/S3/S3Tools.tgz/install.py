def module_test_line(module_name,length_before_msg,msg):
    blanks="... "
    for i in range(length_before_msg-len(module_name)):blanks+=" "
    return(module_name+blanks+msg)

def run_module_tests():
    print "Running tests for Python modules..."
    spacing=18

    msg="[ok]"    
    try: import os
    except ImportError: msg="[NO!]"
    print module_test_line("os",spacing,msg) 

    msg="[ok]"    
    try: import sys
    except ImportError: msg="[NO!]"
    print module_test_line("sys",spacing,msg) 
    
    msg="[ok]"    
    try: import getopt
    except ImportError: msg="[NO!]"
    print module_test_line("getopt",spacing,msg) 
    
    msg="[ok]"    
    try: import math
    except ImportError: msg="[NO!]"
    print module_test_line("math",spacing,msg) 
    
    msg="[ok]"    
    try: import numpy
    except ImportError: msg="[NO!]"
    print module_test_line("numpy",spacing,msg) 

    msg="[ok]"    
    try: import scipy
    except ImportError: msg="[NO!]"
    print module_test_line("scipy",spacing,msg) 
    
    msg="[ok]"    
    try: import pyfits
    except ImportError: msg="[NO!]"
    print module_test_line("pyfits",spacing,msg) 
    
    msg="[ok]"    
    try: import time
    except ImportError: msg="[NO!]"
    print module_test_line("time",spacing,msg) 
    
    msg="[ok]"    
    try: import random
    except ImportError: msg="[NO!]"
    print module_test_line("random",spacing,msg) 
    
    msg="[ok]"    
    try: import types
    except ImportError: msg="[NO!]"
    print module_test_line("types",spacing,msg) 
    
    msg="[ok]"    
    try: import ctypes
    except ImportError: msg="[NO!]"
    print module_test_line("ctypes",spacing,msg) 
    
    msg="[ok]"    
    try: import stat
    except ImportError: msg="[NO!]"
    print module_test_line("stat",spacing,msg) 
    
    msg="[ok]"    
    try: import Tkinter
    except ImportError: msg="[NO!]"
    print module_test_line("Tkinter",spacing,msg) 
    
    msg="[ok]"    
    try: import tkFileDialog
    except ImportError: msg="[NO!]"
    print module_test_line("tkFileDialog",spacing,msg) 
    
    msg="[ok]"    
    try: import tkFont
    except ImportError: msg="[NO!]"
    print module_test_line("tkFont",spacing,msg) 
    
    msg="[ok]"    
    try: import matplotlib
    except ImportError: msg="[NO!]"
    print module_test_line("matplotlib",spacing,msg) 

def ask_directory(prompt,skip):
    dir_reply=False
    if (skip==False):
        while not(dir_reply):
            DIR=raw_input(prompt)
            if not(os.path.isdir(DIR)):print "This is not a valid answer.."
            else:dir_reply=True
    else:
        while not(dir_reply):
            DIR=raw_input(prompt)
            if (not(os.path.isdir(DIR)))and(DIR!=""):print "This is not a valid answer..."
            else:dir_reply=True
    return(DIR)

def ask_executable(prompt):
    exe_reply=False
    while not(exe_reply):
        EXE=raw_input(prompt)
        w=os.popen("which "+EXE).read()
        if (EXE==""):exe_reply=True
        elif(w!=""):exe_reply=True
        else:print "This is not a valid answer..."
    return(EXE)

# FIRST RUN CHECKS ON EXISTING PYTHON MODULES
run_module_tests()

import os
existing_reply=False
# ASK IF THERE IS AN EXISTING INSTALLATION
while not(existing_reply):
    already_installed = raw_input('Is there an existing installation of the S3Tools [Y/N] ? ')
    if (already_installed.capitalize()=="Y"): # YES, THEN UPGRADE ROUTINES 
        INSTALL_DIR=ask_directory('Give full path to (existing/desired) installation directory : ',False)
        print "Upgrading S3Tools in "+INSTALL_DIR
        ls=os.popen("ls "+os.getcwd()+"/Routines/*.py").readlines()
        for file in ls:
            new_file=file.replace("\n","").replace("//","/")
            original_file=new_file.replace(os.getcwd(),INSTALL_DIR).replace("//","/")
            if not(os.path.isfile(original_file)): # A NEW FILE HAS BEEN ADDED TO THE DISTRIBUTION
                print "Adding "+os.path.basename(original_file)+" to your distribution..."
                cp_cmd="cp "+new_file+" "+INSTALL_DIR+"/Routines/"
                cp=os.popen(cp_cmd)
                cp.close()
            else: # A FILE OF THE SAME NAME ALREADY IS PRESENT, CHECK FOR DIFFERENCE
                diff_cmd="diff "+original_file+" "+new_file
                diff=os.popen(diff_cmd).readlines()
                if (len(diff)>0): # A DIFFERENCE IS FOUND FOR THIS FILE, BACKUP OLD VERSION AND COPY NEW VERSION
                    print os.path.basename(original_file)+" needs upgrading..." 
                    # BACKUP OLD VERSION
                    cp_cmd="cp "+original_file+" "+original_file+".bak"
                    cp=os.popen(cp_cmd)
                    cp.close()
                    # COPY NEW ONE TO INSTALLATION DIRECTORY
                    cp_cmd="cp "+new_file+" "+INSTALL_DIR+"/Routines/"
                    cp=os.popen(cp_cmd)
                    cp.close()
        ls=os.popen("ls "+os.getcwd()+"/Routines/*.sh").readlines() # ALSO UPGRADE SHELL SCRIPTS (SUCH AS TEST RUNS)
        for file in ls:
            new_file=file.replace("\n","").replace("//","/")
            original_file=new_file.replace(os.getcwd(),INSTALL_DIR).replace("//","/")
            if not(os.path.isfile(original_file)): # A NEW FILE HAS BEEN ADDED TO THE DISTRIBUTION
                print "Adding "+os.path.basename(original_file)+" to your distribution..."
                cp_cmd="cp "+new_file+" "+INSTALL_DIR+"/Routines/"
                cp=os.popen(cp_cmd)
                cp.close()
            else: # A FILE OF THE SAME NAME ALREADY IS PRESENT, CHECK FOR DIFFERENCE
                diff_cmd="diff "+original_file+" "+new_file
                diff=os.popen(diff_cmd).readlines()
                if (len(diff)>0): # A DIFFERENCE IS FOUND FOR THIS FILE, BACKUP OLD VERSION AND COPY NEW VERSION
                    print os.path.basename(original_file)+" needs upgrading..." 
                    # BACKUP OLD VERSION
                    cp_cmd="cp "+original_file+" "+original_file+".bak"
                    cp=os.popen(cp_cmd)
                    cp.close()
                    # COPY NEW ONE TO INSTALLATION DIRECTORY
                    cp_cmd="cp "+new_file+" "+INSTALL_DIR+"/Routines/"
                    cp=os.popen(cp_cmd)
                    cp.close()
        # ALSO CHECK FOR MISSING SUBDIRECTORIES
        if not(os.path.isdir(INSTALL_DIR+"/C")):
            cp=os.popen("cp -R "+os.getcwd()+"/C "+INSTALL_DIR)
            cp.close()
        if not(os.path.isdir(INSTALL_DIR+"/Tests")):
            cp=os.popen("cp -R "+os.getcwd()+"/Tests "+INSTALL_DIR)
            cp.close()
        if not(os.path.isdir(INSTALL_DIR+"/Jobs")):
            cp=os.popen("cp -R "+os.getcwd()+"/Jobs "+INSTALL_DIR)
            cp.close()
            # NOW MAKE SYMBOLIC LINKS TO PYTHON ROUTINES FROM Jobs/ SUBDIRECTORY, FOR SHELL SCRIPTS
            ls=os.popen("ls "+INSTALL_DIR+"/Routines/*.py").readlines()
            os.chdir(INSTALL_DIR+"/Jobs/")
            for file in ls:
                os.popen("ln -s ../"+os.path.basename(file.replace("\n","").replace("//","/")))
        existing_reply=True
    elif (already_installed.capitalize()=="N"): # NO EXISTING INSTALLATION. BUILD A NEW ONE.
        INSTALL_DIR=ask_directory('Give full path to (existing/desired) installation directory : ',False)
        print "Installing S3Tools in "+INSTALL_DIR
        # START BY COPYING THE .py ROUTINES TO TARGET DIRECTORY
        cp_cmd=os.popen("cp -R * "+INSTALL_DIR)
        cp_cmd.close()
        # NOW DEAL WITH CONFIGURATION FILE Config_Path.py...
        autoconf_reply=False
        # ASK IF USER WANTS AUTO-CONFIGURATION
        while not(autoconf_reply):
            autoconfig = raw_input('Do you want to proceed with path configuration now [Y/N] ? ')
            if (autoconfig.capitalize()=="Y"): # YES, THEN PROCEED WITH AUTOCONF
                # PROMPT THE USER FOR PATHS
                S3TOOLS_PATH=INSTALL_DIR
                PYTHON_EXE=ask_executable('Give python executable [python] : ')
                PDF_VIEWER=ask_executable('Give PDF viewer command for help files [acroread] : ')
                SAX_TEMPLATES_DIR=ask_directory('Give full path to directory under which to find the HI and CO templates for SAX made by Danail Obreschkow [/Path/To/Oxford_Templates/] : ',True)
                KAPTEYN_TEMPLATES_DIR=ask_directory('Give full path to directory under which to find the HI templates for SAX made by Rense Boomsma [/Path/To/Kapteyn_Templates/] : ',True)
                WCS_DIR=ask_directory('Give full path to directory under which to find the WCS Tools binaries [/Path/To/WCS/bin/] : ',True)
                GSM_DIR=ask_directory('Give full path to directory under which to find Global Sky Model [/Path/To/GSM/] : ',True)
                MPIFR_TEMPLATES_DIR=ask_directory('Give full path to directory under which to find the IQU continuum templates for SAX made by Tigran Arshakian [/Path/To/MPIFR_Templates/] : ',True)
                IST_EOR_TEMPLATES_DIR=ask_directory('Give full path to directory under which to find the EoR signal from Mario Santos [/Path/To/IST_Templates/] : ',True)
                # BACKUP DEFAULT Config_Path.py 
                cp_cmd="mv "+INSTALL_DIR+"/Config/Config_Path.py "+INSTALL_DIR+"/Config/Config_Path.py.bak"
                cp=os.popen(cp_cmd)
                cp.close()
                # BUILD NEW ONE WITH USER'S ANSWERS
                ifp=open(INSTALL_DIR+"/Config/Config_Path.py.bak","r")
                ofp=open(INSTALL_DIR+"/Config/Config_Path.py","w")
                for line in ifp:
                    outline=line
                    if ("S3TOOLS_PATH=" in line)and(S3TOOLS_PATH!=""):outline=line.replace('="/Path/To/Tools/"','="'+(S3TOOLS_PATH+"/").replace("//","/")+'"')
                    if ("WCS_DIR=" in line)and(WCS_DIR!=""):outline=line.replace('="/Path/To/WCS/bin/"','="'+(WCS_DIR+"/").replace("//","/")+'"')
                    if ("GSM_DIR=" in line)and(GSM_DIR!=""):outline=line.replace('="/Path/To/GSM/"','="'+(GSM_DIR+"/").replace("//","/")+'"')
                    if ("python=" in line)and(PYTHON_EXE!=""):outline=line.replace('="python"','="'+PYTHON_EXE+'"')
                    if ("PDFViewer=" in line)and(PDF_VIEWER!=""):outline=line.replace('="acroread"','="'+PDF_VIEWER+'"')
                    if ("SAX_TEMPLATES_DIR=" in line)and(SAX_TEMPLATES_DIR!=""):outline=line.replace('="/Path/To/Oxford_Templates/"','="'+(SAX_TEMPLATES_DIR+"/").replace("//","/")+'"')
                    if ("MPIFR_TEMPLATES_DIR=" in line)and(MPIFR_TEMPLATES_DIR!=""):outline=line.replace('="/Path/To/MPIFR_Templates/"','="'+(MPIFR_TEMPLATES_DIR+"/").replace("//","/")+'"')
                    if ("IST_EOR_TEMPLATES_DIR=" in line)and(IST_EOR_TEMPLATES_DIR!=""):outline=line.replace('="/Path/To/IST_Templates/"','="'+(IST_EOR_TEMPLATES_DIR+"/").replace("//","/")+'"')
                    if ("KAPTEYN_TEMPLATES_DIR=" in line)and(KAPTEYN_TEMPLATES_DIR!=""):outline=line.replace('="/Path/To/Kapteyn_Templates/"','="'+(KAPTEYN_TEMPLATES_DIR+"/").replace("//","/")+'"')
                    ofp.writelines([outline])
                ofp.close()
                ifp.close()
                autoconf_reply=True
            elif (autoconfig.capitalize()=="N"):        
                print "You will need to edit the Config_Path.py file manually for the S3Tools to work... Please refer to README."
                autoconf_reply=True
            else:print "Please answer the question..."
            # NOW MAKE SYMBOLIC LINKS TO PYTHON ROUTINES FROM Jobs/ SUBDIRECTORY, FOR SHELL SCRIPTS
            ls=os.popen("ls "+INSTALL_DIR+"/Routines/*.py").readlines()
            os.chdir(INSTALL_DIR+"/Jobs/")
            for file in ls:
                os.popen("ln -s ../"+os.path.basename(file.replace("\n","").replace("//","/")))
            # NOW DEAL WITH THE C STUFF...
            print "For the S3Tools to work, you need to compile the file S3.c under Routines/ into a libS3.so shared object library. Please refer to the README file."
        existing_reply=True
    else:print "Please answer the question..."

